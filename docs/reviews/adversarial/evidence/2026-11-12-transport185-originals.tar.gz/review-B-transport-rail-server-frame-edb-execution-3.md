# 원 B Transport Rail edb EXECUTION3 — bounded frontend gate

- 원 리뷰어 B(Epicurus), runid `B-RAIL-EDB-EXEC3-20261112T101932Z`, UTC `2026-11-12T10:19:32Z`. 구현 비참여·상대 CURRENT 결과/원문 접근0. manifest에 든 상대 SOURCE2 archive도 읽기/해시 대상에서 제외했다.
- **BOUNDED FRONTEND EXECUTION PASS / 신규 finding 0건 / CI_PENDING.** exact source2 소스 판정을 재작성하지 않고 해당 frontend 실행 증거를 연결한다. merge·ARM·apply·운영 수용 승인이 아니다.
- manifest `review-manifest-transport-rail-server-frame-edb-execution-3.json` SHA256 `0aaf771e908d289e558cc492ace744c1fffcbd707617b29037a82a3e4218584d` 직접 일치. QA receipt SHA256 `c3c572c1b427c6b4654f496d93cdfdfe3d47881eb3539c349962dd6b2bfe470d` 일치.
- exact source `edb6538209d5fc2d1b64e001af971dfc0e82ea55`, tree `7ffb15929c7b8de0e48555312797fc66aa47ed58`. own SOURCE2 raw SHA256 `2b204be254b34805b95462542d2ce488e4729c71d25916b5cffb28b6732b7813` 동일, 원문 불변.

## 새로운 edb 실행과 bytes

- 원 B가 QA frozen **100개 파일의 SHA256/bytes/mode를 전부 직접 검산**, 불일치0. 별도 과거 worker R2 frozen **16개도 전부 일치**. 10개 browser raw의 case/status/retry/attempt·오류·attachment를 직접 파싱했다.
- **Native43 + Alpine43 = 새 exact-source86 PASS**. 각 환경은 No-JS2 + 기본18 + review4 + private6 + menu13이며 모든 case 최초1attempt/retry0, skip/flaky/unexpected/top-level errors0이다. 새 edb에는 staged recovery/누락 suite continuation을 조합할 필요가 없었다. 과거 bf9의 성공·실패·진단을 86에 더하거나 새 head PASS로 전용하지 않았다.
- 실제 No-JS raw attachment의 프레임은 양쪽 모두 PC1280에서 **976×832**, 모바일375에서 **351×783**, `javaScriptEnabled:false`다. 기존 no-JS2 RED 보존 영수증과 새 초기 프레임/지도·목록 탭 green을 구분한다. 실제 운영 최초 region0의 원인까지 입증하는 결과는 아니다.
- gates7 exit0 및 결과→log digest 일치. 새 전체 **63files/458 PASS**, focused **4files/30 PASS(새 실제 Common Picker5 포함)**, Doctor0/type/lint/installed·external canonical guards. before2FAIL3PASS→after5PASS 집중 증거는 선행 원본으로 보존됐고, 새 full458에 동일5가 포함된다. passive prefill·지연 catalog/remount의 focus 보존 및 명시적 departure/arrival·동일 역 재지정 대조를 새 full gate에 연결한다.
- source receipt **909 SHA를 immutable Git blobs와 직접 대조**했고 gitlink1 pin도 일치한다. actual-image-audit mjs의 COPY expected **298**을 정확 Git source에, common expected **263**을 실제 Git tgz/SRI/lock/member SHA에 연결했다. 실제 소비6 package byte 입력은 공통 C11 그대로다. 설치된 modules/컨테이너 실제 검사는 owner의 hash-bound fail-closed 실행 audit exit0·mismatch0 증거로 읽었으며 원 B가 Docker에 재접속한 것은 아니다.
- fresh native/Alpine build exit0·pipeline exit0, compiled route32와 rail/parking-lots/timetable을 기록했다. QA image `sha256:a27d2aa60eeff62804792da1922252d6a5592f9f6a758d8b2f651eda37361995`의 source label 및 audit 연결이 있다. 이는 **local QA builder/fixture image**이며 새 merged M ARM release/runner/운영 image 수용 증명이 아니다.
- private harness5 원문 hash 및 repo/private config timeout45000/retries0/workers1을 확인했다. 새 source·기존 E2E assertion/timeout/skip/pool 변경 없이 동작하는 경로다. 기존 localhost helper와 simulated cookie/API fixture의 성공을 실제 인증·키·live backend/지도 성공으로 확대하지 않는다.

## 중요 집계 정정 — 과거 bf9 관측은 총 2회

- 초기 잘못된 selector 수집은 **target0**, worker R2는 **09:46:43.895Z target1 ASSERTION PASS**, parent는 **09:52:38.062Z target1 ASSERTION PASS**다. **old bf9 단독 관측 총2회**이며 “전체 한 번뿐/추가 관측 없음”이라고 쓰지 않는다.
- worker R2의 지연 focus는 **상세1034→출발역1179ms**, parent의 지연 focus는 **상세967→출발역1161ms**다. 두 관측 모두 순간 assertion PASS 뒤 최종 입력칸 focus를 관찰했다. worker receipt/raw report/16 frozen 및 parent diagnosis/addendum hash를 구분해 확인했다. 인계 지연으로 parent가 이미 끝난 worker 관측을 알기 전에 중복 관측했다는 한계도 보존한다.
- 이 두 관측은 **production login0·다른42개 반복0**의 별도 old-source 진단이다. 최초 bf9 Alpine42P1F는 그대로 FAIL, 첫 실패 focus timeline 부재로 **원인 미상**이다. 새 edb86과 합산하거나 첫 실패를 소급 PASS로 바꾸지 않는다. M885의 운영8P1F 및 별도 contact FAIL/region0·href 미도달·원인 미상도 그대로다.
- own SOURCE2는 parent의 한 관측을 기술했으며 전역 관측 총1이라고 승인한 원문으로 해석하지 않는다. **이후 Common/Geo 최종 보고서·PR·운영 인계에는 전체2회와 수집0을 반드시 명시**해야 한다. 이 실행 입력은 addendum로 이를 명확히 공개하므로 신규 finding으로 계상하지 않는다. 기존 원문/실패/worker·parent 증거를 모두 보존한다.

## cleanup·CI·운영 한계

- 종료 증거는 native PID1930480 종료·port53771 closed, Alpine port32788 closed/container stopped, own processes/browser PIDs/ports/containers0·runner exit0과 source909/harness mismatch0을 기록한다. 원 B는 hash-bound **기록 시점** 종료 증거를 검토했으며 현 호스트 재조회·프로세스 종료·타인 cache 정리는 하지 않았다.
- CI frozen checkpoint는 run43195806562 admin458/public164·양쪽 Doctor0/type/lint/build SUCCESS, policy43195808014 두 jobs SUCCESS다. synthetic checkout `4d9bcf93fdd38f1e593de376521359cb994518ef` whole tree가 edb와 같음을 로컬 Git으로 확인했다. **backend131106341751 RUNNING_NOT_PASS**, live-e2e **SKIPPED_NOT_PASS** 관찰을 유지하며 새 API 상태 조회/전체 CI PASS 확대는 하지 않았다.
- 원 B test/browser/build/install/network/host/Docker/production/source/index/branch mutation0. 기존 frozen 파일·Git·hash만 읽었다. 실제 새 M ARM image·official admin-only apply·정상 actual9는 후속 필수다. backend 완료 후 tiny exactCI closure도 별도로 필요하다. Common/Geo publication HOLD 및 Map 운영 제외 유지.
- 조사 중 정적 audit parser가 `const common=`만 가정하여 combined declaration `,common=`에서 IndexError가 났다. 파서를 교정했고 제품/test 실행 실패로 합산하지 않았다. 원 source/report를 수정하지 않았다.
- own evidence `review-B-transport-rail-server-frame-edb-execution-3-evidence/verification.json` SHA256 `73479f3ed40576be0bc5305dbffe316fd63fef177b019f7dcfe6809fb029c991`; 100+16 SHA/bytes/mode·case86 raw stats/attempts·909/298/263 byte bridge·관측2 집계·gate 요약·명령/evidence index를 동결한다.
