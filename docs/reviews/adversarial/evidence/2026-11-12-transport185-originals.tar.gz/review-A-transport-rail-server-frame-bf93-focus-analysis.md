# A — bf93 focus analysis（read-only advisory）

Run A-TR-BF93-FOCUS-ANALYSIS-20261112; UTC 2026-11-12T09:51:10.493066+00:00; exact source bf937d1cb79b06c8da2ffb8c24b42e8c527f5995, tree 6d3d2b5aa20b50aee798ebaeb0c38377d7859ec5.
Scope: passive prefill/explicit station intent 的 포커스 의미와 최소 수정·test 방향만 검토. 원 SOURCE1 PASS 원문/실행 승인 변경0, 새 원인 확정 판정 아님.
관찰: frozen final-receipt SHA256 c484c64fd3b4cecfede405d6625c2ac5bf7c8bccd80e2f26796cf87b4be9008f; Native43PASS, Alpine42PASS1FAIL, wholeQAPassed=false.
첫 Alpine report SHA256 889cfcd4b298b4b9939750a31af80f5905f208d38a2aa154795afd10d19b3987 직접 일치. 원 admin-review-regressions.spec.ts:32–34는 주소 버튼→map aria-selected=true→detail.toBeFocused(5000ms) 순서이며 마지막 focus만 실패했다.
**의견: passive 이름 채움과 명시적 지정은 구분해야 한다.** 상세를 열며 참고용 검색어를 넣는 작업은 비동기 catalog 완료 때 상세/지도/사용자가 옮긴 focus를 빼앗을 의도가 아니다. 반면 사용자의 출발·도착 지정은 해당 picker로 안내할 합당한 명시적 요청이다.
소스 경로: general-rail-station-detail.tsx:9는 compact Journey에 initialDepartureName만 전달한다. general-rail-journey.tsx:95는 이를 explicit initialStationIntent와 똑같이 revision1로 초기화한다.
rail-station-picker.tsx:21–23은 revision>0 및 !disabled이면 id input을 focus한다. disabled→enabled 변화도 effect 의존성이므로 처음 mount/재mount 후 catalog가 늦게 준비되면 실행될 수 있다.
transport-map.tsx:230–236은 view/detail 전환 시 requestAnimationFrame으로 상세에 focus한다. map/list panel 변경으로 compact Journey가 재mount되고 이후 catalog가 준비되는 순서라면 picker focus가 나중에 상세 focus를 덮는 경합 경로가 성립한다.
**Runtime cause UNDETERMINED.** 첫 report는 aside가 13회 inactive였다는 증거이며 실제 focus 수신자와 focusin·catalog·mount/rAF 시간순서를 제공하지 않는다. 현재 observer target 결과는 읽지 않았다. 이번 Alpine 실패가 위 경로 때문인지 또는 SSR 변경으로 새로 유발됐는지 단정하지 않는다.
가장 작은 권고: Journey 초기 상태의 **passive initialDepartureName만 revision0**, explicit initialStationIntent revision1 및 requestStation(:107–111)의 새 revision 증가 유지. picker의 기존 truthy revision 조건을 활용하므로 새 API 없이 이름 입력과 자동 focus 요청을 분리할 수 있다.
정적 확인: picker:19–20은 revision0에서도 searchRequest.text를 기본 검색어로 사용하므로 수동 prefill은 남는다. 실제 station_id 선택·조회 허용 조건과 intent provider identity는 그대로 유지할 수 있다. 구현자 별도 patch와 원 reviewer 재검토가 필요하다.
회귀1: compact detail passive prefill + deferred catalog/stations를 두고 상세에 focus→catalog resolve 후 상세 focus 유지·검색어 유지·station_id 미선택·timetable 호출0을 확인한다. 사용자 다른 control에 focus한 경우에도 늦은 passive 응답으로 이동하지 않아야 한다.
회귀2: map/list→주소 지도 이동/동일 station remount + 늦은 catalog 순서를 고정해, 기존 상세 toBeFocused 단언을 원 timeout으로 유지한다. 가능하면 focusin 순서를 기록해 detail 이후 picker focus가 없는지 확인한다.
회귀3: 명시적 출발/도착 intent는 catalog가 늦게 준비돼도 의도한 picker로 안내되고, 동일 이름 재지정도 새 revision에 반응하는 positive control을 둔다. 반대역/날짜/차종 보존, 실제 후보 선택 전 조회 금지도 유지한다.
기존 tests: rail-station-picker.test.tsx:16은 실제 Combobox 선택/코드 대신 이름 표시, general-rail-station-intent.test.tsx:110/125/141은 지정·취소·딥링크 업무 계약을 보존한다. deferred catalog 뒤 passive focus 불변과 실제 detail remount를 직접 고정한 테스트는 이 읽은 범위에서 확인하지 못했다.
최소 수정 검증은 passive focus만 제거하고 explicit intent positive control 및 원 browser detail focus 단언을 함께 통과시키는 것이다. 전역 autofocus 제거·상세 반복 focus 보정·timeout 증가로 실제 keyboard 의도를 바꾸는 방향은 이 분석의 권고가 아니다.
Evidence: review-A-transport-rail-server-frame-bf93-focus-analysis-evidence/evidence.json 및 exact source/tests numbered.txt. 원 SOURCE1 SHA256 362f71ec09426cf88ef1614a446108042b3de0ea74336015e8b118ef133bacf3 불변 검산.
본인 source/test/index/branch 수정0, 테스트·observer 실행/운영접속/로그인0, peer CURRENT 열람0. 현재 전체 execution은 실패1 보존/최종 승인 미부여이며, 원인 종결은 별도 진단·불변 수정 입력 이후이다.
