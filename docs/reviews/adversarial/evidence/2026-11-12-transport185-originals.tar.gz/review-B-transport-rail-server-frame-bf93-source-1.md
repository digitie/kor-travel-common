# 독립 리뷰 B — Transport PR185 bf93 Rail server frame SOURCE1

- 원 리뷰어 B(Epicurus), backend/ops/invariants·라이브러리/패키지·provenance 렌즈. 구현 비참여, 상대 CURRENT 원문/결과 접근0.
- runid `B-RAIL-SSR-BF93-SOURCE1-20261112T093129Z`, 관찰 UTC `2026-11-12T09:31:29Z`.
- **SOURCE PASS / 신규 finding 0건(P0–P3 없음).** 실행·CI 최종·merge·새 이미지·실제 운영 QA 승인이 아니다.
- manifest `review-manifest-transport-rail-server-frame-bf93-source-1.json` SHA256 `759f210a69842147aad34a8880d021b1f890656a76c6839bb29a2958f162f4e1` 직접 일치, 명시8개 factual ref SHA256 일치.
- source `bf937d1cb79b06c8da2ffb8c24b42e8c527f5995`, tree `6d3d2b5aa20b50aee798ebaeb0c38377d7859ec5`, review base actual M `88566f7d16c3bb1b497d3ce0c4869c43d6d51844`. base는 ancestor이며 직접 부모는 `cc1c329966715abdceeb782b77d9a388a3feaffa`로 구분했다. moving working tree를 기준으로 사용하지 않았다.

## source/ABI/SSR 검토

- 제품 delta는 `frontend/components/general-rail-guide.tsx:13`: `next/dynamic` 및 `ssr:false` wrapper 제거, **같은 ./transport-map의 named TransportMap** 일반 import다. 기존 `/map`의 static import(`app/map/page.tsx:2`)와 일치한다. product 함수 본문/props/19개 메뉴/업무 로직에는 추가 변경이 없음을 문자열 동등성으로 직접 확인했다.
- API guide 조회·AbortController 수명·provider ID→marker ID·카테고리/선택·출발/도착 callback 및 timetable URL은 그대로다. `GeneralRailGuide`는 SSR 초기 빈 places를 넘겨 `useTransportMap`의 embedded 경로를 택한다. `initialMapCamera`의 embedded/서버 guard가 window.location 접근을 피하고, API fetch와 map lifecycle/DOM observer는 effect/event 경로에 있다. 새 서버 데이터 조회나 auth/DB API는 추가하지 않는다.
- 실제 동봉 `vworld-map-web1.0.3`의 entry와 `VWorldMapView.web.js`를 읽었다. 공개 named export를 유지하고 MapLibre 생성은 effect 안에 있으며 store hooks에는 server snapshots가 있다. app의 module-level `setWorkerUrl`은 기존 `/map`과 같은 상수 경로다. 새 worker/라이브러리 복제·별도 modal·새 API adapter가 없다. app import 경로에 새 runtime cycle을 만들지 않고, 역 안내를 참조하는 timetable import 중 type-only 참조도 구분했다.
- static import는 비동기 child barrier를 제거하여 초기 작업면 HTML/CSS 적용 시점을 바꾼다. global CSS의 `:has(.map-workbench)`/grid·flex 규칙과 결합하는 변경이다. **CSS 자체와 TransportMap 구현은 byte 동일**이다. 일반 import가 app chunk 구성·초기 로드 비용을 바꿀 수 있으며 bundle 크기/성능 향상·ARM 원인 해결은 이 소스 리뷰로 입증하지 않았다. 기존 tgz 동일성이 새 app bundle/image 동일성을 뜻하지 않는다.

## 테스트 doubles·회귀 의미·fixture 공격

- `general-rail-station-intent.test.tsx:16`은 dynamic mock의 함수 그대로 static module mock으로 옮겼다. 파일 전체가 정확 그 mock 경계 치환만으로 일치한다. `rail-search-state.test.tsx:10`의 MapFixture 함수 본문도 이전과 정확 같으며 Metro의 dynamic mock과 Guide의 static mock이 그 함수를 공유한다. 기존 fetch/state/실패/다시조회/출발·도착 assertion은 바뀌지 않았다. 이는 이 테스트들의 props/표현 double 보존 근거이며 실제 WebGL·타이밍 동등성을 뜻하지 않는다.
- `transport-map.test.tsx:30`의 새 SSR unit은 **mock하지 않은 실제 GeneralRailGuide/TransportMap/Common workspace**가 서버 마크업에 작업면과 지도·목록 두 탭을 생성하는지 검사한다. MapLibre/VWorld/일부 하위 부품은 기존 double이고 환경은 **jsdom**이다. 따라서 window/document 없는 실제 Node import 안전성·CSS bbox·실제 지도 엔진/키 수용의 대체 검사가 아니다. before-old-source red proof는 **PENDING**으로 남긴다.
- 신규 `e2e/rail-map-server-frame.spec.ts:4`는 JavaScript disabled이고 1280/375의 실제 HTTP `/rail`에서 region bbox>=320, map-workbench1, 지도·목록 탭 visibility를 검사한다. test line13은 측정 bbox를 attachment로 남긴다. CSS injection/height override/timeout/skip/retry 완화가 추가되지 않았다. **No-JS 초기 프레임/탭 표시 검사**이며 탭 클릭·API65·연락처 href·WebGL 동작 검사는 아니다.
- 실제 baseURL이 HTTP(S) exact loopback인지 먼저 검사하고 동일 origin/path 검증 뒤 cookie/route/goto를 수행하는 기존 `openIsolatedMenuPage`를 재사용한다. remote caller/가짜 loopback host·userinfo/unsafe protocol·cross-origin 경로는 기존 사전 거부 경계에 머문다. helper raw blob은 base와 동일하다. mock session을 실제 운영 인증으로 확대하지 않는다. No-JS 때문에 모바일 Drawer 인터랙션이 불가능한 것을 새 No-JS 테스트가 mobile menu 수용으로 잘못 주장하지도 않는다.

## 패키지·보호 경계·입력 증거

- 정확 변경 **7 paths(제품1/테스트4/docs2)**, base907→head908 blobs + gitlink1. 기존901개 blob 동일. candidate.json의 변경7 + reference `/map` raw Git bytes/길이/SHA256 모두 일치한다. 기존 보호 inventory **298 mode/OID 전부 동일**, gitlink `3c09359fa3dea4f65ec14b9db3814cfd410bc104`도 동일하다.
- backend/public/auth/key/pkg/lock/vendor/global CSS/menu/data gates는 변경 대상이 아니다. 보호 객체 및 7경로 diff로 확인했다. 실제 소비6 package의 tgz bytes/SRI/lock integrity를 직접 검산해 동일하고 예상 archive member **263**을 확인했다. 새 source908/COPY**297**는 기대 입력 수이며 **새 빌드의 실제 COPY297/설치된263/compiled32를 원 B가 실행 관찰한 것은 아니다**. 새 설치·pack·라이선스 재발행 없음.
- 입력의 초기 candidate 상태 `PROTOTYPE...TESTS_PENDING_NOT_PUSHED`는 당시 snapshot으로 읽었다. 이후 frozen CI checkpoint는 run43190718380 admin453/public164/type/lint/build/Doctor0, policy43190719014 두 jobs SUCCESS를 기록하지만 backend131089025654는 **RUNNING_NOT_PASS**, liveE2E는 **SKIPPED_NOT_PASS**다. 이 상태는 부모 frozen evidence이며 새 API 전체 상태를 조회하지 않았다. CI checkout `9d6c3f140301aa43c59dccc5937baa5b5ebdbb13` whole tree가 bf93와 같다는 것은 로컬 Git 객체로 직접 확인했다. 전체 CI PASS로 확대하지 않는다.

## 실제 실패 이력·원인 추정 방지

- 기존 runtime은 **M885/image sha256:5ffe49f0492db1baeb37233d711d040587b0768e70139fb82b974432494083d4**이다. 최초 정상9 checks는 **8P1F**, 별도 unchanged contact target도 **FAIL**이었다. 두 세션 각각 login1/logout1이며 region976×0·API200/65 관찰을 보존한다. **공식 링크·전화 href 단언에는 미도달**, 최초 실패 원인은 unknown이다. 새 source PASS로 당시 실패를 PASS로 바꾸지 않는다.
- cold-direct/warm-parking 4개 관측은 x64 first-ready1000/501ms, ARM5048/3999ms 등으로 기록됐고, 원래 정상 운영의 지속0-height는 같은 loopback controls에서 재현되지 않았다. ARM fixture CPU1/1GiB/pids192·SSH tunnel과 x64 native의 자원/네트워크 제한 동등성은 미확립, 산출물도 구분된다. 이는 구간 관찰이지 통계 benchmark·ARM/라이브러리/HTTP cache 원인 확정이 아니다.
- runtime/원본 실패31·진단20의 보존 주장은 hash-bound 인계와 parent 검산으로 읽었다. 이 bounded 소스 리뷰에서 모든 운영 원본 member를 다시 읽거나 정상 로그인·원격 API를 재실행하지 않았다. raw secret/운영값을 새 보고서에 옮기지 않았다. 새로운 source의 실제 지도·연락처 수용은 별도다.

## 명령·own evidence·판정 한계

- 직접 수행: manifest/factual refs SHA256, `git show/diff/ls-tree/rev-parse/merge-base` exact source/base, protected mode/OID, 함수/fixture 치환 동등성, 실제 Git tgz→Python tarfile/SRI/lock/member 검산. **source/index/branch 편집·install/test/build/browser/server/운영/Docker/API 호출0**. 상대 CURRENT 보고서 경로 열람0.
- 조사용 메타데이터 읽기 스크립트의 두 KeyError(`head` 대신 `source`, optional package `exports` 부재)는 재조회해 정정했고 제품/테스트 실패로 합산하지 않았다. source 실행 시도는 없었다.
- evidence `review-B-transport-rail-server-frame-bf93-source-1-evidence/verification.json` SHA256 `8db2ceb79d2707ebe2cdfbaed0e0151a214c5b707fbd6d3a5905e7ac6ca06a40`; 7경로 diff·원본 줄 번호·동봉 SSR 경계 hash·명령·evidence index 보존.
- **Native/Alpine43·before-old SSR red proof·새 실제 COPY297/bytes·backend CI 완료·원 리뷰어 execution/CI closure·새 merged M ARM image/official apply/actual9는 PENDING**. SOURCE PASS는 이 단계들을 승인하지 않는다. 기존 원문을 보존하며 Common/Geo publication HOLD와 Map 운영 제외를 유지한다.
