# Independent A — PR185 rail server frame bf93 SOURCE1

- Run A-TR-RAIL-SSR-BF93-SOURCE1-20261112; UTC source audit 2026-11-12T09:31:44.210100+00:00 → 2026-11-12T09:33:16.717544+00:00; original frontend/accessibility reviewer A/Mill, 구현 비참여, peer CURRENT 원문/결과 열람0.
- Manifest SHA256 **759f210a69842147aad34a8880d021b1f890656a76c6839bb29a2958f162f4e1** 직접 일치. 참조8개 파일과 candidate의8개 Git blob SHA256/bytes 전부 일치.
- Exact HEAD **bf937d1cb79b06c8da2ffb8c24b42e8c527f5995**, tree **6d3d2b5aa20b50aee798ebaeb0c38377d7859ec5**; base **88566f7d16c3bb1b497d3ce0c4869c43d6d51844**. 관찰 checkout 동일/추적 파일 clean. 비교는 parent commit 하나가 아니라 manifest base→exact head union7paths이다.
- **BOUNDED SOURCE PASS / 신규 findings0 (P0/P1/P2/P3 각0)**. 새 source의 native/Alpine43, before-oldSSR red proof, 전체 backend CI, merge/ARM/apply/actual9 수용을 승인하지 않는다.

## Product / SSR / UX attacks

- **general-rail-guide.tsx:13, :31–45**: next/dynamic import와 ssr:false wrapper를 제거하고 기존 TransportMap named import를 추가한 결과가 새 파일 전체와 byte-identical임을 확인했다. 그 외 hook/JSX/props/handler bytes는 동일하다. 기존 app/map/page.tsx:2도 같은 TransportMap을 static import하므로 기존 서버 평가 경로와 맞춘 변경이다.
- 초기 HTML에서 지도 region 내부 `.map-workbench`/공통 MapWorkspace와 MapViewTabs가 생성되는 방향이 타당하다. globals.css:582–600의 `:has(.map-workbench)`/부모 유한 높이/남은 높이 전달은 unchanged이며, 이제 client-only child 도착 전에 해당 selector의 구조 조건을 제공할 수 있다. 실제 desktop/mobile 높이는 source만으로 확정하지 않는다.
- GeneralRailGuide 초기값은 places=[]/selected=null/view=map; transport-map.tsx:154–156의 embedded=true는 initialMapCamera(:504–511)에서 window/URL 접근 전 반환한다. 따라서 이 경로의 서버/첫 client snapshot이 URL query에 따라 달라지는 새 차이는 보이지 않는다. GeneralRailGuide의 window.location.assign(:29)과 geolocation은 사용자 이벤트 안이고 API fetch/AbortController 수명은 effect 안이다.
- TransportMap의 DOM 측정/focus/observer 및 VWorldMapView의 new maplibregl.Map은 effect/handler 안이다. 실제 vendor VWorldMapView:83–113, :174 이후, :455–471을 확인했다. MapStore는 초기 map=null/loaded=false이고 hooks의 useMap/useMapLoaded에는 null/false server snapshot이 있다. 화면 스켈레톤과 프레임을 SSR해도 WebGL·실제 타일 데이터·지도 조작 가능 상태를 SSR한다는 뜻은 아니다.
- module scope의 public VWORLD_KEY 판독과 setWorkerUrl(:61–63)은 기존 TransportMap과 동일하다. 새 worker/SDK 엔진을 만들거나 별도 key/auth 처리를 추가하지 않았다. 이 확인은 DOM 없는 환경에서 실제 maplibre 모듈을 import한 재현 테스트가 아니다. server import 안전성의 실행 결론은 정확 build/NoJS 및 hydrated browser 증거로 별도 확인해야 한다.
- 로컬 static runtime import graph48개를 읽어 새 TransportMap edge를 추가했을 때의 순환 경로를 공격했다. Guide→StationDetail→Journey→Guide 순환은 **기존 그대로** 존재하며 함수 render 시 참조한다. 새 map edge를 제거한 그래프에서도 같은 순환만 남고 map으로 되돌아오는 새 cycle은 없다. regex 기반 로컬 import 검사는 전체 bundler/동적 import/외부 패키지의 형식적 순환 증명이 아니다.
- **성능 한계**: dynamic chunk 경계를 없애므로 Guide/Journey를 포함하는 route에서 MapLibre/VWorld 관련 코드가 초기 정적 그래프에 포함될 수 있다. /rail뿐 아니라 닫힌 timetable의 guide toggle 경로도 대상이다. 새 bundle 크기/초기 JS·TTFB·hydration 비용을 측정하지 않았으므로 성능 영향0 또는 개선을 주장하지 않는다. 이 변경의 선택은 초기 프레임을 보장하려는 tradeoff이며 실제 빌드 chunk/새 이미지 QA에서 확인할 사항이다.
- 선택 provider identity/markerIds/ref, request key/abort, 검색·권역·위치 필터, map/list controlled state, focusRevision, details, 출발·도착 intent, 공식/tel href의 업무 코드는 변하지 않았다. 새 child는 초기부터 mount할 수 있지만 embedded 모드이므로 별도 전체 장소 조회로 전환하는 변경은 아니다. 실제 지도 전환·좌표없는 역·상세/초점·경합 수용은 browser 후속 증거가 필요하다.

## Regression oracles / assertion quality

- **transport-map.test.tsx:30–41**는 renderToStaticMarkup(GeneralRailGuide)에서 실제 TransportMap/공통 MapWorkspace와 role=tab2개 및 지도·목록 이름을 검사한다. Common map-controls.js는 실제 Radix Tabs.Root/List/Trigger를 사용한다. 공통 Tabs를 fake role div로 대체한 oracle가 아니다.
- 이 unit은 기존 vworld-map-web/maplibre/map-overlays mocks와 jsdom document를 사용한다. API effect 실행/실제 CSS 높이/DOM 없는 Node 전역 안전성/실제 WebGL/hydration을 증명하지 않는다. 단, client-only wrapper 아래로 프레임이 사라지는 회귀를 DOM 구조 수준에서 검사하는 의미는 있다. 원 transport-map test 파일은 추가 import와 새 test의 **insert-only** 변경이며 기존 단언 삭제0이다.
- **e2e/rail-map-server-frame.spec.ts:4–22**는 javaScriptEnabled=false인 독립 context에서 loopback만 허용하는 helper로 실제 /rail을 HTTP 요청한다. PC1280/mobile375·900높이에서 철도 heading, 정확 region1, boundingBox.height>=320, map-workbench1, 지도·목록 role tab의 실제 가시성을 검사하고 box를 첨부한다. arbitrary wait/단언 timeout 완화/DOM·CSS 주입/height stub이 없다.
- NoJS 검사는 initial frame이라는 목적에 맞다. 높이만 있는 빈 placeholder로 통과시키지 않고 workbench+실제 tabs가 필요하다. 다만 NoJS 상태에서 탭 클릭/키보드 전환이나 지도 완성/후속 연락처 href를 검증하지 않으므로 이를 interactive/production acceptance로 확대하지 않는다. min width·모든 breakpoint·짧은 viewport·지도 상세 클릭은 기존+후속 JS QA 범위다.
- **general-rail-station-intent.test.tsx:16**의 mock prefix만 next/dynamic→실제 ./transport-map named export로 바뀌고 나머지 파일 bytes는 동일하다. **rail-search-state.test.tsx:9–11**은 기존 MapFixture 함수 bytes를 그대로 꺼내 function declaration으로 두고 dynamic mock(기존 Metro용)과 static map mock(GeneralRailGuide용)이 같은 함수를 공유한다. 함수 선언은 hoisting 가능하며 fixture와 기존 단언 전체가 보존됐음을 exact reconstruction으로 검증했다.
- NoJS helper는 origin/loopback을 검증한 뒤에만 fixture cookie/routes를 설치하는 기존 파일 그대로다. 서버 region 구조를 확인하기 위한 격리 조건이며 운영 cookie 위조/새 로그인/실API 재현을 수행한 것이 아니다. SSR에서는 Guide의 클라이언트 effect가 실행되지 않으므로 실65건을 server render로 채웠다고도 주장하지 않는다.

## Provenance / history / pending

- 변경7paths 외 소스·CSS·menu·deps·locks·vendor·public/backend/auth/schema/key 경로는 git diff에 없다. 정상 blobs908/gitlink1, source908/COPY297/common263은 candidate의 선언/기대치이며 이 source 리뷰에서 실제 새 컨테이너 COPY/설치 파일/compiled32를 실행 감사하지 않았다. UI/VWorld tgz의 base/head bytes 동일 및 exact JS 열람을 확인했다.
- docs2는 기존 본문 전체를 suffix로 보존하며 새 진행 상황만 추가한다. 최초 M885/image5ffe49 정상 세션 **8PASS1FAIL**, 별도 contact diagnostic **FAIL**, region **976×0**, API200/65, href 단언 미도달을 두 고정 receipt에서 확인했다. 이번 소스 PASS는 이 실제 실패를 FIXED/actual9PASS로 바꾸지 않는다.
- cold/warm4관측은 별도 synthetic fixture 결과다. ARM cold first-positive5048ms/last-zero4001ms를 원5000ms 안의 성공으로 바꾸지 않았고, warm을 HTTP cache hit로 보지 않는다. CPU1/memory1GiB/pids192 대 native/네트워크 제약 비동등 addendum이 있어 ARM 아키텍처·library·CSS 또는 최초 운영 실패 원인을 확정할 수 없다. 최초 원인 **UNDETERMINED**를 보존한다.
- 고정 CI checkpoint: CI43190718380 admin453/public164/type/lint/build/Doctor0, policy43190719014 bothSUCCESS. 실제 checkout9d6c3f140301aa43c59dccc5937baa5b5ebdbb13의 local Git tree가 exactbf93과 같음을 검산했다. **backend job131089025654 RUNNING_NOT_PASS, liveE2E SKIPPED_NOT_PASS**. API 최신 상태를 새로 조회하지 않았으며 snapshot의 범위이다.
- candidate.json의 PROTOTYPE/NOT_PUSHED/testpending status는 당시 초기 producer snapshot이고, 후행 CI checkpoint와 구분한다. source manifest에 명시된 native/Alpine43 및 old SSR red 증거는 **PENDING/본인 NOT_RUN**. 메타데이터의 기대 수치/green frontend를 새 browser PASS로 대신하지 않는다.

## Evidence / commands / disposition

- Evidence **review-A-transport-rail-server-frame-bf93-source-1-evidence/**: verification.json, candidate.patch, local-import-graph.json, 관련 exact source numbered.txt, map-controls/VWorldMapView/mapStore/index/hooks packed text.
- Commands: git show exact:paths; git diff --name-only/--no-ext-diff --unified=6 **M885→bf93**; git diff --check(exit0); git ls-tree -rz; git rev-parse source/CI-synthetic^{tree}; status; Python SHA256/length/문자열 역복원·fixture 동일성/insert-only 단언 검사/로컬 static graph; 메모리 tarfile 읽기. 새로운 install/build/test/server/browser/login/운영접속/Docker/Map ops0; 소스/index/branch 변경0; peer CURRENT 열람0.
- **SOURCE PASS / new0**에 한정한다. 이전 drawer/source/실행/CI 원문 모두 그대로이며 PR185의 정확 실행·CI·동일 원 리뷰어 후속 확인 전 merge 최종 승인 아님. 새 merged M image/ARM263·공식 관리자 단독 apply·원 actual9 전체 수용·Common/Geo publication HOLD 해제는 별도 후속 게이트다.
