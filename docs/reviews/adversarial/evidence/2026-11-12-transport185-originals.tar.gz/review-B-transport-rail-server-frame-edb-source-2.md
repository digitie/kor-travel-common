# 원 B Transport Rail server frame edb SOURCE2

- 원 리뷰어 B(Epicurus), runid `B-RAIL-EDB-SOURCE2-20261112T095910Z`, UTC `2026-11-12T09:59:10Z`. 구현 비참여·상대 CURRENT 원문/결과 접근0.
- **SOURCE PASS / 신규 finding 0건.** bf93 SOURCE1 PASS 원문은 불변 보존하며, 새 실행·CI·merge·운영 수용 승인은 부여하지 않는다.
- manifest `review-manifest-transport-rail-server-frame-edb-source-2.json` SHA256 `5ccb5aceeff4f87c1ceedab206649aaee3dba93123c4388ad8aae355d1ba6f60` 및 명시15 refs 직접 일치.
- exact head `edb6538209d5fc2d1b64e001af971dfc0e82ea55`, tree `7ffb15929c7b8de0e48555312797fc66aa47ed58`, 부모 bf937d1, review base M `88566f7d16c3bb1b497d3ce0c4869c43d6d51844`.

## 제품·SSR·API·초점 의도

- `frontend/components/general-rail-journey.tsx:96`의 **수동 initialDepartureName 분기만 revision1→0**이다. 주석을 제외하면 이 값 하나의 치환만으로 bf93 원문과 정확히 같다. `initialStationIntent` revision1, `intentRevision` 증가 재지정, 명시적 departure/arrival 처리, 선택 초기화·request clearing·실제 역 ID 확인·API/검색·조회 gate는 그대로다.
- unchanged `rail-station-picker.tsx:19–23`은 revision0이어도 `searchRequest.text`를 입력값으로 보존하고, `revision && !disabled`일 때만 자동 focus한다. 따라서 passive prefill은 catalog 활성화/상세 재마운트 뒤 focus를 가져가지 않고, 명시적 intent 및 같은 역 재지정은 기존 양수 revision으로 안내한다. 초기 검색어를 실제 station 선택으로 승격하거나 자동 timetable 호출을 허용하지 않는다.
- SSR 경계는 유지된다. 새 변경은 window/document 접근을 render/init에 추가하지 않고 기존 Picker effect의 초점 요청 조건만 조정한다. bf93의 static TransportMap·SSR unit·No-JS bbox E2E·기존 fixture 몸체는 모두 raw OID 동일이다. 일반 import의 app chunk/프레임 효과는 기존 SOURCE1 범위로 연결하며, 실제 Node/No-JS 실행 PASS로 확대하지 않는다.

## 새 회귀와 증거 의미

- 새 `general-rail-focus.test.tsx`는 실제 **GeneralRailJourney→RailStationPicker→FilterCombobox/Common Combobox**를 사용한다. mock은 API/catalog·날짜·지도 Guide 버튼과 DOM 부대 기능에 한정된다. Common Picker 자체나 focus 함수를 no-op으로 바꾸지 않았다.
- deferred catalog Promise를 해제하기 전 상세에 focus를 두고, 해제 후 입력 enabled/이름 유지/상세 focus 보존/조회 disabled/자동 timetable 요청0을 검사한다. compact false/true 각각 list/map key 재마운트를 포함한다. 명시적 departure/arrival 및 동일 역2회 재지정은 실제 입력 focus를 기대하는 양성 대조3개다. 무조건 focus 삭제를 통과시키는 검사가 아니다. unmount·global/scroll mock 복구도 있다.
- 원 B가 hash-bound before raw **2 FAIL/3 PASS**, after raw **5 PASS**를 직접 읽었다. after-result의 journey/test SHA256이 exact edb Git bytes와 일치한다. **이 5개는 부모의 집중 실행 증거이며 원 B 재실행0**이다. jsdom 효과/초점 회귀로서 의미가 있으며 모바일 브라우저·ARM/운영의 모든 지연·focus 복구를 보장하지 않는다.
- 관찰 하네스 원 target은 assertion 자체 PASS였으나 이후 **967ms 상세→1161ms 출발역** focus가 기록됐다. 처음 수집0 선택식 오류도 docs에 남아 있다. 별도 관찰로 원 Alpine5000ms 실패 원인이나 M885 region0 원인을 확정하지 않는다. bf93 native43 PASS/Alpine42 PASS1 FAIL, 운영8P1F/추가 contact FAIL 원문은 보존한다.

## 불변 경계·실행 한계

- base 대비 union **9 paths**, bf93 대비 **4 paths(제품1/new test1/docs2)**; head909 blobs + gitlink1, 기존 보호298 mode/OID 동일. 후보9개 Git blob 길이/SHA256 모두 일치. root/backend/public/auth/keys/DB/CSS/package/lock/vendor/data gate는 이 diff에서 바뀌지 않았다.
- Common263 기대 bytes와 SRI/lock은 원 B SOURCE1 검산에 연결한다. 이번에는 동일 vendor subtree·lock·ledger OID를 재확인했으며, 라이브러리 재pack/소스·license/API 변경 없음이다. **COPY298·compiled32는 이번 exact 실행의 기대 수**이고 owner의 현재 fullQA/CI/ARM cache 진행 상태를 PASS로 쓰지 않는다. 이전 COPY297/43 결과를 edb 결과로 전용하지 않는다.
- 기존 실제 M885/image5f는 입력의 운영 기준이다. 원 B 운영 접속·신규 로그인·test/build/install/browser/CI API/Docker/merge·source/index/branch 변경0. 실제 새 M image/apply/normal9 및 exact 실행/전체 CI는 별도 후속 필수다. Common/Geo publication HOLD, Map 운영 제외 유지.
- source1 원문 SHA256 `acabb2bb3643bb5b57ecbf61cd0d4af8c18f35475526e51ea016ba2504d0925a` 동일. 명령은 manifest hash·git show/diff/ls-tree/rev-parse와 순수 hash/치환 검산뿐이며 전체 소스/실행 재감사를 반복하지 않았다.
- own evidence `review-B-transport-rail-server-frame-edb-source-2-evidence/verification.json` SHA256 `d3fefc3a6ad90e906949a786a29273a09d8d0fa733fee92458cba94032a37629`; 4경로 delta/9경로 union diff·hash/보호·SSR/library bridge·명령/evidence index 보존.
