# Independent A — PR185 edb bounded SOURCE2

- Run A-TR-RAIL-EDB-SOURCE2-20261112; UTC 2026-11-12T09:59:54.919305+00:00 → 2026-11-12T10:00:50.407767+00:00; original A/Mill frontend/accessibility, 구현 비참여/peer CURRENT 열람0.
- Manifest SHA256 **5ccb5aceeff4f87c1ceedab206649aaee3dba93123c4388ad8aae355d1ba6f60** 일치. 참조15개·candidate Git blob9개 SHA256/bytes, observer frozen13개 해시 직접 일치.
- Exact **edb6538209d5fc2d1b64e001af971dfc0e82ea55**, tree **7ffb15929c7b8de0e48555312797fc66aa47ed58**; base M88566f7d16c3bb1b497d3ce0c4869c43d6d51844 union9paths 직접 검증. 관찰 checkout exact/추적 파일 clean.
- **BOUNDED SOURCE PASS / 신규 findings0 (P0/P1/P2/P3 각0)**. 앞선 focus-analysis의 passive focus 분리 권고는 **FIXED(source + handed-off targeted unit evidence)**. 원 bf93 SOURCE1 원문 및 advisory 원문은 그대로 보존한다.

## Own source / UX assessment

- **general-rail-journey.tsx:95–96**의 제품 delta는 주석1줄과 passive initialDepartureName의 revision1→0뿐이다. bf93 파일에 이 두 치환만 적용한 bytes가 edb 파일 전체와 같음을 검산했다. 명시적 initialStationIntent revision1·intentRevision ref1·requestStation의 ++revision 및 반대역/날짜/차종/요청 취소 경로는 동일하다.
- **rail-station-picker.tsx:15–23**에서 revision0도 유효한 검색어 상태다. input fallback은 searchRequest.text를 유지하고, revision truthiness가 필요한 것은 focus effect뿐이므로 이름 자동 채움/검색 안내를 없애지 않는다. 실제 station_id 자동 선택이나 자동 조회를 추가하지 않았다. 값 선택·삭제 시 동작도 그대로다.
- 이 분리는 상세를 열거나 map/list 후 compact Journey가 재mount되어 catalog가 늦게 준비될 때 **passive 입력이 새 focus를 요청하지 않게 하는** 올바른 UX다. 명시적인 출발·도착 지정은 기존 양수 요청을 통해 사용자를 picker로 안내한다. app/rail/timetable/page.tsx:6의 legacy departureName과 guide_role/guide_id/name intent 분리도 그대로다.
- **general-rail-focus.test.tsx:42–54**는 실제 GeneralRailJourney/RailStationPicker/FilterCombobox와 공통 Input/Popover를 사용한다. Picker·포커스 effect를 mock하지 않는다. deferred catalog 앞에서 detail을 실제 focus하고, resolve 뒤 enabled/input value=서울/detail focus/조회버튼 disabled/시간표 요청0을 검사한다. compact false/true 각각 keyed list→map subtree 재mount를 반복하므로 단순 fixture return-value 검사가 아니다.
- 새 test:56–63의 departure/arrival positive controls는 동일 지연 조건에서 대상 actual input focus·반대역 empty·조회 금지를 검사한다. :65–76은 같은 이름 두 번 재지정에도 새 요청이 focus를 주는지 확인한다. `initialDepartureName` focus를 모두 없애며 intent까지 우연히 무력화한 패치를 통과시키지 않는다.
- 지연 catalog는 실제 promise로 gate되고 UI disabled→enabled 이후 focus를 확인한다. ResizeObserver/matchMedia/scrollIntoView stub은 jsdom 부재 API를 위한 것이며 focus 상태·Picker를 가짜로 만들지 않는다. Guide는 intent callback 공급자만 mock한다. keyed aside remount는 actual MapTabPanel/지도 렌더·geometry/hydration을 직접 실행하는 통합 browser oracle는 아니므로 새 exact full QA가 필요하다.
- 기존 **bf93 SSR import 수정·SSR unit·NoJS E2E·기존 intent/search tests 5개** bytes가 모두 동일하다. 새 Journey 수정은 브라우저 전역 접근/서버 fetch를 추가하지 않고 서버·첫 client의 passive revision0 초기값이 일치한다. 앞선 SSR/실제 CommonTabs 검토를 유지하며 새 NoJS·hydration 통과를 부여하지 않는다. bundle 비용 미측정 한계도 동일하다.
- Union9 밖 제품/공통 CSS/menu/deps/locks/vendor/public/backend/auth/key 변경 없음. 실제 Picker/FilterCombobox·package/lock·common-artifacts·globals CSS가 bf93과 동일함도 직접 비교했다. source909/COPY298/common263/compiled32는 candidate 기대치이며 본인이 새 실제 image/설치 bytes를 감사한 결과가 아니다.

## Evidence / historical failure boundary

- 제공된 before.log는 **2FAIL3PASS**: passive compact false/true에서 expected aside / received input 오류이고 explicit departure/arrival·재지정3건은 통과한다. after.log/result는 **5PASS/exit0**이고 source SHA cc192a39aaf1d5a16125d992d1575dd750e197356314437117b32c2dafe4ce57 및 test SHA b61008c3f97f15749c75e9d969c61984929e2ca622395ed7e8c09f3dd21b3a16이 exact edb Git blobs와 일치한다. 본인 재실행은 하지 않았다. 이 targeted 근거를 전체 unit/browser/CI PASS로 확대하지 않는다.
- Frozen observer 원문에서 **bf93 target 자체는 PASS**, 주소 이동 후 focusin **967ms ASIDE 상세 →1161ms INPUT 출발역**을 직접 읽어 확인했다. 따라서 assertion 시점 통과와 나중의 focus 유지가 다를 수 있다는 별도 관찰은 실재한다. 최초 collector 선택식 오류0건 기록은 docs에 남고, 교정된 단독 target을 첫 실패의 재판정으로 쓰지 않는다.
- **최초 Alpine42PASS1FAIL 원인과 M885 운영976×0 원인은 UNDETERMINED 유지**. 별도 observer의 late-focus 재현과 두 unit red를 원래 실패 시점의 causal trace로 바꾸지 않는다. M885/image5f 첫8PASS1FAIL·별도 contactFAIL·href 미도달·resource-confounded cold/warm 이력도 보존한다.
- docs2는 전체 bf93 본문을 suffix로 유지하고 위 경계와 새 진행 상태만 앞에 추가한다. 새 fullQA/CI/ARMcache는 현재 입력에서 **IN_PROGRESS/PENDING, not PASS**. 운영 runtime은 기존 M885/image5f이며 본 소스 판정은 실행/merge/apply/actual9 승인 아님.

## Commands / limits / frozen outputs

- Evidence: **review-A-transport-rail-server-frame-edb-source-2-evidence/** verification.json, union.patch, postfix.patch, exact Journey/Picker/FilterCombobox/new test numbered.txt.
- Commands: git show exactedb paths; git diff M885→edb 및 bf93→edb; git diff --check(exit0); rev-parse tree/HEAD 및 tracked status; Python SHA256/bytes/exact reconstruction·preserved SSR comparisons; frozen observer/원 unit logs read-only 파싱.
- Own evidence parser 최초에는 raw 시간 필드를 ms로 가정해 assert로 중단했다. 실제 스키마 browserMs를 확인한 뒤 검증을 완료했다. 제품 test 실행/실패나 새로운 observer run이 아니며 이를 raw red로 세지 않는다.
- 본인 source/test/index/branch 편집0, install/build/test/browser/auth/운영접속/Map ops0, peer CURRENT 원문/결과 열람0. 원 SOURCE1 SHA362f71ec09426cf88ef1614a446108042b3de0ea74336015e8b118ef133bacf3 및 focus-analysis SHA1d93557bfca086d4ecb8e457a4b0ae56b4c7ca5e479207487fe5ee6d813d98b5 불변 검산.
- 다음 gate: 정확 edb 전체 실행·CI 및 같은 원 리뷰어 확인→실제 merged M/image·ARM bytes→공식 apply→원래 실제9개 전체 정상 수용. Common/Geo publication HOLD 해제는 별도이며 이번 SOURCE PASS에서 선승인하지 않는다.
