# Independent A — PR185 exact edb bounded EXECUTION3

- Run A-TR-RAIL-EDB-EXEC3-20261112; UTC 2026-11-12T10:20:17.710196+00:00 → 2026-11-12T10:22:14.635204+00:00; original A/Mill frontend/accessibility, 구현 비참여, peer CURRENT 열람0.
- Manifest SHA256 **0aaf771e908d289e558cc492ace744c1fffcbd707617b29037a82a3e4218584d** 일치. Source **edb6538209d5fc2d1b64e001af971dfc0e82ea55**, tree **7ffb15929c7b8de0e48555312797fc66aa47ed58** Git 직접 일치; 관찰 checkout 동일/추적 파일 clean.
- Verdict **BOUNDED FRONTEND EXECUTION PASS / 신규 findings0(P0/P1/P2/P3 각0)**. 새 source QA를 지지하나 backend CI pending·ARM release·merge·apply·실제9개 수용 승인 아님.
- Own source2 PASS/focus 분리 검토는 **source + bounded 실행 근거로 유지**. NoJS 초기 프레임과 지연 catalog passive focus 회귀가 새 정확 소스의 실행으로 연결된다. 원 SOURCE2 SHA256 fb1261674577f012abc7a75ea24d6509be20f6f1572d13fdc2574ef648ee6aec 불변 검산.

## Corrected bf9 observation accounting — 향후 공개 원장 기준

- 최초 bf9 Alpine focus **1FAIL**과 별개인 **추가 관측 target 실행은 합계2회**다. collector는0건이며 제3의 target 실행으로 세지 않는다. 새 edb86건도 이 이전 관측 수에 섞지 않는다.
- Worker R2 **2026-11-12T09:46:43.895Z**, 원 target1PASS, 주소 클릭 후 상세 focus1034ms → 출발역 input1179ms. frozen16개 SHA/bytes/mode 및 raw browser focusin을 직접 확인했다.
- Parent **2026-11-12T09:52:38.062Z**, 별도 원 target1PASS, 상세967ms → 출발역1161ms. 기존 frozen13개의 해시·길이를 source2 manifest의 고정 index와 재검산하고 두 startTime이 다른 실제 실행임을 확인했다.
- Parent takeover 시 worker R2 결과가 인계되지 않아 parent가 관측을 중복 실행한 사실을 addendum이 명시한다. **global once-only/no-extra-observation 주장은 유효하지 않다**. source2가 기술한 parent의1회는 그 로컬 관측 기록으로 보존하며 원문을 재작성하지 않는다. 최종 Common/Geo/PR의 전역 사실 집계에는 추가 관측 **2회**를 반영해야 한다.
- 두 관측의 순간 target assertion PASS 뒤 late focus 이동은 각각 보존한다. 최초 Alpine 실패 당시 focus timeline은 없으므로 최초 원인은 계속 **UNDETERMINED**다. M885 운영 height0·8PASS1FAIL/contactFAIL도 소급 PASS로 바꾸지 않는다. 이 진단들에서 production login0/다른42건 반복0을 유지한다.

## Exact-edb QA / assertions

- QA final-receipt SHA256 **c3c572c1b427c6b4654f496d93cdfdfe3d47881eb3539c349962dd6b2bfe470d** 및 frozen100개 SHA256/bytes/실제 mode 전부 직접 일치. 최종 receipt는 원 bf9 실패·collector0·R2·parent·운영 실패 영수증을 hash로 보존하며 재채점하지 않는다.
- 원 Playwright **10개 report**를 재귀 파싱: Native43/Alpine43 각각 server-frame2+basic18+review4+private6+menu13. 두 mode의 unique43 case 이름 집합 일치, 각 case result1개/pass/retry0, skip/unexpected/flaky/top-level errors0. workers1/retries0/repeatEach1/test timeout45000ms. 이는 새 edb의 기록상 첫 실행 결과이며 이전 bf9 회복/관측을 재활용한 staged 합산이 아니다.
- Pipeline 원 results13개 step(빌드·canonical 포함) 모두 exit0/step 중복0. 복구나 미실행 group continuation 없이 새 source별 전체 실행이 끝났다. 기존 로그를 읽은 것이며 reviewer가 test/browser를 다시 실행한 결과는 아니다.
- 7 gates exit0, 실제 unit log63files/458PASS, focused4files/30PASS(새 focus5 포함), Doctor0/type/lint/installed+external guard 확인. source2에서 검토한 passive prefill/explicit intent positive controls와 새 전체 QA의 source hash가 연결된다.
- NoJS server-frame 원 JSON attachment를 직접 decode했다. Native/Alpine 모두 width1280에서 box976×832, width375에서351×783, javaScriptEnabled=false. 실제 frame·workbench·지도/목록 tab 단언을 통과한 source 계약이며 WebGL 준비·실제 provider 키/타일·정상 운영 연락처 수용을 뜻하지 않는다.
- 원 주소 지도 이동→detail.toBeFocused case를 포함한 review4가 두 mode 모두 통과했다. 정확 Git original spec SHA256 **8da2a60fa45f37dda21ccad5338289f24f8e65365eac9d8c4e5b5a99f8d5214c**가 QA source receipt/R2 원 spec과 일치한다. 원5000ms focus 단언을 삭제·timeout 완화한 교정이 아니다. 실제 target 순간 통과와 장기 focus 안정성의 차이는 앞선 unit의 강제 지연 regression 및 source0 focus 분리와 함께 평가했다.
- Repo/private configs 및 원 private6 spec은 고정 harness hashes와 일치한다. 원 loopback helper·SSR spec·Picker·focus unit/config를 exact Git SHA와 대조했다. 관측 wrapper는 이전 bf9용이고 새 edb full QA에 같은 diagnostic overlay를 주입한 것이 아니다.

## Bytes / image / cleanup / fixture limits

- source receipt909 blob 경로 집합+gitlink1은 exact Git tree와 일치한다. 전체909개의 live 파일을 reviewer가 다시 읽은 것은 아니며 실제 source/private harness mismatch0은 고정 cleanup proof이다. 중요 source/tests/config SHA를 Git과 별도 비교했다.
- 실제 image-audit JS의 **COPY298 expected hash 전부를 exact Git blobs에 대해 git cat-file --batch로 재계산**해 일치했다. common263 expected hash 전체도 exact6 tgz의 bytes/SRI/lock 도달 경로 및 tar 내부 파일로 재구성해 동일함을 확인했다. 실제 원 stdout은 copy298/common263 mismatch0/routes32/rail·parking-lots·timetable true/exit0이다.
- 새 QA builder image **sha256:a27d2aa60eeff62804792da1922252d6a5592f9f6a758d8b2f651eda37361995**, OCI source exactedb. Native actual common263와 Alpine 실제263 비교 및 native compiled32 proof가 존재한다. 이는 격리 fixture x64/Alpine 검증이며 **ARM production release image가 아니다**. Reviewer는 실제 container를 새로 열어 감사하지 않고 실행 결과와 소스 bytes 연결을 확인했다.
- SDK를 쓰는 map QA도 fixture key/loopback/mock data 조건이다. console·tile fixture 메시지나 이미지 fixture의 정상 동작을 운영 provider/API/auth 수용으로 확대하지 않는다. 원 hardcoded domain screenshot 파일명 재사용의 최신 bytes만 보존된 한계가 있어 모든 mode별 과거 PNG가 별도 남았다고 주장하지 않는다. 본 검토는 새 독립 시각 QA를 수행하지 않았다.
- 최종 cleanup proof: ownProcesses[]/fleetBrowserPIDs[]/runnerExit0, native1930480 inactive·port53771 closed, Alpine fixture stopped·port32788 closed. Pipeline cleanup native exit143은 종료 처리 기록이고 test pipeline exit0과 구분된다. 운영 login/SDK apply/DB/Map 변경0은 이 QA 범위의 기록이다. 실제 운영의 모든 과거 입력이 불변이었다는 전역 주장으로 확대하지 않는다.

## CI boundary / frozen evidence

- Front checkpoint는 CI43195806562 admin458/public164/type/lint/build/Doctor0 및 policy43195808014 양쪽 PASS. 실제 synthetic checkout **4d9bcf93fdd38f1e593de376521359cb994518ef**의 local Git tree가 exactedb와 같음을 직접 검산했다. **backend131106341751 RUNNING_NOT_PASS / liveE2E SKIPPED_NOT_PASS**. API 최신조회는 하지 않았고 final exactCI closure를 별도로 받아야 한다.
- Evidence: **review-A-transport-rail-server-frame-edb-execution-3-evidence/verification.json** — own manifest refs(peer archive 제외), QA100/worker16/parent13 hash 검사, 86 cases/stats, NoJS decoded box, COPY298/common263, 원 영수증/cleanup/보정 관측원장 포함.
- Commands: Python SHA/bytes/mode·Playwright JSON/attachment 파싱; git show/ls-tree/rev-parse/status; git cat-file --batch COPY SHA; 메모리 tarfile/SRI/lock 검증. Static evidence parser가 JS const 구분자와 parent browser.json 위치를 잘못 가정해 두 번 중단한 뒤 정확 스키마로 교정했다. 제품 실행 실패·추가 QA run이 아니며 source 수정도 없다.
- Reviewer source/test/index/branch 편집0, install/build/test/browser/운영접속/auth/Map ops0, peer CURRENT 원문/별도 counterpart source 원문 읽기0. **EXECUTION PASS에 한정**하며 최종 exactCI→merge M→실제 ARM image/bytes→공식 apply→원 actual9 전체 수용·Common/Geo 출판 HOLD 해제는 별도 gate이다.
