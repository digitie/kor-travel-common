# Manager591 Transport PUBLIC+ADMIN 독립 소스 리뷰 A — e533820

판정: **COMBINED PUBLIC+ADMIN SOURCE PASS**. 신규 P0/P1/P2/P3 각 0건. e533의 등록된 두 UI 선택 및 revision ENV 결합 기능에 대한 판정이며, 새 UI 이미지·실제 운영/DB/API 수용 승인은 아니다. exact backend CI 전체 테스트는 관찰 당시 진행 중이다.

- runid: A-MANAGER-TRANSPORT-COMBINED-E533-20261112-01
- 시작 UTC: 2026-11-11T22:51:44.101085+00:00; 완료 UTC: 2026-11-11T22:57:27.933244+00:00
- 원 독립 리뷰어 A/Mill. 구현 비참여, CURRENT peer raw/verdict 미열람. root 앱 source 변경·install·배포·실호스트 호출·운영 Docker mutation·repack 없음.
- packet `validation/review-manager-transport-ui-route-e533820/manifest.json`, 직접 SHA256 **79d7253d54a071a4749873beed2c043d52873cf11eb12b26c1978473263b1fd5** 일치. forwarding JSON도 함께 확인했다.
- base **ca1d32b05f7a8418708bdd4f84449d79df57a102** → head **e533820112372fb2f23982265b7a9575db7a0431**, tree **98f2fefd9349dc0538ca8cd5b4e250ab84b2dc77**.
- 이전 **478a077**은 PUBLIC ONLY checkpoint이며 그 원문/CI를 이번 combined 승인으로 사용하지 않았다. 이번 원문도 별도 보존한다.
- 공유 Manager worktree는 시작/종료158db1/clean으로 대상과 달랐다. Git object와 own `/tmp/review-A-manager-transport-ui-route-e533820` exact archive에서 검토/시험했다.

## 불변 입력·변경 범위

실제 diff10개 경로가 manifest와 같다. 각 base/checkpoint/head의 존재하는 blob ID·SHA256·크기와 packet snapshot 바이트를 실제 Git object에 대조했다. proof12개도 지정 hash/크기를 전부 검증했다. 기존 tracked **473 entry**는 mode/type/blob 동일하다. config의 기존 lifecycle target/컨테이너/서비스·core/admin 그룹 layout을 늘리지 않는다.

새 runtime Python은 CLI/registry/component candidate **3파일**이다. 공통 `_apply_current`가 있는 service_release_candidate.py와 Compose·G·pin registry는 base와 같다. frontend/의존성/lock/C11 산출물·기존 Map shared body 변경이 없다. 원 public test8의 checkpoint/head 바이트도 같다.

## 새 선택과 환경 결합의 소스 판단

- CLI는 `apply-component-ui --component admin`만 기존 entry dispatch로 전달한다. 기본 None은 기존 PUBLIC frontend이며 임의 runtime/ENV를 받는 새 인자는 없다.
- registry의 `_component_ui_choice`는 정확 필드·component 이름·중복·UI 이름·같은 release 단일 runtime 소유·oneshot 제외를 검사한다. `components.admin.runtime`은 기존 **transport-admin-web**, group은 기존 **admin**이다. canonical source는 기본 target 선언을 공유한다. gateway/backend/code-server/db/migrate를 새 실행 대상으로 추가하지 않는다.
- 등록된 **TRANSPORT_ADMIN_RELEASE_SHA**만 선택적 source 표식으로 재결박한다. 일반 인증/세션/지도/DB key를 release_env로 등록하는 잘못된 선언은 거부한다. 실제 설정의 허용 key는 이 하나다.
- `_preserve_environment`는 G 안의 현재 raw ENV와 새 이미지 기본값을 읽고, old effective 값 우선 규칙을 유지한다. release_env가 있으면 **이미지 기본 Env 값 == 승인 source_sha**를 먼저 요구하고 해당 key만 새 SHA로 바꾼다. source SHA의 형식·canonical merged source·OCI revision/source URL 검사는 기존 전체 실행 경로에서 함께 통과해야 한다. image ENV만으로 OCI 승인을 덮지 못한다.
- 기존 raw `$` 한 번 인코딩·env_file 제거·frozen stdin, admission/적용 후/발행 직전 환경·current·전체 비선택·health guard는 그대로다. `selected_environment_unchanged`는 명시적으로 승인한 marker와 나머지 기존 ENV 보존을 뜻한다. old image가 여전히 실행 중이면 marker만 먼저 바뀌는 drift도 거부한다.
- 기존 PUBLIC은 release_env=None이며 owner readonly proof의 PUBLIC revision key 목록은 비어 있다. 저는 실호스트를 재조회하지 않고 이 hash 검증된 proof와 실제 코드 경로를 구분했다. PUBLIC에 backend499 revision을 일괄 주입하지 않는다.

등록 ENV의 실사용처도 frozen Transport **936fdb90b0ee9f6392d2f888255053ee1f4066b2**에서 직접 검색/읽었다. runtime 소비는 `packages/kor-travel-transport-admin/frontend/app/api/release/route.ts`의 **인증된 GET 반환 값**이며 `hasAdminSession` 실패401, `no-store, private`다. Dockerfile의 기본 ENV 및 Compose 설정과 연결되고 인증/세션 키로 쓰지 않는다. legacy admin deploy의 전체 checkout rsync 경로는 새 SDK dispatch/_apply_current에서 호출하지 않는다.

## 직접 before/after·SDK 실행

기존 `/tmp/kt-manager-candidate-python` venv를 읽기 재사용하고 own PYTHONPATH·pytest basetemp·존재하지 않는 Docker socket을 사용했다. 새 install/전체 backend 실행은 하지 않았다.

1. **같은 immutable probe 직접 재실행**: 478에서 admin parser exit2, approvedRevision=false/wrongOldRevision=true; e533에서 parser exit0, approvedRevision=true/wrongOldRevision=false. auth raw dollar 보존은 양쪽 true였다. wrapper exit0은 before의 예상 실패를 관찰했다는 뜻이지 이전 admin 수용 성공이 아니다. `own-before-after-probe.json`, raw before/after logs.
2. **전체 SDK+registry503 PASS /skip0 /15.16초**를 직접 실행했다. existing455 + public8 + admin40. exact 모듈/명령은 `own-all-sdk-command.json`, raw 출력은 `own-all-sdk.log`.
3. own 추가 **33 PASS /1.84초**. 실행 전 render와 발행 직전에서 admin 인증/세션/write-token/지도/DB/revision6키 ENV drift12건, 비선택 public/backend/code-server/gateway/db의 mount 실변경10건을 주입했다. 모두 current 발행을 차단했다. render 단계는 up0, 발행 직전 fake up은 admin-web 하나뿐이다.
4. image ENV marker의 대문자/앞뒤 공백·개행·중복·dict·비문자 항목6건을 거부했고, 비문자 component3건과 Map/Pinvi paired를 admin alias로 우회하는2건도 factory 전 단계에서 거부했다. 원40개는 추가로 G contention, OCI source/revision, 잘못된 역할/secret key, after-up 비선택 및 ENV drift를 검사한다.

## 실제 Compose 표현 경계의 own probe

별도 own Unix fake Engine에 **실제 docker compose**를 연결했다. e533 `_preserve_environment`와 unchanged shared escaper로 stdin을 만들고 실제 `/containers/create` 요청 ENV를 관찰했다. 1/2/3/4개 dollar, `$VAR`, `${VAR}`, 한글·따옴표·역슬래시, 빈 문자열·equals·끝 dollar와 새 image default 및 release key, 합계 **12개 raw 값이 기대값과 완전히 같았다**. old release marker만 승인한 새 SHA로 바뀌었다.

fake Engine은 create body 관찰 즉시400으로 멈추며 다른 mutation도 거부한다. 실제 컨테이너 생성0, 실제 Docker daemon 접촉0. Compose **CLI exit1은 이 intentional create-stop**이고 own assertion driver exit0다. 이를 실제 배포 성공으로 계산하지 않는다. 자체 server/socket은 종료·제거했다. `own-admin-compose-fake-engine.py`, `own-admin-compose-probe.log`, `fake-engine-expanded-controls.json`에 합성값만 보존했다. 과거 input3 probe 파일/결과는 수정하지 않았다.

## source·DB·실제 앱 수용의 제한

운영 backend/code source499822601abca3f050aa0cfe0e27fb446d22281d와 DB0042_reference_export_artifacts, 후보 backend0036_parking_statistics_archive의 차이를 없애지 않는다. 새 선택은 PUBLIC frontend 또는 admin-web 하나를 기존 current·현재 Compose·shared images overlay에서 frozen stdin으로 실행한다. backend/code-server/migrate/gateway 및 다른 UI의 image metadata/그룹은 유지하고 새 current도 mixed source로 남긴다. 후보 전체 checkout 동기화·DB migration·backend 교체가 없다.

기존 own478의 정적 PUBLIC api.ts/types.ts 동일 및 proxy 실행 bytes 동일 근거는 같은 Transport936 source 범위로만 유지된다. 이번 registry/Python 변경을 앱 전체 source나 실제 backend 호환 수용 판정으로 확대하지 않는다. ADMIN 앱 GET release 표시와 marker 결합은 직접 읽고 공격했지만, 새 ARM 두 UI 이미지의 실제 login/API/table/map/mobile/logout·DB 운영 전후 수용은 **NOT_RUN/PENDING**이다. production metadata install/apply0, Map operations0이다.

packet의 /tmp 용량 부족 partial run·첫 ARM buildx 활동 디렉터리 실패·owner fixture cleanup 이력은 보존된 별도 실행이다. 이것들을 성공으로 다시 세지 않았다. 성공 근거는 위 exact own503/33와 이후 완료된 owner proof이며, 초기 실패가 실제 제품 source 수정이었다고 추정하지 않는다.

## CI 관찰·검증 명령

GitHub API/job steps와 완료된 frontend/중앙 정책 raw logs를 직접 읽었다. 관찰 UTC **2026-11-11T22:56:02.564Z**:

- exact **43114698062** frontend job130839526863 **SUCCESS**, unit54·browser2/7.0초 및 type/lint/Doctor/build 성공.
- exact **43114698466** 중앙 정책 job130839527928 **SUCCESS**. released policye8ed3ae와 producer/codepin55a921b 경계를 raw log에서 구분했다.
- backend130839526473은 lint 단계 SUCCESS, **전체 테스트 IN_PROGRESS**였다. 전체 CI PASS나 기존478의3939 PASS를 이 head 결과로 가져오지 않는다. 로컬 canonical Ruff0.16.4를 새 설치/실행하지 않았고, packet full-scope canonical Ruff log의 hash와 위 exact lint step을 근거로 구분한다.
- 실제 frontend CI checkout은 synthetic **0ee698d4f69c9d0e584617ccbc12131449d46882**이다. GitHub Git commit API로 parents=[ca1d32b,e533], tree **98f2fefd9349dc0538ca8cd5b4e250ab84b2dc77=head**를 직접 확인했다. 중앙 정책은 exact e533 checkout이다.

```text
git diff / ls-tree -r / show / rev-parse: base/checkpoint/head와 packet 대조
git archive e533820... <필요 경로> → own fixture
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<own>/backend/src DOCKER_HOST=unix:///tmp/review-A-never-contact-docker.sock
/tmp/kt-manager-candidate-python/bin/python -B <immutable combined-route-before-after-probe.py> before|after
/tmp/kt-manager-candidate-python/bin/python -B -m pytest -q -p no:cacheprovider --basetemp /tmp/review-A-e533-sdk-pytest <원10모듈>
/tmp/kt-manager-candidate-python/bin/python -B -m pytest -q -p no:cacheprovider --basetemp /tmp/review-A-e533-adversarial-pytest tests/test_review_A_e533_adversarial.py
/tmp/kt-manager-candidate-python/bin/python -B <own-admin-compose-fake-engine.py>
git diff --check ca1d32b... e533820... → exit0
```

시험 후 새3개 Python·config·shared candidate의 own fixture 바이트가 exact Git source 그대로임도 확인했다. backend/app browser 전체를 다시 실행하거나 타인 cache를 삭제하지 않았다.

## 처분

- 신규 P0/P1/P2/P3 **0/0/0/0**, OPEN finding 없음.
- 신규 registered admin selector와 declared revision 결합: 직접 before/after 및 공격으로 수용.
- 이전478 PUBLIC ONLY와 original raw-dollar/Mount 원 finding closure는 그대로 보존하며 소급 확장/수정하지 않는다.
- **COMBINED PUBLIC+ADMIN SOURCE PASS**. exact backend CI 완료·두 이미지 공식 적용·실제 앱/DB 수용은 별도 gate다.

Evidence: `review-A-manager-transport-ui-route-e533820-evidence/`의 observations/source.patch/own-before-after-probe/own-all-sdk/own-adversarial/own-admin-compose/transport-release-env-references/source-invariants-and-cleanup/direct-github-ci/ci-synthetic-tree-proof를 함께 보존한다. 운영 credential·ENV·raw API 응답은 저장하지 않았다.
