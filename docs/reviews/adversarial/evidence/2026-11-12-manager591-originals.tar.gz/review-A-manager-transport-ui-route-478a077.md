# Manager Transport PUBLIC UI 경로 독립 리뷰 A — 478a077

판정: **PUBLIC UI METADATA SOURCE PASS**. 새 P0/P1/P2/P3 각 0건. 기존 component SDK에 PUBLIC frontend를 등록하는 이 불변 소스 범위의 판정이다. 새 UI 실제 API/인증 수용·DB 검증·admin 선택 승인은 아니다.

- runid: A-MANAGER-TRANSPORT-ROUTE-478-20261112-01
- 시작 UTC: 2026-11-11T22:36:19.955957+00:00; 완료 UTC: 2026-11-11T22:40:50.323261+00:00
- 역할: 원 독립 리뷰어 A/Mill. 구현 비참여, CURRENT peer raw/verdict 미열람. 설치·운영 호출·mutation·repack·앱 source 수정 없음.
- packet `validation/review-manager-transport-ui-route-478a077/manifest.json`, 직접 SHA256 **1d945ce83c9405768807653bc43e72b57b769ba02a22d82b8dbc6bbcbec2e702** 일치. forwarding 입력도 함께 읽었다.
- PR591 base **ca1d32b05f7a8418708bdd4f84449d79df57a102** → head **478a0777339653e08b4ecd40c1111eab862209eb**, tree **495408ed125b47c4777f4525bdc06660cfb514ff**.
- 공유 Manager worktree는 시작·종료 **158db1abad151addcbd75ec2c24fe60ea4f4f449/clean**이었다. 이를 검토 대상으로 오인하지 않고 exact Git object를 읽고 own `/tmp/review-A-manager-transport-ui-route-478a077`에 필요한 경로만 archive 추출했다.

## 불변 입력·변경 범위

실제 base..head 6개 경로와 manifest 집합이 같다. 각 존재하는 base/head Git blob ID·바이트 수·SHA256을 대조하고 packet snapshot 바이트도 실제 Git blob과 일치함을 확인했다. 5개 proof 파일과 실제 baseline manifest의 지정 SHA256도 검증했다. 기존 tracked **476 entry**가 mode/type/blob 그대로다.

제품 변경은 `config/docker-targets.yml:796` 아래 **ui_candidate 3줄**(role transport-frontend, canonical Transport source URL)뿐이다. 신규 테스트8개와 문서4개가 추가/보완됐으며 Python runtime/CLI/frontend/lock/vendor/artifact는 변경되지 않았다. diff와 식별 근거는 `source.patch`, `observations-start.json`에 보존한다.

## role·source·보호 backend 검사

실제 등록 컨테이너에서 transport-frontend → Compose **frontend**, 기존 release catalog에서 **core**가 유도된다. 기존 core/admin layout, core backend/frontend/dagster-code-server와 migrate one-shot, admin 두 역할은 그대로다. 호출자가 임의 runtime 역할을 고르는 새 CLI 인자는 없다.

변경 없는 실제 경로를 읽어 다음을 확인했다.

- `services/registry.py:1133–1159`: role/source_url 정확 필드, UI 역할 형식, 소유 target의 단일 등록 서비스, canonical HTTPS GitHub URL 검사.
- `service_release_component_candidate.py:24–36,89–124`: Map/Pinvi paired 대상 배제, 단일 runtime 그룹, root·정확 SHA·image ID·실행 옵션 검사. `_merged_source`는 G 전/안에서 다시 검사하고, `_compose_plan`의 기존 전체 overlay를 유지한 채 mutation runtime만 frontend 하나로 좁힌다.
- `service_release_candidate.py:303–437`: 현재 모든 이미지와 health, OCI revision/source, selected identity·effective ENV·전체 nonselected·current를 검사한다. frozen stdin과 `up --no-deps --no-build --pull never ... frontend`만 실행하며 적용 후 및 발행 직전에도 검사한다.
- `service_release_cli.py:109–152`: 외부 current의 working_dir/config와 같은 project의 images overlay를 사용한다. 후보 source checkout을 운영 디렉터리로 복사하는 단계가 없다.

이번 metadata가 기존 raw-dollar 보존 및 Mounts 순서만 정규화하는 경로를 수정하거나 bypass하지 않는다. 이전 own source closure 원문은 그대로 보존한다. exact 등록은 **PUBLIC frontend**이며 admin whole-checkout 동기화 문제의 해결이나 admin 승인으로 확대하지 않는다.

## 직접 재현·추가 공격

기존 venv를 읽기 참조하고 `PYTHONDONTWRITEBYTECODE=1`, own PYTHONPATH·pytest basetemp, 존재하지 않는 own DOCKER_HOST를 사용했다. SDK fixture의 fake Docker만 실행했다.

1. 최종 신규 테스트 바이트 그대로인 등록 test에 **base config만** own fixture에서 주입하면 **1 FAIL/exit1**, role/source_url 미등록 오류가 재현된다. 즉시 exact head config 바이트로 복원했고 SHA256 **ea4eaad38fe1f585e4f87316dbf436785fd46de5ccd50f661f775cbf67fa799f**도 확인했다. 제품 source/config worktree를 수정한 것이 아니다.
2. 원 packet의 selected429 + 신규8 =437과 own 추가20을 합쳐 **457 PASS /exit0 /12.37초**를 직접 실행했다. `own-focused-and-attacks.log`, `own-test-command.json`.
3. own 추가20: 실행 전 render/발행 직전에서 backend·code-server·admin-web·admin-gateway·DB 각각의 Config.Env 변경10개를 주입했다. 모두 current 발행이 차단되고 실행 전 공격은 up0, 발행 직전 공격의 up 대상은 frontend뿐이었다.
4. 잘못된 backend/code-server/gateway/migrate 역할 또는 타 target UI 역할6개가 등록 해석에서 거부됐다. OCI source/revision 위조, canonical main에 포함되지 않은 candidate commit, 선택 frontend effective ENV drift4개도 Docker up 이전에 거부되고 current를 보존했다.
5. 원 신규8개는 dry-run/execute 모두에서 여섯 이미지·두 그룹 및 기존 backend revision과 source/schema 표식 보존을 확인하고, 비선택5역할 restart 변경 후 publication을 차단한다. fake schema 파일 표식을 실제 DB 측정으로 주장하지 않는다.

첫 archive 경로 지정에 존재하지 않는 docker-compose 디렉터리를 넣었던 fixture 준비 오류는 실제 tracked docker-compose.yml로 바로잡았다. 첫 XML classname 해석은 tests/tests.py를 잘못 만들어 **0 tests/exit4**였으며 raw attempt 로그를 보존했다. 이를 제품 실패나 PASS로 세지 않고 올바른7모듈 수집과 위457 PASS를 근거로 사용한다.

실행 골격(정확 모듈 목록은 command JSON):

```text
git diff ca1d32b05f7a8418708bdd4f84449d79df57a102 478a0777339653e08b4ecd40c1111eab862209eb
git rev-parse / git show / git ls-tree -r / git archive: exact object와 packet 대조
/tmp/kt-manager-candidate-python/bin/python -B -m pytest -q -p no:cacheprovider --basetemp /tmp/review-A-transport-route-final2-pytest <원7모듈> tests/test_review_A_transport_route_attacks.py
```

로컬 canonical Ruff executable은 발견하지 못해 신규 lint 실행을 PASS로 쓰지 않는다. packet의 canonical0.16.4 raw log는 해시 검증했고 exact CI의 전체 Ruff 성공도 직접 확인했다. packet에 남은 비정본 Ruff0.3.7의210진단은 보존된 다른 도구 결과이며 소스 rewrite나 suppression으로 없애지 않았다.

## DB0042/후보0036 및 PUBLIC API 호환성 상한

실제 baseline manifest SHA256 **b8fc347925a676f3e377c3de770418acef28703fec535dee97445b62c495853a**를 검증하고 읽었다. 배포 backend/code source는 **499822601abca3f050aa0cfe0e27fb446d22281d**, live DB는 **0042_reference_export_artifacts**, 후보 backend source에는 **0036_parking_statistics_archive**가 있다. 다른 newer backend 파일도 있으므로 candidate 전체 bundle source를 동일 운영 기준선으로 간주하지 않는다.

등록된 UI-only 경로는 기존 backend/source/schema·code-server·migrate·admin 이미지를 보존하며 이 차이를 없애기 위한 migration/sync/replacement를 수행하지 않는다. 문서도 전체 bundle schema gate 완화와 UI API 수용을 구분한다. 제가 live DB를 접속하거나 실제 migration/dry-run/apply를 실행하지 않았다.

정적 계약 근거를 별도로 직접 Git 비교했다. 후보 merged Transport **936fdb90b0ee9f6392d2f888255053ee1f4066b2**와 위 live backend source의 `frontend/src/lib/api.ts`, `frontend/src/lib/types.ts`는 **동일 blob/동일 바이트**다. backend proxy route는 추가된 정확한 `//` 설명/Doctor 두 줄만 제거하면 이전 source 바이트와 완전히 같다. 동작 변경은 없다(`public-api-static-proof.json`).

이는 해당 client/type/proxy 정적 계약의 일치 근거이며 모든 backend 응답·데이터·auth·map이 새 UI에서 정상이라는 증명은 아니다. 새 ARM UI 이미지로 PUBLIC UI/API/login/map/health를 검증하는 실제 수용은 **PENDING/NOT_RUN(본 리뷰)**이다. admin whole-checkout 동기화 및 admin UI 교체는 **별도 범위/미승인**이다.

## 정확 CI 직접 확인

GitHub에서 exact head에 연계된 workflow/jobs와 raw logs를 직접 조회했다(`direct-github-ci.json`).

- **CI43111822395 SUCCESS**. backend job130829534925: 전체 Ruff PASS, **3939 PASS /40 SKIP/1 warning /479.31초**. frontend130829535024: **54 unit PASS**, type/lint/Doctor/build 단계 SUCCESS, **browser2 PASS/6.6초**.
- 중앙 정책 **43111822894 SUCCESS**, job130829537354 SUCCESS. producer/codepin55a921b와 released 중앙 policye8ed3ae 경계를 raw log에서 구분한다.
- CI 실제 checkout은 synthetic **0c42c112a2d66d58a455addaa0bd23c1aa41fafa**다. GitHub Git commit API로 parents=[ca1d32b,478a077], tree **495408ed125b47c4777f4525bdc06660cfb514ff=head tree**를 직접 대조했다(`ci-synthetic-tree-proof.json`). synthetic을 문자 그대로 head checkout이라고 기재하지 않는다.

## 처분·한계

신규 P0/P1/P2/P3: **0/0/0/0**, OPEN finding 없음. 알려진 Transport PUBLIC UI 미등록은 direct red→green으로 **FIXED** 확인. 기존 guard·DB/backend 보존과 PUBLIC 선택 범위가 유지돼 **PUBLIC UI METADATA SOURCE PASS**다.

이 보고서는 metadata 설치/운영 apply/실제 API·DB 수용/admin 승인으로 확대하지 않는다. 전체 backend/브라우저를 로컬에서 반복하지 않았고 remote exact CI와 own 집중457을 구분했다. 새 dependency/install/repack 없음. 이전 source 원문과 불변 manifest는 소급 변경하지 않는다.

Evidence: `review-A-manager-transport-ui-route-478a077-evidence/`의 observations/source.patch/own-before-registration/own-focused-and-attacks/own-transport-attacks/public-api-static-proof/protected-backend-boundary/direct-github-ci/ci-synthetic-tree-proof를 함께 보존한다.
