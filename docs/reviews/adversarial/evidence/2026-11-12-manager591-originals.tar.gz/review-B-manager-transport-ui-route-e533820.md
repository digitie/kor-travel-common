# 독립 리뷰 B — Manager PR591 Transport PUBLIC/ADMIN UI 경로

- Reviewer: Epicurus, 원 B / packaging·platform·security·release. 구현 비참여.
- Run ID: Epicurus-B-transport-e533820-20261111T225100Z
- UTC: 시작 2026-11-11T22:51:11Z, 최종 증거 관찰 2026-11-11T23:00:40Z.
- 불변 packet: validation/review-manager-transport-ui-route-e533820/manifest.json
- 관찰 SHA256: 79d7253d54a071a4749873beed2c043d52873cf11eb12b26c1978473263b1fd5
- Forwarding: review-manifest-manager-transport-ui-route-e533820.json
- Repo: kor-travel-docker-manager / PR591
- Base: ca1d32b05f7a8418708bdd4f84449d79df57a102
- Head: e533820112372fb2f23982265b7a9575db7a0431
- Head tree: 98f2fefd9349dc0538ca8cd5b4e250ab84b2dc77
- Verdict: **SOURCE PASS / 신규 finding 0. 원격 CI 두 workflow SUCCESS를 직접 관찰. 실제 Transport 배포·수용은 별도 미검증 gate.**

## 범위와 입력 결박

AGENTS.md / SKILL.md / CLAUDE.md / architecture / decisions의 기존 규칙과 ADR-60 component 원칙을 적용했다. 이 지침들은 base와 head에서 동일하다. 현재 다른 reviewer의 raw/판정은 읽지 않았다. parent/구현자의 테스트 및 proof는 출처를 구분해 읽고 자체 검사로 대조했다.

정확한 변경 10개 경로 집합을 검증하고, manifest의 base/checkpoint/head 각 blob OID·SHA256·크기를 Git object와 직접 비교했다. packet proof12개의 해시·크기도 일치한다. 새 source는 runtime Python3개, 설정1개, test2개, docs4개다. old478은 PUBLIC checkpoint이며 combined 승인이 아니다.

전체 Git inventory에서 473개 기존 entry가 같다. config의 새 transport.ui_candidate 절만 제거하면 base 전체 YAML과 동등하다. 따라서 lifecycle target/services/containers, core/admin 그룹 layout 및 기존 선언에 다른 변경은 없다. 공유 service_release_candidate.py / service_release_compose.py / c6c_deployment.py / runtime_pin_registry.py와 frontend tree도 base와 동일하다. C11 배포물·lock·frontend·워크플로를 새로 만들거나 바꾸지 않았다.

작업 트리를 baseline으로 읽지 않았다. exact Git archive의 자체 fixture에서 기존 /tmp/kt-manager-candidate-python venv를 읽기 전용 재사용했다. 용량을 고려해 선택한 test module별로 순차 실행하고 끝난 자체 pytest fixture만 정리했다. 생산자 source/index·다른 worker cache를 변경하지 않았다.

증거: review-B-manager-transport-ui-route-e533820-evidence/manifest-blobs-proof.json, bounded-invariants.json, session.json 및 보존 manifest.

## source 검토 — 선택·권한·current

service_release_cli.py:245는 apply-component-ui에만 --component를 추가한다. 기본 None은 기존 public 선택이며 CLI dispatch(:167)가 등록 이름을 전달한다. 임의 role/runtime/env를 받는 새 인자는 없다.

registry.py:1133의 선택 정본은 다음 두 형태다.

| 선택 | 실제 runtime/group | 승인 source | revision 환경 예외 |
|---|---|---|---|
| 기본 public | 기존 frontend / core | transport canonical GitHub URL | 없음 |
| --component admin | 기존 transport-admin-web / admin | 같은 canonical URL | TRANSPORT_ADMIN_RELEASE_SHA 하나 |

기본 역할은 소유 target 컨테이너 등록에서, 추가 admin은 소유 release의 기존 runtime에서 유도한다. 이름·필드·UI suffix·runtime 중복·단일 소유 group·one-shot 겹침을 검사한다. 설정의 추가 component 전부를 검증하므로 미선택 선언에 잘못된 runtime이 있어도 통과시키지 않는다. API/backend·migrate·외부 release·인증/DB 키를 admin 선택이나 revision 예외로 등록하는 경로는 거부된다. source URL의 기존 HTTPS/GitHub·query/fragment 금지 및 root-owned 설정 신뢰 경계는 유지된다.

service_release_component_candidate.py:25 / :97은 기존 host·release 선언과 paired Map/Pinvi 금지를 유지한다. merged canonical source를 G 전후에 확인하고, G 안에서 current와 같은 project의 전체 overlay를 읽는다. 실제 mutation 선택만 UI 하나로 좁힌다. 기존 shared 본문은 immutable image ID·OCI revision/source·현재 health·비선택 컨테이너·pointer·최종 health 조건을 계속 적용한다.

frozen stdin에는 기존 이미지 overlay 전부를 보존하며 실행은 선택 UI의 up --no-deps --no-build --pull never다. backend/code-server/migrate/gateway/DB를 함께 실행하지 않는다. source clone을 운영 checkout으로 rsync하거나 오래된 candidate backend0036을 live backend499/schema0042에 복사·migration하는 새 경로가 없다. 기존 admin legacy 전체 checkout 배포기는 호출하지 않는다.

사후 또는 늦은 발행 guard가 실패하면 새 current를 발행하지 않는다. 실패 시 실제 UI mutation 자체를 자동으로 없었던 것으로 되돌린다는 보장은 아니다. 기존 shared terminal 진단과 실제 상태 확인 의미를 유지한다.

## revision 환경값의 예외와 raw 값 경계

service_release_component_candidate.py:56의 기본 정책은 candidate 새 기본값을 합치되 live effective 값이 우선한다. 새 예외는 정본에 등록한 release_env 하나다. candidate image 기본 Env의 값이 승인 source SHA와 정확히 같아야 한다. 별도 _merged_source 및 OCI source/revision 검사도 통과해야 _apply_current가 실행된다. default Env만 맞고 OCI가 다르면 거부된다.

등록 키만 source SHA로 재결박하며 인증·세션·지도·DB 및 나머지 live 값은 보존한다. 다른 이름의 RELEASE_SHA 값도 임의로 재작성하지 않는다. 선택 env_file을 다시 읽지 않는다. raw 달러는 component bind에서 한 번 Compose 표현으로 인코딩하며, 비교/guard의 값은 raw다. 승인 old image와 candidate image의 환경 관계를 admission·사후·current 직전 모두 확인한다.

등록 source 표식의 실제 소비도 immutable Transport936 source에서 직접 확인했다. TRANSPORT_ADMIN_RELEASE_SHA는 Dockerfile ARG/ENV와 인증된 GET /api/release의 반환값에 쓰이며, route는 hasAdminSession 실패 시401, 성공 시 no-store/private 응답이다. 인증이나 DB 접속을 고르는 값이 아니다. public frontend에서 이 키의 제품 소비는 없었다. 실제 public runtime에 revision 키가 없다는 별도 readonly proof는 해시가 맞는 handoff 관찰이며 B가 live inspect를 다시 한 것은 아니다.

Transport public api.ts / types.ts / service-export-types.ts는 candidate936과 알려진 live-backend source499의 Git blob이 동일하다. proxy route 차이는 Doctor 설명/지시 주석 두 줄뿐이다. 이 source 비교는 실제 live API 동작·현재 데이터·admin 전체 수용을 대신하지 않는다.

증거: transport-source-fact-proof.json, producer-runtime-revision-env-readonly.json.

## 직접 실행 — SDK503 및 추가25

producer XML의 선택 suite와 같은 10개 module을 exact source에서 직접 실행했다. 모든 module은 pytest 캐시 비활성화, 자체 basetemp, 생산 Docker를 가리키지 않는 환경으로 실행했다.

| module 범위 | 직접 결과 |
|---|---:|
| registry config | 81 PASS |
| service release | 55 PASS |
| 기존 candidate | 65 PASS |
| Mounts | 85 PASS |
| CLI | 23 PASS |
| 기존 component candidate | 120 PASS |
| frozen Compose | 23 PASS |
| process | 3 PASS |
| 신규 admin | 40 PASS |
| 신규 public | 8 PASS |
| 합계 | **503 PASS / fail0 / error0 / skip0** |

각 module별 실행으로 공간을 제한했다. 합계는 B JUnit에서 직접 계산했다. 전체 backend를 로컬에서 재실행하지 않았다. source unit은 fake Docker와 자체 current/source fixture를 사용하므로 실제 schema/DB 수용 측정이 아니다.

자체 추가 공격 **25 PASS / skip0**:

- 비문자/잘못된 selector6: Docker factory 이전 거부.
- 중복 owner·one-shot 겹침·다른 release 소유3: factory 이전 거부.
- candidate Env 중복·형식·구분자·NUL 오류5: up 이전 거부 및 current 보존.
- 실제 Compose → 자체 fake Engine create 요청8: raw 달러/참조/빈 값/등호·역슬래시/개행/한글을 엄격히 비교. live 인증 값 우선, candidate 새 raw default, 미등록 다른 release 표식 보존, 등록 revision만 변경을 함께 검증.
- manifest 작성 직후·pointer 발행 전 revision/gateway/DB 변화3: 발행 거부, 기존 current 유지.

실제 Compose v5.1.4를 자체 Unix socket의 fake Engine에 명시적으로 연결했다. create 요청의 Env를 캡처한 뒤 의도적으로 HTTP400을 반환해 CLI exit1로 정지했다. 이 exit1은 성공을 위장한 실제 Docker 실패가 아니라 검사 목적의 capture-stop이며, 실제 컨테이너 생성·생산 Docker/DB 접촉은 0이다. post-current 검증은 같은 raw 값을 자체 fake inventory에 넣어 수행했다.

이 검사에서 원 B-MGR-P1-01의 raw 달러 결함이 재도입됐다는 증거는 없다. 원 e798 FIXED 판정과 Mounts 원문은 변경하지 않았다.

증거: direct-suites.json, direct-suite-*.log/xml, run-focused.py, own-attacks-v2.log/xml, test_epicurus_transport_e533820-v2.py, epicurus_fake_engine.py.

## before 대조와 실패 기록 보존

같은 해시의 producer before/after probe도 B가 직접 실행했다.

- old478: admin parser exit2, 승인 revision 미적용, 옛 revision 유지, 인증 raw 달러 보존.
- e533: parser exit0, 승인 revision 적용, 옛 값 유지false, 인증 값 보존.

probe harness exit0은 기대한 이전 거부/부재와 이후 기능을 관찰했다는 뜻이다. old478에 admin 적용 승인이 있었다는 의미가 아니다. before archive는 backend/src+config를 포함하므로 import 시 docker-compose.yml 부재 경고가 있었고, 원 stderr를 보존했다. 그 단계에서 Compose/live 실행은 없었으며 parser/helper 대조의 assertion은 통과했다.

첫 자체 보조 공격은 compose config 출력 표현을 Engine의 raw Env로 바로 비교하여 **17 PASS/8 FAIL**했다. 제품 source를 고치지 않고 관찰 경계를 실제 fake Engine create Env로 교정했다. raw exact equality 조건은 그대로 유지한 두 번째 검사에서 **25 PASS**다. 첫 로그·XML·test 원본과 v2를 별도 보존했으며 초기 실패를 제품 회귀나 PASS로 재명명하지 않았다.

old478 검토 중 /tmp 용량0에서 끝난 320 PASS/117 fixture setup error도 이전 scope-hold 기록에 그대로 있다. 새503 성공으로 그 기록을 덮지 않았다. producer의 기존 /tmp·첫 ARM build 실패 역사도 manifest에서 보존돼 있다.

증거: direct-before-after-probe.json, producer-combined-before-probe.log, producer-combined-after-probe.log, own-attacks-attempt1.log/xml, limits-and-history.json 및 이전478 evidence.

## exact e533 원격 CI와 실제 checkout

GitHub connector로 e533에 연결된 workflow를 직접 조회했다. 최초 CI IN_PROGRESS와 최종 관찰 모두 github-ci.json에 보존한다.

- CI **43114698062 SUCCESS**
- 중앙 공통 프론트엔드 정책 **43114698466 SUCCESS**
- backend job **130839526473 SUCCESS**
- frontend job **130839526863 SUCCESS**

두 job의 raw logs를 직접 읽었다. 실제 checkout은 head 직결이 아닌 synthetic merge **0ee698d4f69c9d0e584617ccbc12131449d46882**다. merge 메시지는 e533 into ca1d32b이며 GitHub compare(e533 → 0ee698d4)는 merge base=e533, ahead1, files=[]다. 현재 merge ref의 소개만으로 CI checkout을 추정하지 않고 raw checkout SHA와 대조했다. 해당 merge의 local Git tree OID는 직접 얻지 않았으며 API 비교의 내용 delta0 근거로 구분한다.

backend raw 결과는 **3979 PASS / 40 SKIP / 1 warning, 483.48s**다. Ruff0.16.4 설치와 전체 CI lint 명령의 All checks passed를 직접 관찰했다. frontend raw는 **54 unit PASS / browser2 PASS(7.0s) / Doctor 진단0**, 타입·lint·build·guard 단계 성공이다. 이는 Manager frontend 회귀이며 새 Transport PUBLIC/admin 앱의 실제 ARM 이미지 브라우저 수용이 아니다.

로컬 canonical Ruff0.16.4는 찾지 못해 설치하지 않았다. producer canonical full-scope log의 고정 hash와 exact CI의 pinned Ruff 성공으로 확인했으며, 로컬 구버전 Ruff 결과를 새 성공으로 대체하지 않았다.

CI: https://github.com/digitie/kor-travel-docker-manager/actions/runs/43114698062
비교: https://github.com/digitie/kor-travel-docker-manager/compare/e533820112372fb2f23982265b7a9575db7a0431...0ee698d4f69c9d0e584617ccbc12131449d46882

old478의 CI green을 current combined gate로 사용하지 않았다.

## Finding / disposition / verdict / 미검증 한계

새 P0/P1/P2/P3 finding: **0**. 수정 권고 없음. **exact e533의 PUBLIC+ADMIN SDK source는 PASS**다.

실제 live backend499/schema0042 값과 public revision-key 부재는 전달된 readonly 관찰이며 재접속하지 않았다. 새 ARM 두 UI 이미지의 실제 bytes·image default ENV·OCI labels, merged 설치본, 적용 전후 DB/비선택 상태, PUBLIC/admin 로그인·표·지도·모바일·health·logout 수용은 별도 gate다. 실제 새 image의 Env가 승인 SHA와 다르면 source가 PASS여도 제품이 적용을 거부해야 한다.

Map 작업·운영 install/apply·DB/migration·repack·production Docker 접촉은 수행하지 않았다. 모든 Git/source 검토와 직접 probe는 격리 fixture이며 이 원문은 배포 실행 지시나 전체 앱 runtime 승인으로 확대할 수 없다. 현재 peer raw는 소비하지 않았고 모든 기존 판정·실패 원문은 보존한다.
