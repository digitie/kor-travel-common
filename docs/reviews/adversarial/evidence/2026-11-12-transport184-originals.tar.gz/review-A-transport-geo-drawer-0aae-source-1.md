# Independent A — Transport Geo drawer 0aae preliminary SOURCE1

- Run: A-TR-GEO-DRAWER-0AAE-SOURCE1-20261112; reviewer A/Mill, 구현 비참여, 현재 peer 원문/결과 열람 0.
- UTC: 2026-11-12T06:33:35Z 시작; 2026-11-12T06:41:24.257892+00:00 종료.
- Manifest: review-manifest-transport-geo-drawer-0aae-source-1.json; SHA256 ccb8bb6c196f5c0193a54d7d3c4ae685c490d9531ef44a8ac8c170c9f332471f 직접 일치.
- Base 47a4719ab772f7d0e7a707df2ed6a6d08b1cc4ea → HEAD 0aae32287e368222cb4a01005f0e8dd158957f70; tree c6b2a14ca089858888dc3143f5fd58d87a1c6b60 직접 일치. 관찰 checkout도 해당 HEAD/추적 파일 clean. 판정 자료는 Git object이다.
- SOURCE verdict: **BLOCK**. New findings: **1 (P0 0 / P1 0 / P2 1 / P3 0)**. preliminary source 범위이며 실행·CI·merge·배포 승인 아님.

## A-TR-DRAWER-P2-01 — OPEN: 이전 모바일 가로 메뉴 규칙이 새 왼쪽 drawer에도 적용됨

- 위치: packages/kor-travel-transport-admin/frontend/app/globals.css:462; 연결 :455–464, :845. 조립 경로 components/admin-shell.tsx:100, :141–144.
- 정확한 소스: 기본 `.common-menu [data-slot="app-menu"]` 및 `.common-menu ul`은 column(:455–456). 뒤의 `@media (max-width: 62rem)`은 같은 두 요소를 row로 바꾸고 그룹에 shrink:0을 준다(:461–464). 이 블록은 @layer legacy 종료(:440) 밖의 unlayered 규칙이다. 새 `.transport-menu-drawer .rail-nav {flex-direction:column}`(:845)은 **별도 부모 요소**를 지정한다. flex-direction은 자손 nav/ul로 상속되지 않는다.
- 재현 절차: 정확 0aae를 320/375/414/768px에서 열고 메뉴 버튼으로 drawer를 연다. `.transport-menu-drawer .common-menu [data-slot="app-menu"]`와 그 내부 ul의 computed flex-direction을 확인한다. 기본 16px 미디어 기준 62rem=992px 이하에는 row가 최종 선언이며 993–1023px에서는 해당 override가 사라진다. 이는 CSS cascade/실제 packed DOM의 정적 증명이며 본인이 브라우저를 실행한 결과가 아니다.
- 영향: 사용자 요구인 모바일 **세로 메뉴**가 주요 모바일 폭에서 충족되지 않는다. 19개 링크 그룹이 가로로 뻗고 `.rail-nav`의 가로 clip과 충돌하여 메뉴 접근·발견을 방해할 수 있다. 실제 잘린 픽셀/히트 영역/스크롤 수치는 NOT_RUN이다.
- Geo 비교: frozen Geo786 globals.css:3769–3770은 실제 AppMenu nav 및 ul을 column으로 지정하며 모바일 row 역전이 없다. Transport의 16rem/4rem 및 drawer 폭만 맞춰서는 이 계약을 충족하지 못한다.
- 권고: 더 이상 필요한 곳이 없는 이전 strip용 :461–464를 제거하거나, drawer portal 아래의 실제 nav/ul/group/link에 세로·폭·shrink 규칙을 명확히 적용한다. portal이 body 아래이므로 `.transport-shell` 조상만으로 제한한 override는 drawer에 닿지 않는다. PC 접힘/다른 페이지의 가로 메뉴에 영향이 없는 범위로 수정한다.
- 회귀 증거 요구: 새 admin-mobile-navigation.spec.ts:31–32의 실제 nav/ul column 단언은 유효하다. 320/375/414/768/1023 폭과 992/993 경계, 짧은 높이에서 마지막 링크·로그아웃까지 접근을 정확한 수정 HEAD에서 검증해야 한다. 현재 source의 테스트 파일 존재를 PASS로 간주하지 않는다.

## 독립 검토 및 공격 시나리오

- 8개 변경 경로 전부 diff/read. manifest 각 blob의 bytes/SHA256 8/8 일치. base/head 각각 908 blobs, 변경 외 900개의 mode/type/OID 동일. package/lock/vendor/public/backend/auth/key 관련 blob 변경 없음. Git object 총수이며 QA source907 파일 집합과 혼동하지 않는다.
- Geo786 AppShell.tsx/globals.css 2개 reference SHA256 직접 일치. 화면 구조·breakpoint·접힘/모바일 이름·portal 여부를 비교했으며 Geo 앱 실행은 하지 않았다. Geo의 기존 custom modal hook을 복제하지 않고 기존 공통 Radix를 사용한 방향 자체에는 새 finding 없음.
- 정확 admin UI tgz SHA256 16b4c213453fb02b527f8e4ae673a703e4ba3808538ae6fb24f70bdda770d213. tar를 메모리로 읽어 DialogContent와 AppMenu 실제 JS 확인: DialogContent는 Portal 안에 overlay/content를 만들고 unstyled를 overlay에도 전달한다. 기존 transform/max-width 클래스가 강제 삽입되는 경로는 없다. AppMenu는 실제 flex nav → group → flex ul이므로 위 CSS 충돌이 성립한다.
- SSR: server snapshot=false로 최초 hydration 상태를 맞추고 window 접근은 subscribe/client snapshot 경로에 있다. 1023px matchMedia와 1024px CSS 경계가 일치한다. 구독 해제 함수 존재. breakpoint 전환 key가 MobileNavigation을 재생성하고 open=false로 초기화한다. 실제 hydration/focus cleanup 타이밍은 브라우저 미검증이다.
- Focus/keyboard: DialogTitle/초기 닫기 버튼 focus/기본 modal Radix/Escape·backdrop 경로와 onCloseAutoFocus의 preventScroll을 확인했다. desktop 복귀는 main(tabIndex=-1), mobile 복귀는 새 trigger를 조회한다. portal cleanup·Tab/ShiftTab·배경 스크롤 잠금·route 변경의 실제 순서는 owner 정확 HEAD 브라우저 증거가 필요하다. 정적 경로 외 별도 focus 엔진이나 실제 통과를 주장하지 않는다.
- Route/상태: 기존 19 href·longest-prefix active 선택·10 map-page 분류를 유지한다. 일반 선택 링크는 modifier/defaultPrevented를 보존하고 같은 경로에서도 닫는다. pathname/media key 변경은 모달 상태를 닫힌 상태로 분리한다. PC Zustand store는 AdminShell에 남아 있고 모바일 RailContent는 collapsed=false이므로 모바일 전체 이름을 보존하는 경로다. localStorage 읽기·쓰기 실패는 catch로 처리한다.
- Auth/cache: POST /api/auth/logout과 submit/login 진입 시 v1/v2 session cache 제거를 보존한다. 새 인증·DB·키 처리 없음. 로그인 화면에서 메뉴를 렌더링하지 않는다. 운영 로그인/logout은 실행하지 않았다.
- Sizing: desktop 16rem/4rem, 모바일 min(18.5rem,88vw), backdrop/content 토큰 z-index, reduced-motion animation 제거, drawer header/footer와 scroll body 분리를 확인했다. 모바일 grid auto/minmax 및 expanded map topbar 숨김은 남아 있다. 실제 높이·RTL·iOS virtual keyboard·화면확대·짧은 높이에서의 접근은 실행 미확인이며 위 row 충돌 수정 후 최종 수용 필요.
- Tests: jsdom unit의 modal 열림/닫힘·focus·19 paths·PC 저장/복귀·blocked storage 단언을 읽었다. 이 환경은 CSS 시각 검증을 대체하지 않는다. E2E는 실제 CSS column, 첫 focus, Tab containment, Escape/backdrop/route/breakpoint/main focus, 높이만 바뀔 때 읽기 위치를 단언한다. 기존 2개 journey 파일은 열기/닫기 버튼 selector만 바뀌고 도메인 단언은 유지된다. ShiftTab 역방향·배경 scrollY 잠금 및 짧은 drawer에서 말단 메뉴 클릭은 후속 QA에서 보강 확인할 지점이며 별도 확정 결함으로 세지 않는다.
- docs 두 파일은 새 상태를 위에 추가했으며 기존 전체 bytes는 suffix로 보존됨을 확인했다. 이전 47a actual9/PNG36/디코딩2+2는 역사로만 남아 있고 새 drawer 수용으로 전용하지 않았다. Common4 PASS/HOLD 및 모든 기존 원문은 수정하지 않았다.

## Commands / raw evidence / limits

- 실행 명령: `git rev-parse <head>^{tree}`; `git diff --name-only <base> <head>`; `git diff --no-ext-diff --unified=3 <base> <head>`; `git ls-tree -rz <base/head>`; `git show <exactSHA>:<path>`; Python SHA256/length/mode/OID 및 기존 docs suffix 비교; 메모리 tarfile packed JS 열람; `git status --porcelain --untracked-files=no`.
- Evidence: review-A-transport-geo-drawer-0aae-source-1-evidence/verification.json, candidate.patch, admin-shell.tsx.numbered.txt, globals.css.numbered.txt, admin-shell-menu.test.tsx.numbered.txt, admin-mobile-navigation.spec.ts.numbered.txt, mobile-navigation-fixture.ts.numbered.txt, dialog.js.packed.txt, app-menu.js.packed.txt.
- Harness history: 첫 tgz 읽기는 존재하지 않는 pre/vendor 경로로 git exit128; 실제 immutable frontend/vendor 경로로 바로 수정했다. 제품 실패/테스트 red로 세지 않는다.
- Reviewer test/build/install/browser/server/auth/Docker/host/Map operations: **NOT_RUN/0**. 본 작업은 source 열람·해시 검증과 별도 원문/evidence 생성만 수행했다. 소스/index/branch 수정 0, peer 현재 결과 열람 0.
- 정확 0aae의 owner fullunit/type/lint/Doctor/guards/native+Alpine39 및 CI/ARM 후보 수용은 이 보고서에서 검증하지 않았고 PASS를 부여하지 않았다. 예전 strip/prototype/47a 결과로 대체하지 않는다.
- Finding 수정 후 새 immutable source와 정확 실행·CI 증거에 대한 동일 원 리뷰어 후속 확인이 필요하다. merge/공식 apply/신규 실제 운영 수용은 별도 미완 게이트이다.
