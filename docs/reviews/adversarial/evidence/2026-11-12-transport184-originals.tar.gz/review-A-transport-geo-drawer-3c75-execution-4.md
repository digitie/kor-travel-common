# Independent A — Geo drawer 3c75 bounded EXECUTION4

- Run A-TR-GEO-DRAWER-EXEC4-20261112; UTC audit 2026-11-12T07:23:57.053882+00:00 → 2026-11-12T07:25:36.306849+00:00; original reviewer A/Mill, 구현 비참여, peer CURRENT 열람 0.
- Input review-manifest-transport-geo-drawer-3c75-execution-4.json SHA256 **3d6da26a9e0f01e22ed4345572bc3c1310e3731915851d6801e8d921abaf93fd** 직접 일치. 참조 7개 파일 해시와 raw124개 해시 전부 일치.
- Exact source **3c75431e59a10fbfc9c5673191979d652a9bac9b**, tree **00b6474f7d9d6b39bcd5a633a392dfa23d202392** 직접 Git 검증. 관찰 checkout 동일/추적 파일 clean.
- Verdict **BOUNDED FRONTEND EXECUTION PASS — STAGED, retained unexplained first failure**. 신규 확정 findings **0** (P0/P1/P2/P3 각0). **전체 CI/merge 최종 PASS가 아니다**. Backend CI pending은 별도 exactCI 후속 입력으로 닫아야 한다.

## Own execution closure

- **A-TR-DRAWER-P2-01 FIXED — source + bounded browser evidence.** exact3c75 메뉴 E2E native13 및 Alpine13 JSON에서 320/375/414/768/992/993/1023px 실제 nav/ul column 검사, 19 links, 마지막 링크 focus, Escape/route/backdrop/trigger 복귀가 모두 expected/pass/retry0이다. 원 62rem 경계 양쪽을 포함한다. source3에서 확인한 CSS 제거와 현재 QA source/COPY의 exact CSS SHA256이 연결된다.
- **A-TR-DRAWER-P2-02 FIXED — source + bounded browser evidence.** source2 NOT_FINAL에서 발견한 잘못된 Shift+Tab 시작점은 source3 첫 brand anchor로 교정됐다. 실제 높이 전용 case(:125, 추가 :142–158)가 native/Alpine 각각 pass하여 마지막 link/logout viewport 포함, first brand→Shift+Tab→logout, header 위 wheel 후 document.scrollY 보존, Escape 후 trigger 복귀를 통과했다. 전체 패널 시각·전체 면적 노출·모든 플랫폼을 보장하는 주장으로 확장하지 않는다.
- 기존 source1 BLOCK/source2 partial/source3 SOURCE PASS 파일의 기존 SHA256을 모두 다시 검산해 불변 확인했다. 원문 상태를 소급 변경하지 않는다.

## Actual execution evidence audit

- Native **18 basic +4 review +13 menu +6 private recovery =41 unique cases**. Alpine **18+4+6+13=41**. 재귀적으로 raw Playwright suites/tests/results를 읽어 두 mode의 case 이름 집합이 동일한 41개이며 중복 없음 확인. 최종 8 report의 skip/unexpected/flaky/errors0, 개별 result 하나/pass/retry0, workers1/retries0/test timeout45000ms 확인. diagnostic target1은 82 unique mode-case 합계에서 제외했다.
- Native는 **단일 clean run이 아니다**. 최초 native pipeline exit1/private5PASS1FAIL을 원 raw에서 직접 확인했다. 375px 역안내 case는 departure combobox가 original assertion deadline **5000ms** 안에 enabled가 되지 않아 실패했다. 원 테스트의 전체 timeout45000ms와 이 assertion timeout5000ms는 별개다.
- 그 다음 동일 build의 diagnostic target1PASS, 다시 **원 private config/원 private test** 전체6PASS가 각각 별도 실행됐다. private 원본 SHA256 24b027e5d8a07dac2e30c98a00b64f17843bdbdfeb5941074c33797d6472d5bd 및 config 고정 SHA 직접 일치. diagnostic test는 import 첫 줄을 제외한 body가 원본과 byte-identical이고, config도 testDir 한 곳만 바뀐다. 추가 자동 fixture는 응답/console 관찰이며 원 단언을 바꾸지 않는다. 최종 group은 이 diagnostic overlay가 아닌 원 private config를 사용한다.
- 최초 raw51개가 final-raw에 그대로 남고 초기 hash index의 각 해시도 일치한다. 최초 오류 메시지를 own first-failure.txt에 보존했다. **최초 실패 원인 UNDETERMINED**: 당시 응답 telemetry가 없어 이후 catalog200/cities2/stations200을 최초 요청의 정상·비정상 근거로 역추정하지 않는다. 리소스·네트워크·CSS·fixture 원인이라는 판정도 하지 않는다. 별도 재실행에 의한 회복을 Playwright 자동 retry0와 혼동하지 않는다.
- Gates raw7 results exit0; unit log62files/452PASS, focused7PASS, Doctor0, type/lint/guards exit0. Native build exit0와 Alpine builder build exit0, Alpine continuation exit0를 raw command/result로 확인했다. 최초 native pipeline exit1은 여전히 보존된다.

## Bytes / provenance / visual / cleanup

- source receipt의 blob 경로 집합907 및 gitlink1을 exact Git tree와 대조했다. 전체907 SHA를 새로 재실행하지 않았고, shell/CSS/메뉴E2E/unit/loopback fixture/lock/config/Dockerfile 등 중요12개 SHA는 Git blob과 직접 대조했다.
- Alpine COPY audit JS의 **296개 expected 파일 해시 전부**를 경로 매핑 후 exact Git blobs에 대해 `git cat-file --batch`로 직접 SHA256 재계산해 일치(17,454,014bytes). 원 stdout도 copied296/mismatches0/routes32/parkingLots+railTimetable true/exit0. 이 해시 목록만 맞춘 것으로 실제 컨테이너를 새로 감사했다는 주장은 하지 않는다. 실제 실행 stdout과 source 해시 연결을 감사한 것이다.
- Common6개 tgz의 source receipt SHA·Git bytes·ledger SRI·lock의 도달 경로 integrity·tar regular file 수를 직접 비교해 총263개 확인. Native actual comparator는 도달한 설치 파일을 tar 내부 bytes와 직접 비교하는 코드이며 raw actual counts25/94/19/25/85/15=263이다. Alpine actual-bytes raw는 ALL_ACTUAL_BYTES_MATCH263. Native source/cleanup audit는 mismatch0/native compiled32, Alpine COPY 감사는296/compiled32를 기록한다. 기존 warm modules 사용을 새 install 또는 새 ARM production 검증이라고 부르지 않는다.
- PNG375/768/1280 3장을 본인이 직접 열람했고, 실제 열람한 Windows copy와 frozen PNG의 SHA256 모두 일치. 375/768은 왼쪽 세로 drawer·읽을 수 있는 이름/close/말단 logout을 확인했으며 스크롤이 아래로 이동된 캡처다. 1280은256px 세로 rail/본문 분리를 확인했다. 64px 접힘은 E2E로 검증된 항목이며 별도 캡처에서 봤다고 주장하지 않는다. 화면의 tile 오류는 격리 fixture가 VWorld tile을 abort하는 조건으로, 운영 지도 결과를 의미하지 않는다.
- cleanup 원문은 ownProcesses[]/ownHeavyJobs0, native4개 PID absent·각 port closed, Alpine fixture container exited/runningfalse 및 port closed, 총5port closed를 기록한다. final fleet recognizedHeavyProcesses[]/ownHeavyCount0/noProcessesTerminated=true. 본인 실제 호스트에 새로 접속해 현재 상태를 재탐사한 것은 아니다.
- QA server는 loopback에서 기존 fixture key와 E2E_MAP_SDK=true로 기동됐다. fixture QA/build/bytes audit를 production key 수용·실제 사용자 auth·공식 apply·ARM image 승인으로 확대하지 않는다.

## CI boundary / evidence / remaining gates

- 고정 front checkpoint의 main43170676902는 admin job131022947972/452, public131022947845/164, Doctor0/type/lint/buildSUCCESS; policy43170677221SUCCESS. 실제 synthetic checkout **78a1aa393fc2ac4655e11705a8b52b953aac7707**의 local Git tree가 exact3c75 tree와 동일함을 직접 확인했다.
- Backend job131022947871은 입력에서 **IN_PROGRESS_NOT_PASS**이고 liveE2E는 **SKIPPED_NOT_PASS**. 본 리뷰는 새 CI API 조회를 수행하지 않고 frozen checkpoint에 한정한다. 훗날 backend 완료를 이 원문에 소급하지 않는다.
- Evidence directory **review-A-transport-geo-drawer-3c75-execution-4-evidence/**: verification.json에 7 input hashes/124 raw hashes/실제82 case identities·stats/critical Git checks/COPY296/common SRI 및 count/cleanup/PNG hashes/old raw hashes를 보존; first-failure.txt에 원5000ms 실패 메시지 보존.
- Commands: Python SHA256/JSON 재귀 파싱/원본 body·config 비교; `git show <exact>:<path>`; `git ls-tree -rz`; `git cat-file --batch` SHA256; `git rev-parse <source/synthetic>^{tree}`; `git status --porcelain --untracked-files=no`; 메모리 tarfile/lock/SRI 비교; view_image3회. 전부 기존 증거 read-only 검사이다.
- Reviewer 재실행 tests/build/browser server/install/auth/Docker/운영접속/Map ops **0**. 소스/index/branch 편집0, peer CURRENT 원문 열람0. Backend final exactCI closure→merge184→실제 merged ARM image→공식 admin-only apply→정상 actual acceptance는 별도 미완 게이트다. Common/Geo 최종 출판 HOLD 해제도 이 증거만으로 승인하지 않는다.
