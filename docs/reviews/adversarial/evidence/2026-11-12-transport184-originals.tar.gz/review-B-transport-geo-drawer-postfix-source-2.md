# 독립 리뷰 B — Geo Drawer SOURCE2 조사 기록 (NOTFINAL)

- 상태: **NOTFINAL / 조사 중 SOURCE3 불변 입력 수신으로 전환**. source2 최종 승인/판정을 발행하지 않았다. 3378 manifest나 기존 source1 raw를 바꾸지 않는다.
- runid `B-GEO-DRAWER-POSTFIX-SOURCE2-20261112T064814Z`, 관찰 UTC `2026-11-12T06:48:14Z`.
- 입력 SHA256 `7f346c1fb5cb3c74cbeb6fbb9dfead55d0b63584906f954f797104a900fda0d8` 직접 일치.
- head `337822b9598fb13709366647d113b1af3a60b5fd`, tree `e3200924e58aca26a4d72ae2576afe98c3fdb808`, base `0aae32287e368222cb4a01005f0e8dd158957f70` 직접 일치.
- bounded 4경로 raw bytes/SHA 일치. CSS는 원 P2의 잔존 62rem 블록 5줄만 정확 삭제: **B-GEO-DRAWER-P2-01 소스 FIXED 관찰**. 제품 TSX/7개 unit/helper/locks/vendor/logout bridge 동일.
- 추가 독립 관찰 **B-GEO-DRAWER-P2-02 (P2)**: `frontend/e2e/admin-mobile-navigation.spec.ts:150`의 닫기→Shift+Tab→로그아웃 기대는 실제 DOM/동봉 FocusScope와 다르다. `components/admin-shell.tsx:129` 홈 링크가 닫기 버튼보다 앞선 첫 tabbable이다. 초기 close autofocus는 tab 순서를 바꾸지 않는다. 첫 역방향 이동은 홈 링크여야 한다. 실제 브라우저 재현/실패 실행을 수행한 것은 아니다.
- 직접 읽은 동봉 Scope fix.2는 Shift+Tab의 target이 first 또는 container일 때만 last로 순환한다. 첫 링크에서 시작해 logout으로 순환하는 assertion으로 바로잡는 것이 적합하다.
- SOURCE3 전달 후 별도 정확 head에서 최종 판정한다. 이 기록은 source2 PASS가 아니며, 관찰 verification의 중간 BLOCK 판단은 final 발행 전 조사 상태다.
- 증거 `review-B-transport-geo-drawer-postfix-source-2-evidence/verification.json` SHA256 `1071476b4a166f98d0bcb40818ae59c0574293f3abb8b0150fb512d058eb8cfd`; 당시 diff/줄 번호/packed Scope 원문 보존.
- source1 raw SHA256 `d6433697d226a9f94e5c26d56973688d982a2b520803ed701ed0acdf949dba57` 동일 확인. 상대 CURRENT 결과 열람 없음.
- reviewer 테스트/빌드/브라우저/운영 접속·변경 0. 모든 exact 실행·CI·ARM·운영 수용 미완. 이 부분 기록도 이후 덮어쓰지 않는다.
