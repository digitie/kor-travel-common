# Independent A — Transport Geo drawer bounded SOURCE3

- Run: A-TR-GEO-DRAWER-3C75-SOURCE3-20261112; UTC 2026-11-12T06:50:59.036506+00:00; original reviewer A/Mill, 구현 비참여/peer 현재 원문 열람 0.
- Manifest review-manifest-transport-geo-drawer-3c75-source-3.json SHA256 **2741ec83b3ecd427893446e2c407fde69673f86d082ae28248c73f2891cf7dd9** 직접 일치.
- Base 0aae32287e368222cb4a01005f0e8dd158957f70 → exact HEAD **3c75431e59a10fbfc9c5673191979d652a9bac9b**, tree **00b6474f7d9d6b39bcd5a633a392dfa23d202392** 일치. 관찰 checkout 동일/추적 파일 clean; 검토는 Git objects 기준.
- **BOUNDED SOURCE PASS / new findings 0 / OPEN 0**. P0/P1/P2/P3 신규 미해결 각 0. 실제 실행·CI·merge·ARM·공식 apply·운영 수용 PASS가 아니다.

## Own findings disposition

1. **A-TR-DRAWER-P2-01 FIXED (source)**. globals.css:455–457의 실제 AppMenu nav/ul column·group 규칙은 유지되고, source1 :461–465의 62rem row/shrink:0/width:auto 블록만 삭제됐다. 원 CSS에서 이 정확한 5줄을 한 번 제거한 bytes가 3378 및 3c75 CSS 전체와 같음을 직접 assert했다. 부모 `.rail-nav`에 의존하는 대신 실제 nav/ul 선언이 모바일 전체 폭에 적용되므로 원 정적 원인이 제거됐다. 실제 320/375/414/768/992/993/1023px computed style/접근성 수용은 후속 실행 게이트다.
2. **A-TR-DRAWER-P2-02 FIXED (source; source2 partial에서 추가 관찰한 테스트 결함)**. e2e/admin-mobile-navigation.spec.ts:148의 시작 focus를 닫기 버튼에서 `link[name="Kor Travel Transport 홈"]`으로 바꾼 한 줄만 3378과 다르다. 기존 admin-shell.tsx:129–134는 brand anchor 다음 closeButton 순서다. 따라서 닫기는 두 번째 tabbable이고, 원 테스트의 Shift+Tab 한 번 → logout 기대는 잘못된 전제였다. 새 전제는 첫 anchor에서 역방향 wrap을 시험하므로 합당하다. 정확 packed fixedScope JS :133–143은 첫 tabbable 또는 container에서 Shift+Tab일 때만 마지막으로 loop하고, :190–225는 DOM 순서/visible/tabIndex 기준으로 edges를 고른다. autoFocus에서 닫기를 지정하는 것과 첫 tabbable 순서는 별개다. 실제 실패를 실행한 적은 없으며 원 source2 오류를 실행 red로 기재하지 않는다.

## Bounded checks / attacks

- 두 manifest(3378/3c75) 각각 4개 blob SHA256/bytes/tree 직접 일치. 0aae→3c75 changed-path set은 CSS/E2E/docs2의 정확 4개다. 3378→3c75 changed-path set은 E2E 하나이며 이전 focus 문자열 하나를 치환한 결과가 새 파일 전체와 동일하다.
- 새 E2E에서 추가한 짧은 높이 블록을 제거하고 폭 배열을 원래 값으로 되돌리면 0aae 테스트 파일 bytes 전체가 정확히 복원된다. 기존 domain/focus/route/breakpoint/높이만 변경 시 문서 위치 단언의 삭제·timeout/skip 변경은 없다.
- 992/993px 추가는 원 62rem CSS 경계 양쪽을 검사하고 1023px drawer/1024px PC 기존 단언도 유지한다. 실제 nav/ul column 검사를 유지하여 컨테이너 방향만 확인하는 약한 검사로 바꾸지 않았다. 메뉴 E2E는 소스상 13 cases; native41+Alpine41은 **요구되는 후속 실행 수**이며 본인 실행 결과가 아니다.
- 280px 높이에서 마지막 링크 focus 후 viewport 포함, logout viewport 포함, 첫 brand에서 Shift+Tab → logout, header 위 wheel 전후 document.scrollY 동일, Escape 후 trigger focus 단언을 추가했다. 말단 메뉴가 DOM에 존재하기만 하는 검사보다 강하다. 실제 클릭/스크롤 잠금의 터치·브라우저별 동작, 전체 말단 영역 노출 여부는 아직 실행으로 입증하지 않았다. `toBeInViewport`는 viewport 교차 검증이며 전체 가림/전체 면적 무조건 노출을 의미하지 않는다.
- 제품 AdminShell TSX, 7개 unit case 파일, loopback fixture helper, UI/Scope tgz의 0aae/3378/3c75 bytes가 각각 동일함을 bounded bridge로 확인했다. 따라서 portal/19 routes/POST logout/cache/PC preference/focus callback 구현에 이 postfix가 새로운 JS 변경을 넣지 않는다. changed-path set 밖의 deps/locks/vendor/backend/public/auth/key 변경도 없다. 전체 907-file runtime 감사를 반복하거나 source1 실행 승인을 가정하지 않았다.
- PC에서는 삭제된 max62rem 블록이 원래 적용되지 않았고 모바일에는 기본 nav/ul column이 남는다. drawer portal 조상에 도달하지 못하는 별도 `.transport-shell` override를 추가한 수정이 아니다. source1에서 확인한 Geo 실제 세로 AppMenu 계약과 맞는 방향이다. 새 parent/child row override를 추가하지 않았다.
- docs2는 source1 row 결함/수정 이력을 추가하고 새 실행·재검토·CI 미완을 명시한다. 이전47a actual9/PNG36 수용은 역사로 유지된다. 원 Common4 PASS/HOLD와 새 메뉴 실제 수용은 별개다.

## Evidence / limitations

- Evidence: review-A-transport-geo-drawer-3c75-source-3-evidence/verification.json, postfix-union.patch, selector-only.patch, source2.patch, globals.css.numbered.txt, admin-shell.tsx.numbered.txt, admin-mobile-navigation.spec.ts.numbered.txt, packed-focus-scope-edges.numbered.txt.
- Commands: `git show <SHA>:<path>`; `git rev-parse <head>^{tree}`; `git diff --name-only <base> <head>`; `git diff --no-ext-diff --unified=6 <base> <head>`; `git diff --check <base> <head>` (exit0); Python SHA256/length/exact byte replacements; memory tarfile source read; checkout/status read. 소스/index/branch 수정 0.
- Source1 BLOCK 원문 SHA256 **87da8377eb5881e0e081aa4c7d63116932597bc1bf48e4516362cf8e6b533eed** 그대로 검산. source2가 완료되기 전 새 formal input3이 도착했으므로 사용자 지시에 따라 review-A-transport-geo-drawer-postfix-source-2.md에 **NOT_FINAL partial**을 별도 보존했다. source2 PASS/BLOCK 최종 원문을 소급 창작하거나 재명명하지 않았다.
- 본인 runtime/test/browser/build/install/server/auth/Docker/production/Map operations **NOT_RUN/0**. 새 exact CI를 조회하지 않았으며 owner fresh452/type/lint/Doctor/guards/native+Alpine82/ARM 후보는 모두 본 판정에서 미검증·PENDING이다. 0aae 또는47a 결과를 새3c75 PASS로 전용하지 않는다.
- 본 판정은 4-path postfix와 필요한 기존 focus/CSS 경계의 **소스 종결**이다. merge 전 exact3c75 실행·CI 증거 및 같은 원 리뷰어의 후속 게이트 확인이 필요하다. ARM/공식 SDK apply/새 UI 정상 운영 수용·Common/Geo 최종 출판 재개는 별도 후속 게이트다.
