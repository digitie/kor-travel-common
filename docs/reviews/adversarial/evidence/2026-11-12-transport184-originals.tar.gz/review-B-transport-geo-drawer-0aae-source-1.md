# 독립 리뷰 B — Transport Geo Drawer 0aae preliminary SOURCE1

- 원 리뷰어 B(Epicurus): 라이브러리 통합·SSR/cleanup·fixture 보안·인증/cache·패키지/provenance·운영 보존. 구현 참여 없음, 상대 CURRENT 리뷰/결과 열람 없음.
- runid: B-GEO-DRAWER-0AAE-SOURCE1-20261112T063836Z
- 직접 관찰 UTC: 2026-11-12T06:38:36Z; 원문 완료 UTC: 2026-11-12T06:40:36Z
- 판정: **SOURCE BLOCK — 신규 finding 1건(P2 OPEN), P0/P1/P3 신규 0건.** 이는 예비 소스 판정이며 merge/배포 승인이 아니다.
- 입력: `review-manifest-transport-geo-drawer-0aae-source-1.json`, SHA256 `ccb8bb6c196f5c0193a54d7d3c4ae685c490d9531ef44a8ac8c170c9f332471f` 직접 일치.
- Git base `47a4719ab772f7d0e7a707df2ed6a6d08b1cc4ea` → head `0aae32287e368222cb4a01005f0e8dd158957f70`, tree `c6b2a14ca089858888dc3143f5fd58d87a1c6b60`. head의 부모/base와 tree 직접 일치. PR184.

## B-GEO-DRAWER-P2-01 — 남은 strip 규칙이 실제 모바일 Drawer 안 메뉴를 다시 가로로 배치함

- 위치: `packages/kor-travel-transport-admin/frontend/app/globals.css:462` (조건 461, 비교 455–456, 새 Drawer 바깥 wrapper 규칙 845), 통합 위치 `components/admin-shell.tsx:141` (이하 frontend 기준).
- 실패 시나리오: 375px 또는 768px에서 메뉴 열기 → Drawer 안의 `[data-slot="app-menu"]`와 그 `ul`은 세로여야 하지만, 남은 `@media (max-width:62rem)` 규칙이 둘에 `flex-direction:row`를 지정한다. `html` 16px이므로 이 규칙은 320/375/414/768/992px에 적용된다. 1023px에서는 이 특정 잔존 규칙이 적용되지 않아 경계 폭 한 종류만 보면 놓친다.
- 직접 근거: 455–456의 column 선언과 462의 row 선언은 모두 unlayered이고 해당 선택자 specificity가 각각 동일하다. 뒤의 row가 이긴다. 새 `.transport-menu-drawer .rail-nav`의 column(845)은 **바깥 div**에만 적용된다. 실제 동봉 UI tgz의 `dist/app-menu.js`는 그 안에 별도 `nav[data-slot="app-menu"]`와 flex `ul`을 생성하므로 wrapper 방향으로 이를 교정할 수 없다. 모바일 규칙의 group `flex-shrink:0`(463)도 남아 있다.
- 영향: 사용자 요청의 Geo형 세로 메뉴를 주요 모바일 폭에서 충족하지 못한다. 19개 링크가 DOM에 존재하는 것과 세로 메뉴로 사용 가능한 것은 별개다. 바깥 wrapper의 `overflow-x:clip`과도 충돌하므로 실제 접근 가능한 항목·스크롤은 새 브라우저에서 확인해야 한다. 이 리뷰는 실제 clipping 범위나 브라우저 실패 건수를 실행해 관찰했다고 주장하지 않는다.
- 기존 신규 테스트와 충돌: `e2e/admin-mobile-navigation.spec.ts:31` 및 32는 실제 computed direction을 column으로 요구한다. 이 assertion을 유지하면 해당 폭에서 결함을 잡는 검사다. jsdom 단위 테스트는 CSS cascade를 검증하지 않는다.
- 권고: 원 구현자가 잔존 strip의 nav/ul/group 규칙을 제거하거나 Drawer 내부에 명확하게 세로 방향을 적용하고, 새 E2E의 direction/19개 링크/키보드/overflow assertion을 유지한다. 정확 수정 head의 native/Alpine 결과와 원 B 후속 소스 재검토가 필요하다.
- disposition: **OPEN / 이번 preliminary SOURCE gate BLOCK**. 정적 cascade로 확인했으며 브라우저 재현은 reviewer NOT_RUN; 실행 결과를 추정 PASS/FAIL 건수로 바꾸지 않았다.

## 불변 소스·패키지·업무 경계 직접 검산

1. Git object-only 전체 mode/blob/path 대조: base/head 각 **907 blobs, 변경 8개(소스2/테스트4/문서2), 동일 899개**. manifest의 변경 8개 raw Git bytes 길이/SHA256 전부 일치. 기존 보호 inventory **298개 전부 동일**. working tree, index, branch는 읽기 기준에 섞거나 변경하지 않았다.
2. Geo `786dae25f0a1927a98cbc66e6e8c86987da0a42f`의 AppShell/CSS 두 Git blob SHA256도 manifest와 일치한다. 사용자 명시 요구인 `<1024` 왼쪽 Drawer / `>=1024` 세로 rail을 기준으로 검토했다. Geo 자체 modal engine을 복제할 의무로 해석하지 않았다.
3. 실제 소비 UI tgz SHA256 `16b4c213453fb02b527f8e4ae673a703e4ba3808538ae6fb24f70bdda770d213`, base와 동일. tar를 메모리에서 열어 `dist/dialog.js`/타입/`app-menu.js`를 직접 읽었다. `unstyled`는 공통 presentation class만 opt-out하며 Radix Portal/Overlay/Content를 유지한다. `DialogTitle`, 닫기 ref, overlay props, controlled open 연결이 실제 공개 API와 맞는다. CSS는 body Portal 요소를 직접 대상으로 하므로 `.transport-shell` 후손이 아니어서 모든 Drawer 스타일이 사라지는 형태는 아니다. root layout의 tokens.css import와 실제 tokens 0.1.1의 root z-index/overlay/motion 값도 확인했다. package/lock/vendor/라이선스 payload/공통 C11 재발행 변경 없음.
4. 19개 메뉴 group 원문은 base와 동일하다. 가장 구체적인 경로 선택, 접근 가능한 이름, PC 16rem/4rem 선택, 모바일 `sidebarCollapsed=false` 전달을 읽었다. Next Link의 보통 좌클릭만 닫고 modifier/defaultPrevented는 보존한다. 업무 page/API/backend/auth/schema/키 입력 파일은 이번 변경 대상이 아니다.
5. `app/api/auth/logout/route.ts` raw blob 동일: POST origin 검사·303 상대 `/login`·만료 cookie 보존. shell의 POST form과 submit cache 정리, `/login` 진입 후 dashboard-v1/v2 sessionStorage 정리, 저장소 예외 허용도 보존된다. 모의 cookie를 쓰는 메뉴 검사를 실제 인증/로그아웃 운영 수용으로 확대하지 않았다.

## 적대 시나리오·SSR/cleanup·테스트 의미

- SSR에는 `getServerDrawerLayout=false`, client snapshot에서만 window 사용; 로그인 분기는 모든 hook 뒤다. per-instance Zustand 생성과 예외가 허용된 명시적 preference 저장을 유지한다. MQL listener는 같은 query/listener로 해제한다. 경로/media key 변경은 MobileNavigation의 open state를 새로 만든다. Portal의 body 잠금/focus trap/Escape는 실제 공통 Radix 경로를 사용한다. close autofocus는 기본 복귀를 막고 microtask에서 현재 mobile trigger 또는 main에 `preventScroll`로 복귀한다. 이는 소스 경로를 확인한 결과이며 hydration/키보드/스크롤 실제 PASS를 뜻하지 않는다. document-wide trigger selector는 현재 root layout의 단일 AdminShell을 전제로 읽었으며 다중 shell browser 수용을 수행하지 않았다.
- 검토한 전환: 닫힘→열기→Escape/배경/현재 링크/다른 경로, 1023↔1024, 접힌 PC→전체 이름의 모바일→PC 복귀, 로그인 진입, 차단된 localStorage. 이 시나리오들의 실제 focus·body style 복구·경로 이동은 exact 후보 QA가 필요하다. fullscreen map에서 상단바를 숨기는 규칙도 있어 지도 확장/복귀 실제 회귀를 기존 47a 수용으로 대체할 수 없다.
- 이전 **B-MENU-P2-01 FIXED**는 이번 입력에서 helper/해당 16 controls/type mock Git bytes가 base와 같고, 새 E2E 역시 **실제 fixture baseURL**을 전달하므로 유지된다. HTTP(S) exact loopback, userinfo 금지, target same-origin+protocol 검사가 cookie/route/goto 이전에 있다. remote caller+안전한 ENV, spoof host, unsafe protocol/userinfo, cross-origin/blob 경로가 사전 거부되는 경로를 다시 읽었다. network 없는 controls도 이번에는 재실행하지 않았다.
- 새 E2E는 DOM 링크 수 외에 computed nav/ul 방향, Drawer 위치/폭, 첫 focus, Tab containment, Escape/배경 복귀, resize 후 main/body 잠금, 저장 PC 폭/모바일 이름, 일반 화면 높이 불변, 높이 변경 중 입력 focus/scroll을 검사한다. 앞 finding을 잡을 assertion은 약화시키지 말아야 한다. 새 5폭 주요 메뉴 검사는 reduced-motion 조건이며 일반 animation/실제 touch 환경까지 수용한 결과가 아니다.
- 단위의 Link mock은 전달된 onClick을 먼저 실행한 뒤 jsdom 문서 이동만 막는다. 기존 strip 전용 중앙 스크롤 검사는 요구 변경에 따라 제거됐다. legacy E2E 두 파일은 열기/닫기 selector만 바꿨고, 로그인 비밀번호 미제공 시 기존 skip은 그대로다. skip을 PASS로 합산할 근거는 없다.

## 명령·증거·한계

- 직접 명령: `sha256sum manifest`; `git show -s --format='%H %T %P' HEAD`; `git diff BASE HEAD`; 각 대상 `git show HEAD:path`; `git ls-tree -rz BASE/HEAD`. Python 표준라이브러리로 raw blob SHA256/길이·mode/OID·tgz 내부 exports·Geo reference를 검산했다. 재현용 명령은 evidence의 `commands.txt`, 정확 8경로 diff와 줄 번호 발췌를 보존했다.
- evidence: `review-B-transport-geo-drawer-0aae-source-1-evidence/verification.json`, SHA256 `c0792adb11ad4dc1e1af1cf23374f98c1d3d54944e1bef0ac0324f2405c4b065`. 전체 evidence 파일 목록/해시는 같은 폴더 `evidence-sha256.json`에 있다.
- 조사 중 tokens archive 이름을 처음 0.2.0으로 잘못 지정한 Git 읽기 1회가 exit128이었다. `ls-tree`로 실제 0.1.1을 확인해 정정했고 제품 실패로 계산하지 않았다.
- **reviewer runtime/test/browser/CI API 조회/build/install/server/Docker/운영 접속·변경 0**. 새 native/Alpine 각39·전체 unit/type/lint/Doctor/guard·정확 PR184 CI·ARM 이미지·실제 키/정상 인증 운영 수용은 이 raw에서 **PENDING/NOT_RUN**이다. manifest가 pending인 것을 과거 다른 head 결과로 채우지 않았다.
- 이전 47a/image3f207의 실제 수용, 기존 source/실행/CI raw, Common4 PASS 원문은 역사로 보존한다. 새 Drawer의 실제 수용이 끝날 때까지 Common/Geo publication **HOLD**. finding 수정 후 동일 원 B final followup과 exact 실행·CI가 필요하며 본 보고서는 merge/배포 승인을 부여하지 않는다.
