# 독립 리뷰 B — Transport Geo Drawer 3c75 EXECUTION4

- 원 리뷰어 B(Epicurus), 구현 비참여·상대 CURRENT raw/결과 열람 없음. runid `B-GEO-DRAWER-3C75-EXEC4-20261112T072407Z` / 관찰 UTC `2026-11-12T07:24:07Z`.
- **FRONTEND EXECUTION PASS — STAGED, 최초 실패 원인 미상 보존 / CI_PENDING / 신규 finding 0건.** 단일 clean native run 또는 전체 CI/merge/배포 PASS가 아니다.
- 불변 입력 `review-manifest-transport-geo-drawer-3c75-execution-4.json` SHA256 `3d6da26a9e0f01e22ed4345572bc3c1310e3731915851d6801e8d921abaf93fd` 직접 일치. 7개 참조 파일 hash 전부 일치.
- exact source `3c75431e59a10fbfc9c5673191979d652a9bac9b`, tree `00b6474f7d9d6b39bcd5a633a392dfa23d202392`. 기존 SOURCE3 판정은 보존하고 이번에는 실행 증거 연결만 검토했다.

## own disposition

- **B-GEO-DRAWER-P2-01: FIXED, 실행 closure 확인.** native/alpine 메뉴 raw 각13개에 320/375/414/768/**992/993**/1023px의 column·19개 링크·keyboard 검사가 모두 expected/passed다. 정확 source3 CSS와 report의 spec 경로/줄을 연결했다. 과거 0aae CI452/164를 이 closure로 쓰지 않았다.
- **B-GEO-DRAWER-P2-02: FIXED, 실행 closure 확인.** SOURCE2 NOTFINAL에서 발견한 잘못된 reverse-tab 전제는 SOURCE3에서 첫 홈 링크로 수정됐다. 동일 source의 짧은 화면 case(line125)가 native/alpine 양쪽 expected/passed다. 280px 말단 링크/로그아웃·first→last ShiftTab·배경 wheel scroll·Escape focus 복귀가 포함된다. 닫기 버튼이 첫 tabbable라는 옛 전제를 다시 사용하지 않았다.
- **B-MENU-P2-01 기존 FIXED 유지.** 실제 caller origin/loopback helper와 source907 연결이 유지된다. 모의 session/응답을 쓰는 local QA이며 정상 인증/실제 키·지도 운영 수용은 아니다.

## Native 최초 실패와 staged recovery

- 최초 native 결과는 basic18 PASS + review4 PASS 후 private **5 PASS / 1 FAIL**, 전체 pipeline exit1이었다. 실패 case는 `기능보존 역안내 검색어는 실제후보 선택 후에만 조회·교환 375px`; 출발역 combobox가 기존 **5000ms** expect deadline까지 disabled였다. 원 raw/report와 최초 51파일 index의 모든 hash가 최종124 index에 그대로 남아 있다.
- 이후 메뉴13 PASS, 별도 관찰 fixture의 진단 target1 PASS, **변경 없는 원 private 그룹6 PASS** 순서다. 유효 native 커버리지는 18+4+13+6 = **41 unique**이며 진단1과 최초5를 다시 더하지 않았다. private6은 별도 수동 그룹 재검증이다. Playwright 자동 retry0을 “재실행 자체가 없었다”는 뜻으로 바꾸지 않는다.
- 원 private test의 diagnostic 복사본은 **첫 import를 제외한 body bytes가 동일**하다. 자동 관찰 fixture는 request/response 상태·body shape·console/snapshot만 관찰하고 product나 assertions를 교체하지 않는다. 원 harness5 hash와 private config(timeout45000/retries0/workers1)를 직접 확인했다. 최초/재검증의 동일 case timeout45000, 각 report 결과 attempt1/retry0도 일치한다. skip/expect timeout/test pool 완화 증거 없음.
- **FIRST_FAILURE_CAUSE_UNDETERMINED.** 진단 당시 catalog/stations가 200이고 combobox enabled였다는 것은 그 진단의 관찰이다. 최초 response telemetry는 NOT_CAPTURED다. 이후 정상 응답으로 최초 네트워크·CSS·리소스 원인을 확정하거나 첫 실패를 지우지 않는다. 이 한계와 별도 실제 운영 수용을 조건으로 staged frontend 증거를 수용한다.
- Alpine은 별도 continuation의 basic18+review4+private6+menu13 = **41 PASS**. 최종 유효 8개 report의 mode별 unique82는 skip/flaky/unexpected/errors0이지만 **전체 역사에는 최초 실패1이 존재**한다. native를 단일 clean41 PASS로 표기하지 않는다.

## bytes·source/image·cleanup

- 원 B가 raw124 파일을 직접 SHA256 재계산: **124/124 일치, 누락0**. source receipt907 SHA를 immutable Git blobs와 직접 대조: **907 일치**, gitlink1 pin 일치. 이는 새 소스 재감사가 아니라 실행 입력의 byte 연결이다. QA의 초기·종료 source mismatch0/harness mismatch0 기록도 보존돼 있다.
- native build exit0, Alpine **builder fixture** build exit0, 두 compiled manifest에 route32와 `/parking-lots`·`/rail/timetable` 포함. Alpine COPY audit의 expected296을 정확 Git source hash와 연결했고 mismatch0/route32 fail-closed script 및 exit0 raw를 읽었다. 이 audit는 QA builder image `sha256:6aa0029f20971ce5e958ad5954d237a36dac481238d58479b92f6569933932dc`에 대한 것으로, 향후 merged ARM image/runner/운영 image의 증명이 아니다. ARM build0·운영 apply0는 이 QA의 실행 범위다.
- 실제 소비6 package의 tgz **SRI/lock integrity와 tar member 수263**을 원 B가 Git bytes에서 검산했다. 원 harness는 설치된 모든 해당 member bytes를 tgz와 비교하며 native count263, Alpine `ALL_ACTUAL_BYTES_MATCH 263` 실행 raw가 있다. **현재 원격 node_modules/Docker bytes를 원 B가 재접속해 읽은 것은 아니다.** 새 pack/공통 C11 재발행/lock 변경을 허용한 것으로 해석하지 않는다.
- gates7개(type/lint/unit/Doctor/dependency 등) exit0 및 해당 log digest를 연결했다. unit raw **62files/452 PASS**, focused41(그중 menu unit7), Doctor0. frontend execution 근거이며 전체 backend 검증 수용으로 확대하지 않는다.
- 종료 receipt는 기록된 native PID4 종료·각 port 닫힘, Alpine fixture exited/port 닫힘, ownProcesses/heavy0/own5ports0을 보여준다. fleet receipt도 ownHeavy0이다. 원 B는 **기록 시점의 cleanup 증거를 검토**했으며 현 호스트 상태 재조회/프로세스 중지/캐시 삭제를 하지 않았다. 운영 전체 ENV나 비선택 앱의 현재 상태가 모두 불변이라고 확대하지 않는다.

## visual·CI 경계·보존

- 375/768 Drawer와 1280 desktop PNG3개를 **원 B도 직접 열람**, Windows copy SHA256을 불변 screenshot hash와 별도로 일치 확인했다. 모바일 왼쪽 세로 그룹/가독 가능한 브랜드·닫기/하단 로그아웃, PC 왼쪽 rail을 확인했다. 모바일 캡처는 키보드로 메뉴 아래쪽까지 이동한 상태이며 최초 scroll 위치의 증거가 아니다. PC64px 접힘은 PNG가 아니라 E2E raw 근거다. fixture VWorld 타일 오류는 실제 production 지도/키 성공·실패로 분류하지 않는다.
- CI checkpoint는 main run43170676902의 admin452/public164·Doctor0/type/lint/build SUCCESS, policy43170677221 SUCCESS, **backend131022947871 IN_PROGRESS_NOT_PASS** 및 liveE2E **SKIPPED_NOT_PASS**다. 실제 CI checkout `78a1aa393fc2ac4655e11705a8b52b953aac7707`의 Git tree도 원 B가 로컬 객체로 확인해 source3와 whole tree 일치했다. CI 상태는 hash-bound checkpoint 관찰이며 새 API 조회/전체 CI 종료 확인은 하지 않았다.
- superseded 0aae/3378 run의 cancel receipt는 역사로 보존하며 새 run PASS로 치환하지 않는다. Backend 완료 후 tiny exactCI closure가 별도로 필요하다. **PR184 merge, merged M ARM image, official admin-only apply, 정상 실제 로그인·logout/키/지도 수용은 미완**이다. Common/Geo publication HOLD와 Map 운영 제외를 유지한다.
- 원 source1 BLOCK, source2 NOTFINAL, source3 PASS의 원문 hash를 다시 확인해 모두 보존했다. reviewer 테스트/브라우저 실행/build/install/network/CI API/운영 접속·변경 **0**. 저장한 기존 PNG 열람은 실행 재테스트가 아니다.
- own evidence `review-B-transport-geo-drawer-3c75-execution-4-evidence/verification.json`, SHA256 `a5c955d1606e192e623df365e782bdc230e72f5b766ddebabcdc70e24a89d60e`. raw124 검산·사건별 report stats/attempts·907/296 byte bridge·old raw 보존·직접 visual·명령·evidence hash index를 별도 저장했다. **본 원문은 frontend staged execution만 수용하며 merge/배포 승인을 부여하지 않는다.**
