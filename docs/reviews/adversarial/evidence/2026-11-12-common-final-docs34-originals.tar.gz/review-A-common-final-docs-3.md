# Common PR50 facts3 — 원 리뷰어 A 독립 bounded DOCS 검토

- runid: `review-A-common-final-docs-3-20261112T055316Z`
- 역할: 원 A/Mill, consumer/UX acceptance facts·provenance·과거 실패 보존·범위 과장 검토. 구현 비참여, 현재 상대3 결과 미열람.
- 관찰 UTC: `2026-11-12T05:53:16`–`2026-11-12T06:00:19`.
- **판정: BLOCK — 신규 P2 문서 finding 1건. P0/P1/P3 0건. 운영·QA 성공 자체에 대한 반박은 아니다.**

## 불변 입력과 범위

manifest `review-manifest-common-final-docs-3.json`의 직접 SHA256은 `0ae0429c422a3067a6d1d3f01b3d52b5087fcd1d0cfb8b3743c845ad44be9d03`로 일치한다.

Common base `30730650e0a6e8ef72680e39e5553a0ab1a358cb` → exact head `48109bb1f29c45ce53367d64c44de723798fcefe`, tree `36f30af9b15bb3047be66369339572e1893f06dd`를 Git object로 읽었다. 시작/종료 작업트리도 해당 head/clean으로 관찰했다.

manifest의4개 문서/receipt blob SHA256·길이,14개 factual source SHA256·길이를 모두 직접 확인했다. 변경은4경로뿐이며 다른 모든 Git path의 mode/type/OID는 base와 같다. 따라서 기존 review raw/archive, 규범·패키지·버전·도구·workflow·config·scanner 예외·동결 배포물에 변경이 없다. 원문1/2와 본인의 Transport CI-close6 raw hash도 그대로다.

## A-COMMON-DOC3-P2-01 — 선택 Transport current 갱신과 다른 current 보존을 구분하지 않은 0 주장

- severity/disposition: **P2 / OPEN**. 문서 factual scope의 보정 요구다.
- 위치: `docs/reviews/adversarial/evidence/2026-11-12-frontend-deployment-receipt.json:232` (`transport.admin.rootGeoMapBackendAuthPinsCurrentChanges: 0`).
- 관련 위치: `docs/reviews/adversarial/2026-11-12-consumer-sdk-final.md:78`의 “기존 인증/세션/root/pins/current를 보존” 문장.

현재 완료한 작업은 Transport 관리자 image/source를47a/3f207로 바꾸고 selected Transport current에도 새 값을 게시하는 공식 적용이다. 반면 근거 `validation/manager-transport-admin-M47a4719a-deployment/final-receipt.json` 및 `postproof-result.json`의 보존 필드는 **`rootEnvAuthSessionPinsOtherCurrentUnchanged`**다. other/nonselected라는 범위를 제거해 current 전체에 변화0이라고 쓰면 보호 대상과 정상 선택 갱신을 섞는다.

이 차이는 실제 동결 인덱스와 맞는 operator source에서도 명확하다. `admin_ops.py:218`은 새 관리자 컨테이너와 `current().images[RUNTIME]`의 image/source가 새 입력과 일치해야 통과하고, `:226`은 다른 current pointer 보존 검사에서 `transport`를 명시적으로 제외한다. `:220`의 public current936 보존과도 별도다. 이 source 및 로컬 preflight/confirm/postproof mirror4개의 hash가 frozen37 인덱스와 같음을 확인했다.

정적 재현/영향: 독자가 새 공개 receipt의 `transport.admin`을 읽으면 “current changes0”을 deployment 전체의 보존 사실로 받아들이지만, 원 근거는 다른 current만 보존한다. 정상 선택 current 갱신을 zero-change ledger로 남기는 감사 범위 오류다. source/image·actual9QA·비선택54 보존 결과가 틀렸다는 지적은 아니다.

권고: **현재 `transport.admin`의 field를 OtherCurrent/NonselectedCurrent 범위로 명시하고, prose에 “선택 Transport current는 새 source/image로 갱신, 다른 앱 current와 public current936은 보존”을 구분**한다. `priorHistory.transport.admin.approvedKeyInput`의 동명0 field(`:565`)는 당시 키 입력만의 범위이므로 일괄 치환하지 않는다. 운영 재적용·새 QA·코드 변경은 필요하지 않다. 최소 문서 delta를 새 불변 입력으로 원 리뷰어가 확인하면 된다.

## 그 외 사실·출처 확인

- **현재6개 앱:** 기존 Concierge/Pinvi/Weather/Geo 객체는 base와 동일하고, Manager도 SDK591의508 설치/이전SDK값 보존/새 receipt2개 추가 외 원 acceptance facts가 동일하다. 새 앱 Transport만 추가됐다. Map record는 그대로 제외 범위다.
- **Manager SDK와 UI 분리:** odroid/n150 receipt는 merged508·reviewed e533/tree98f2 연결, frontend rebuild/restart0, actualApplyfalse를 명시한다. 기존 Manager UI9910 수용을 새 SDK 설치 시 재로그인한 것으로 바꾸지 않았다. public Transport936 수용은13항목/9세션의 단계별 aggregate이고 단일 전체 run이라고 주장하지 않는다.
- **새 Transport 계보:** merge47a / reviewed cd4 / CI checkout350457의 동일 tree510888을 로컬 Transport Git object와 대조할 수 있는 증거로 확인했다. ARM receipt의 image3f207·source907/COPY296·common6패키지263·compiled32·OCI/default release를 공식 적용 receipt와 QA receipt의 동일 image/source에 연결했다.
- **ARM 원본18개:** `final-manifest.json`이 가리키는 frozen18파일 hash를 직접 대조해 불일치0. 최초 collector shadow 실패 보존, 같은 image의 strict r2, rebuilt/retagged false라는 범위를 유지한다. source/COPY는 builder/context의 근거이며 prod runner에 모든 raw source가 존재한다는 주장도 하지 않는다.
- **정상 실제 수용9개:** 실제 `actual-result.json`에서 checks9개 전부PASS/failures0, 정상 제공 계정, fixture/위조cookie false, loginPosts1/logoutPosts1을 확인했다. 공식 적용 단계는 QA pending인 당시 receipt를 그대로 두고, 후속 QA final PASS로 닫는다. source·apply·QA 단계별 false/pending을 성공으로 다시 쓰지 않는다.
- **지도 한계:** actual PNG36행을 모두 직접 파싱해 before16/after20,HTTP200·image/png·PNG signature·IHDR256·승인 key 일치를 확인했다. bitmap decoded는 전후2+2, zoom7→8이다. 전체 observer96/legacy image200판정68/HTTP실패0의 나머지28은 미분류로 남긴다. 36개 검증을96개 전체의 PNG 판정으로 확대하지 않는다.
- **UX 사실:** responsive sequence9행/유일 폭7개(320/375/414/768/1023/1024/1280)가 모두 passed이고, 모든 기록된 font sample에서 실제 Pretendard custom glyph를 확인했다. documentY280→280/focus 유지,768 rail height delta0, 표·Popover Escape/focus·일반주차장·철도/공식·전화 링크가 raw checks와 맞는다. 외부 연락처 방문0, 실제 운영 screenshot0을 보존하고 과거 native PNG와 구분한다.
- **원본13개 QA:** frozen13과 source13의 총26 hash 대조를 직접 수행해 불일치0. 별도 참조 receipt5개를 연결한 final QA index와 parent receipt가 같은 source/image/check9를 가리킨다. 새 로그인·새 domain test는 하지 않았다.
- **과거 실패:** first6b75의76응답은 미분류, 후속36개만 HTTP200 XML/InvalidParameterValue/locator=key이며 subtype은 독립 분류하지 않았다는 기록이 유지된다. 과거768px 테스트 가정 실패, b0435실패, db58 typeFAIL, cd4 r1 worker 오류·bounded 복구도 priorHistory/불변 원문에 남긴다. old pending을 지금의 성공으로 소급하지 않는다.
- **과장 금지:** T218 IN_PROGRESS, Map 사용자/Claude 별도, nativephysical/EAS/store NOT_RUN, toolchain/build ecosystem/CI_LAST 미래 후속을 유지한다. 이 facts3의 출판·정확 CI도 아직 후속이다. 새 norm/artifact/toolchain을 문서로 만든 것으로 추론하지 않는다.

원 운영37개는 remote private frozen 인덱스와 parent37/37검증 receipt에 연결했다. 로컬에서 접근 가능한4개 mirror와 전체 인덱스 hash는 직접 맞췄지만 **원격37개를 새로 fetch/검사하지는 않았다**. 이 한계는 writer/parent의 원 검증을 바꾸거나 새로운 운영 실행으로 세지 않는다.

## 링크·바이트·실행 한계

변경4문서의 bounded link105개는 target file의 exact Git 존재를 확인했고 새 최종 운영 수용 section anchor도 맞는다. resume/task의 역사 suffix와 Map 객체, 이전5개 앱의 원 acceptance facts가 보존됐고 `git diff --check base head`는 exit0이다. 링크의 외부 live HTTP 상태를 새로 검사하지 않았다.

parent 인계의 전체 links840/3212·plan111·secret1432/0/기존예외32는 인계값이다. 전체 검사를 재실행하지 않았다. source 내 새로운 key/계정/본문 원시값 대신 hash·이름·길이로 연결하는 범위를 살폈다. 정확 common481 head의 CI는 manifest에서 pending이며 **자기 현재 조회/CI PASS 선언은 하지 않았다**.

명령: PowerShell cwd `C:\` → WSL Python/Git의 `show/diff/ls-tree/rev-parse/status`와 hashlib/JSON 검산. domain/runtime/login/logout/browser/build/install/운영 수정·추가 heavy0. 제품 파일·index·branch·원문 보고서를 수정하지 않았다.

자기 evidence: `review-A-common-final-docs-3-evidence/`의 `git-packet-and-history-verification.json`, `base-head.patch`, `factual-evidence-audit.json`(18image/26QA·선택 current 근거), `qa-claim-crosschecks.json`, `observations-finish.json`.

최종 **bounded DOCS BLOCK / P2 1건 / 나머지6앱·Transport 수용 사실과 출처 연결은 위 범위에서 일치**. 수정 요구는 current의 보호 범위를 정확히 쓰는 문서/JSON delta이며 운영 재실행이나 이전 source/runtime 판정의 철회가 아니다.
