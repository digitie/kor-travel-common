# Common PR50 facts3 — 원 B 독립 문서 리뷰

- Reviewer: Epicurus / original B. packaging/provenance·raw 보안·배포 경계 관점, 구현 비참여.
- Run ID: Epicurus-B-common-final-docs3-20261112T055315Z.
- UTC: 입력 직접 관찰 2026-11-12T05:53:15Z 이후.
- **Verdict: PASS — bounded factual DOCS / 새 finding 0건.**
- counterpart의 현재 facts3 원문/결과는 읽지 않았다. 기존 raw·manifest를 수정하지 않았다.

## 불변 입력과 범위

Manifest: `/home/digitie/dev/common-unification-20261111/review-manifest-common-final-docs-3.json`

직접 고정 SHA256:
`0ae0429c422a3067a6d1d3f01b3d52b5087fcd1d0cfb8b3743c845ad44be9d03`

| 구분 | exact Git ref |
|---|---|
| repository | kor-travel-common |
| base | 30730650e0a6e8ef72680e39e5553a0ab1a358cb |
| head | 48109bb1f29c45ce53367d64c44de723798fcefe |
| tree | 36f30af9b15bb3047be66369339572e1893f06dd |

Git object-only로 지정4개 경로의 head blob SHA256/길이와 전체 diff를 대조했다. 변경은 resume, 통합 factual 기록, 공개 deployment receipt JSON, T-218 task뿐이다. 나머지 **1,428개 entry의 mode/type/OID가 같다**. packages/versions/tools/workflows/config/scanner 예외/.gitattributes 및 기존 raw/archive bytes를 바꾸지 않는다. 규범 변경이나 동일 버전 artifact 재발행도 없다.

본인 이전 docs1/2 원문 SHA256은 각각 `856acad4dc62b6febcb86b9aa7250db6b006e98a6c333dcc4c343c19ced05294`, `a96e83b25e64a88402a8abd9386b3d4f02a8c2e7d99058969355c02687be9e8d`로 그대로다.

## 사실 연결과 운영 경계

manifest의 **14개 factual reference**를 실제 파일의 길이/SHA256과 대조했다.

- Transport actual merge **47a4719ab772f7d0e7a707df2ed6a6d08b1cc4ea**, reviewed cd4 및 CI synthetic35045758의 Git tree가 모두 **510888aa00fa949531e392c68061ff9ee72a5b83**임을 직접 확인했다.
- ARM strict audit, 공식 SDK 배포 및 정상 QA receipt가 같은 **image sha256:3f2073a3768bc90f07f4ff3ef614c9ceb263fb66b8b63ce125afeead1a58fb09**와 source47a를 가리킨다.
- ARM64, source907/COPY296, common6 packages/263 files, compiled32, OCI/source/default release의 감사 범위를 읽었다. raw source가 production runner 안에 그대로 있다는 주장은 하지 않는다. 최초 collector shadow 실패와 같은 이미지 readonly r2 성공을 구분하며 rebuild/retag로 실패를 덮지 않는다.
- 공식 SDK508의 admin-only dry-run1/confirm1과 postproof가 연결된다. operator launcher 오류는 confirm 전 이력으로 남고 extra apply0이다.
- **nonselected는 전후 실제54개**이며 추가/삭제/보호 projection 변화0이다. 53으로 계산하지 않았다. 공개936/image3262·backend499/schema0042 및 root/auth/session/pins/다른 current의 보존을 selected admin 교체와 구분했다.
- 승인된 Geo 키는 Transport 등록 웹 build 입력의 별도 변경이다. “모든 ENV가 영원히 무변경”이나 “새 키가 운영 반영되지 않음”으로 이전 상태를 고정하지 않았다. 배포 단계의 release SHA 예외와 정상 QA 단계의 실제 소비를 연결한다.
- Manager 두 host의 SDK591 설치는 source508b/기존 ca1d에서의 이동이며 frontend rebuild/restart0이다. 기존 Manager UI 수용과 SDK 설치 사실을 새 frontend 배포로 합치지 않는다.

현재6개는 Manager·Concierge·Pinvi·Weather·Geo·Transport다. Concierge/Pinvi/Weather/Geo의 기존 receipt 객체는 base와 완전히 같고 Manager의 기존 frontend 사실과 기존 evidence prefix도 유지된다. “7개 주 이관 머지”와 “6개 actual 수용”은 다른 집계다.

## 실제 QA 수치와 실패 이력의 경계

Transport admin의 actual-result와 final receipt를 대조했다. **단일 정상 세션9 checks PASS/실패0, login1/logout1**, 보호401→인증된 exact M→logout303→보호401의 범위다. 위조 cookie/fixture 주입0, 실제 운영 screenshot0이라는 경계도 유지한다.

**bounded map36건**은 zoom 전16/후20이며 각 row의 HTTP200, image/png, PNG signature, IHDR256×256, 승인 key 일치 metadata를 확인했다. 각 phase에서 실제 bitmap decode2씩, camera7→8이다. early-map rows와 최종 actual rows도 같다.

이를 전체 세션 observer와 혼합하지 않는다. 전체는 **96 observed / legacy validated68 / unclassified28 / HTTP failure0**이다. 28개를 오류 또는 검증된 PNG로 단정하지 않았고, 96개 전체 decode/PNG 수용으로 확대하지 않았다.

unique 폭은 **320/375/414/768/1023/1024/1280의7개**, 왕복 관측 행은9개다. 정상 QA의 실제 Pretendard·표/팝오버·주차장/철도/연락처 검사, 높이 변화 rail delta0와 문서 scrollY280 유지/focus 보존을 동결 기록에 연결한다. 외부 연락처 링크를 방문하거나 실제 생산 screenshot을 새로 만들었다는 주장은 없다.

Transport public936/image3262는 **13항목을9세션의 단계별 증거로 수용**한 기록이다. aggregate의 singleRunPass=false와 보존된 harness 실패를 확인했으며 새 admin9개 단일 세션과 합쳐 “한 번의 전체 suite PASS”로 바꾸지 않았다.

priorHistory에는 기존5개 수용 시점·6b75 source/CI/review pending과 실패가 남는다. 첫76응답은 당시 MIME/signature **미분류**, 후속36개만 XML InvalidParameterValue/locator=key로 분류한다. 세부 인증 오류 subtype을 독립 분류했다고 쓰지 않는다. 후속 성공으로 기존 BLOCK/skip/NOT_RUN을 다시 쓰지 않는다.

## 원문 byte·보안 검증 수준

| 증거 | 이번 B 직접 확인 |
|---|---|
| 이미지 frozen18개 | 실제18개 파일 hash 대조 |
| 운영37개 | hash로 묶인 member manifest 및 parent37/mismatch0 대조; 로컬7개 실제 bytes/길이 대조 |
| 운영 원문 나머지30개 | 로컬에 없어 원격 private archive 재조회하지 않음; parent 검증에 의존 |
| QA13개 | source/frozen 양쪽 **26회** 실제 hash 대조 |
| 공개 receipt | private 원문 대신 이름/크기/SHA·승인된 집계만 게시하는 구조 확인 |

로컬 운영7개는 mode0600도 확인했다. 비공개 admin 입력의 origin 문자열2개를 공개 추가분과 비교하여 노출0을 확인했고 값은 출력/저장하지 않았다. 추가분의 private 절대 경로와 credential assignment 탐지0이다. 공개 JSON에 raw body/cookie/key URL·계정·private 운영 입력이 들어간 것으로 발견한 것은 없다.

이 검사는 비밀값을 모두 추출하거나 원격 설정을 다시 읽은 검사가 아니다. parent가 전달한 secret1432/findings0/기존예외32 및 links840/3212·plan111은 전달 검증 결과로만 기록하며 본인이 재실행했다고 하지 않는다. scanner/allowance bytes는 unchanged라 예외 확대는 없다.

## 남은 범위·명령·판정

T-218 상태는 **IN_PROGRESS**다. Map은 사용자/Claude 별도 범위이며 추가 source/build/apply 수용으로 집계하지 않는다. native physical/EAS/store는 NOT_RUN이고 toolchain/build ecosystem 및 **CI_LAST는 후속**이다. 이 문서 정산으로 이를 완료 처리하지 않는다.

새 Common48109bb의 exact CI는 **manifest freeze에서 pending**이다. 이번에는 재조회/실행하지 않았고 PASS로 전용하지 않는다. 소비자 과거 CI 성공이나 Transport 실제 수용도 Common PR50의 exact CI를 대신하지 않는다. 문서 facts PASS이며 merge 또는 새 도메인 runtime 승인은 아니다.

PowerShell workdir C:\ → wsl.exe에서 Git show/diff/ls-tree/cat-file/rev-parse와 Python SHA256/JSON 비교만 수행했다. 새 상대 링크6개의 Git target을 확인했고 신규 section anchor도 대조했다. Git diff --check는 직접 exit0이다. 설치·detached worktree·전체 build/test·browser·인증·배포·Map ops는0이다.

새 evidence: `review-B-common-final-docs-3-evidence/`

- verify.py SHA256: `decb62597c5f50ada226509261ce6f5c2912b8334779531363fee20a9ee2310e`
- verification.json SHA256: `ccc33ba449e3493238c21045788c2aceb3401159f09871430d1a79d10c0c6b7e`
- manifest.json: 입력 exact copy. private raw/credential 내용은 복사하지 않았다.

**PASS / 새 finding 0건.** 위의 byte/출처·수치·배포 경계 안에서 사실 delta를 수용한다. Common exact CI·PR50 출판은 parent의 별도 gate이며 기존 모든 원문은 불변 보존한다.

## 작성 중 수신한 후속 CI 관찰 — 2026-11-12T06:03:07Z

최초 원문 작성 뒤 별도 CI receipt를 수신했다. 앞 절의 pending·미조회는 최초 검토 단계의 기록이며, 원 manifest의 동결 상태도 그대로 보존한다.

GitHub의 exact48109bb 연계 workflow를 직접 조회해 **frontend43164298948 / python43164298844 / docs43164298962 모두 completed/SUCCESS**를 확인했다. docs의 secret-scan·Windows tools·Linux tools·packages·docs·check-versions **6개 job도 모두 SUCCESS**다. 소스 변경이나 다른 head 결과의 전용은 없다.

parent receipt SHA256은 `283a87706abcb4265cd37d14c7ae81e37aa401eb063153f5cd892b50665782c9`, 독립 `ci-followup.json` SHA256은 `1d5eccd1d7f259db9e20f11af9bc82dac3d5e79c9da5ee994af5a89f2dde7086`이다. 최초 작성본은 evidence의 report-before-ci.md에 SHA256 `1f0f09c0976788610130eb94ebdf834c5e3b257e3c700fb2aeda22104e7bac22`로 별도 보존했다.

**최종 bounded DOCS PASS / 새 finding 0건.** 같은 head의 후속 CI 성공을 확인했으며 merge는 수행하지 않았다. T-218·Map 제외·native/EAS/store·toolchain/ecosystem/CI_LAST 및 직접 원문 대조 범위의 한계는 변하지 않는다.
