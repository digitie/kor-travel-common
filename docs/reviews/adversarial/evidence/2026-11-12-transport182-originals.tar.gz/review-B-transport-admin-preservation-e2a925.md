# Transport admin 기능보존 e2a — 독립 B 원문

- Reviewer: Epicurus / original B. 구현 비참여; packaging/provenance/platform/security/release 및 기능 비회귀 검토.
- Run ID: Epicurus-B-transport-preservation-e2a925-20261112T001207Z.
- UTC: 시작 기록 2026-11-12T00:12:45.308583Z; 최종 정적 관찰 2026-11-12T00:24Z.
- Verdict: **BLOCK — B-TR-P2-01 OPEN, B-TR-P3-02 OPEN.** 최종 X의 수정 소스와 실행 gate에 대한 별도 bounded followup이 필수다.
- 이번 결과는 e2a 불변 소스의 정적 리뷰다. merge/install/admin apply 또는 전체 앱 runtime 승인으로 사용할 수 없다.
- 상대 A의 현재 원문/결과를 읽지 않았다. 기존 원문/manifest, 소스, package, 설치 모듈 및 운영 환경을 변경하지 않았다.

## 1. 불변 입력과 직접 byte 검증

Repository: /home/digitie/dev/common-unification-20261111/kor-travel-transport

Manifest: /home/digitie/dev/common-unification-20261111/validation/review-transport-admin-preservation-e2a925086925/manifest.json

Manifest의 직접 관찰/고정 SHA256:
`0721412625b76db6ee1eda5c789ab319b6a20950f5ac630c94afad9ac1a6e136`

| 입력 | 직접 확인한 Git ref |
|---|---|
| base / C11 candidate | 936fdb90b0ee9f6392d2f888255053ee1f4066b2 |
| 이번 source head | e2a925086925fd353bd3705f8ea3ae96ac3810a5 |
| head tree | 21b87f7b2e38152d09c8cbec372f682405dbfdc7 |
| 보존할 admin live source | 6bd594e606ef7d0326ec5742942e83997708946e |
| 실제 backend 계약 대조 source | 499822601abca3f050aa0cfe0e27fb446d22281d |
| common ancestor | 59e1d8213c09a82a4ed9cc4396a6414ef0332b9c |

manifest 세 sidecar SHA256, base/head ls-tree, 변경 경로의 양쪽 Git blob OID, head blob SHA256/길이를 직접 대조했다. 변경 **49개**가 manifest와 정확히 같고, 기존 tracked **854개** 및 보호 경로 **295개**의 base/head mode/type/OID가 같다. moving checkout의 이후 737 또는 dirty 변경은 읽기 baseline에 섞지 않았다.

보호 경로는 public frontend, backend/app/tests/migrations/uv.lock, admin package/lock/common-artifacts/vendor 및 기존 지도 vendor 고지를 포함한다. 이는 e2a가 backend499로 교체되었다는 뜻이 아니다. live backend499는 API 계약 비교에만 사용했다. DB0042와 candidate0036의 차이에 대한 migration/sync/replacement는 수행하지 않았다.

직접 생성한 증거 디렉터리:
`review-B-transport-admin-preservation-e2a925-evidence/`

| 증거 | SHA256 |
|---|---|
| manifest.json (입력 exact copy) | 0721412625b76db6ee1eda5c789ab319b6a20950f5ac630c94afad9ac1a6e136 |
| session.json | e23417393742c3e5ae2367f5c519ed5c8c5a17a59204627cafe10c679ffec5b5 |
| input-proof.json | 5ee71f6e6b0afaebf106d9446889e2624572888f68f4c44bc347a49893793ca7 |
| static-audit.py | a9b9d662560c9f9ca7501c83800d0c5fe65828c95550f29727a9f7f91b2f1ef7 |
| static-audit.json | bbdb1dcfe6b7143906f6913acafa93cc779d7d58973b8944cad5a7fa51f0c5a9 |
| findings-static.json | f046d7d5f0b0cae670300c129ae8dda498a671d65ded754868db8d3dfc595a69 |

static-audit.json에는 49개 head blob의 OID/SHA256/길이와 실제 tgz 10개 사본의 SRI/metadata/고지 경로를 기록했다. fixture 추출이나 애플리케이션 코드 실행은 하지 않았다.

## 2. Findings

아래 경로의 공통 prefix는 `packages/kor-travel-transport-admin/frontend/`이며 line은 명시한 불변 Git ref 기준이다.

### B-TR-P2-01 — 일반철도 상세 교체가 기존 공식 역 안내와 전화 연결을 제거함

**Severity P2 / disposition OPEN / source 회귀.**

- e2a `components/general-rail-guide.tsx:46`이 기존 RailGuideDetails를 GeneralRailStationDetail로 교체한다.
- e2a `components/general-rail-station-detail.tsx:9`는 전화번호를 일반 텍스트로 출력하고 공식 코레일 역 안내 링크를 제공하지 않는다.
- base936 `components/general-rail-guide.tsx:81`에는 provider_id를 encodeURIComponent한 공식 stationSeq 링크와 정제된 tel 링크가 모두 있다.
- 같은 e2a에 그대로 남은 기존 계약: `e2e/general-rail.live.spec.ts:25` 공식 링크, :26 전화 링크; `e2e/transport-user-journeys.spec.ts:98` 전화 링크, :99 공식 링크. 두 E2E 파일은 base/head blob이 동일하다.
- e2a frontend 전체 Git grep에서 실제 runtime의 `korail.com/ticket` 링크는 없다. stationSeq는 두 기존 테스트의 assertion에만 남는다.

**재현/증거:** base/head Git show로 위 renderer를 대조한다. e2a의 /rail에서 주소·전화·provider_id가 있는 역을 선택하면 새 상세에는 시간표 UI와 전화 텍스트가 있지만 기존 두 링크를 생성하는 JSX가 없다. 본인은 browser/E2E를 실행하지 않았다. 이 판정의 직접 근거는 실제 renderer의 링크 소실과 보존된 동작 계약의 모순이며, E2E red를 실행 관찰했다는 주장이 아니다.

**영향:** 지도·시간표 carry가 되어도 기존 사용자의 공식 역 안내 접근과 전화 연결 기능이 사라진다. 특히 새 상세가 편의시설 정보를 제공하지 않는다고 표시하는 상황에서 공식 안내로 이동할 기존 경로도 없어졌다. live6bd의 상세를 가져왔다는 사실은 base936 C11의 기존 기능 삭제를 정당화하지 않는다.

**권고:** 새 시간표 상세를 유지하면서 검증된 provider_id에 대한 공식 링크와 정제된 tel 링크를 복원한다. 기존 주소의 지도 이동 action도 상세 교체 시 함께 보존되는지 확인한다. 실제 행동 assertion을 유지하고, 공통 controls에 맞는 selector 조정과 기능 assertion 삭제를 구분한다. 최종 X에서 375/1440 실제 상세 접근 및 두 링크의 target/href를 검증해야 한다.

### B-TR-P3-02 — live의 일반철도 수집 작업명 한글 표시가 carry에서 누락됨

**Severity P3 / disposition OPEN / live 보존 누락.**

- e2a `lib/dagster.ts:13` 이후 JOB_LABELS에는 `general_rail_timetable_collection_job` 항목이 없다. 이 파일은 base936과 동일하다.
- live6bd 같은 파일 :14에는 `JOB_LABELS.general_rail_timetable_collection_job = "일반철도 예정 시간표";`가 있다.
- 실제 소비 지점: e2a `components/collection-status.tsx:27`, :89; `components/dagster-operations.tsx:12`; `components/operations-home.tsx:137`. label이 없으면 raw job name으로 fallback한다.
- backend499 `backend/app/dagster/definitions.py:669`에 실제 job이 정의되고 :915 등록, :937 스케줄 설정이 있다.

**재현/증거:** git diff base936..live6bd -- frontend/lib/dagster.ts 및 e2a Git grep으로 항목 부재를 대조한다. 위 job의 run/schedule이 응답에 있으면 기존 한글 작업명 대신 내부 영문 이름이 표시되는 분기를 소스에서 확인할 수 있다. 실제 Dagster/운영 API에 접속하거나 job을 실행하지 않았다.

**영향/권고:** 작업 실행/승인 guard 변화는 없지만 운영 목록의 기존 읽기 편의가 퇴행한다. live의 label mapping을 보존하고 해당 fallback/표시 계약을 최종 입력에 포함한다.

## 3. B 전문 범위의 정적 검증

**Packaging / 같은 bytes / license boundary.** public 4개와 admin 6개, 총 10개 실제 Git tgz 사본을 메모리에서 읽어 SHA512 SRI를 계산했다. 각 사본의 common-artifacts entry, lock resolved/integrity/version, archive package.json의 name/version이 모두 일치하고 base/head Git blob도 동일하다. UI/tokens는 GPL-3.0-or-later, VWorld core/web은 GPL-3.0-only, LightningCSS는 MPL-2.0, Scope는 MIT라는 package/lock 선언이 일치한다. 각 archive의 LICENSE/NOTICE 경로도 확인했다. 이번 delta는 기존 제3자 artifact나 고지 bytes를 바꾸지 않는다. 과거 원 fork/source gate 전체를 재실행하거나 재라이선스 판정한 것은 아니다.

UI 0.2.0 / tokens 0.1.1, LightningCSS fix.4, Scope 1.3.1+kortravel.fix.2, admin VWorld core1.0.1/web1.0.3의 C11 bytes가 그대로다. 두 common-artifacts.json의 CANDIDATE_NOT_RELEASED는 기존 불변 receipt의 문구로 남아 있다. 이를 현재 배포 상태나 신규 repack의 근거로 해석하지 않았다. RN metadata 항목이 있어도 이 두 web surface에 RN tgz가 설치되었다고 확대하지 않았다.

**Auth/session/proxy / allowlist.** `app/api/transport/[...path]/route.ts` 및 `lib/auth.ts`의 base/head blob이 같다. GET은 session 확인 후 upstream path를 구성하며, 새 읽기 경로 추가가 로그인 우회나 POST write route 추가로 이어지지 않는다. 기존 `admin/collector-status` read entry는 이번에 추가한 항목이 아니다. 새 branch는 parking-lots/detail의 정확한 segment 수, rail/stations의 정확한 구조와 양수 ASCII ID만 허용한다. 0/음수/선행0/점·slash/비ASCII/추가 admin suffix는 새 정규식/길이 조건에 맞지 않는다. 이것은 소스 분기 대조이며 HTTP 공격을 실행한 결과가 아니다.

기존 수수료 POST의 session/origin/content-type/본문 한도 처리는 unchanged다. query는 URLSearchParams로 전달되고 upstream origin은 기존 서버 설정을 사용한다. 새 코드에 임의 호스트 선택, 세션 전달 확대 또는 backend admin mutation 추가는 확인하지 못했다.

**Backend499와 실제 해석 계약.** 주차장 list/detail과 collection 상태, q/cursor/has_more/next_cursor 필드를 실제 backend499의 public_parking_routes.py 및 schemas.py와 대조했다. pagination의 query/cursor 교체, abort 및 늦은 응답 방지 코드를 읽었다. 좌표 없는 주차장은 목록에서 볼 수 있으며 정적 등록 면수를 실시간 여유 면수로 표시하지 않는다. backend GET의 내부 cache 동작까지 무쓰기라고 주장하지 않는다.

도시철도 catalog와 `/transport/rail/stations/{code_id}/timetable`는 backend499 main.py:1829/:1834의 정식 코드 계약에 대응한다. 미지정/404/수집 실패·stale·no_data·운행일 미확정과 정상 empty를 같은 “운행 없음”으로 합치지 않는 분기를 확인했다. 일반철도 guide provider_id는 출발/도착 검색 의도로만 전달되고, 실제 TAGO station_id를 후보에서 고른 후에 query를 만든다. guide provider_id를 시간표 코드로 자동 대입하는 경로는 발견하지 못했다.

**지도/C11 union / 테스트 강도.** 공유 MapWorkspace/MapStage/Tabs/VWorld 경계, expand/focus/native followup anchor 경로와 unchanged map-workspace.spec.ts를 대조했다. 주차장·독립 시간표 routes/nav 추가와 code-ID 기반 도시철도 선택, 유종 5개 지역 가격/overflow 대체 목록, 종류별 truncation 안내를 읽었다. viewport의 좌표를 label 충돌 회피 때문에 바꾸는 코드는 없고, CSS offset으로 카드 위치를 조정한다.

새 테스트는 페이지 내용/API 요청, session 유무, 잘못된 route, cursor/늦은 응답, 역 이름만으로 자동 확정하지 않음, selection/disabled/Escape와 다중 선택 유지 등을 구체적으로 assert한다. 단순 snapshot 통과로 기능을 대신하지 않는다. 다만 이는 테스트 소스의 강도 관찰이다. 새 테스트가 모두 통과했다는 판정도, map/portal/focus/layout의 실제 browser 보존 판정도 아니다. P2가 보여 주듯 기존 상세 동작과 새 테스트 범위 사이에는 누락이 있다.

## 4. 실행 결과와 미완 gate

| 항목 | 이번 B 직접 수행 / 전달 사실 |
|---|---|
| Git ref/tree/49변경/854동일/295보호/SRI/archive metadata | 직접 수행, 정합 |
| auth/API 계약/renderer/테스트 소스 정적 검토 | 직접 수행; finding 2건 |
| 제품 targeted tests | **NOT_RUN**, 슬롯 조율 전 실행하지 않음 |
| unit/full suite/type/lint/Doctor | **이번 B NOT_RUN** |
| build/browser/N150 heavy slot | **NOT_RUN** |
| exact e2a 원격 CI | 직접 관찰 없음; green 주장 없음 |
| 운영 로그인/API/DB/컨테이너/apply | **NOT_RUN / 변경 0** |
| 전달 r1 | manifest상 type/guard PASS; unit412 PASS 7 FAIL +1 unhandled; lint1; Doctor17 |
| 전달 r2 | manifest상 type/lint PASS; targeted38 PASS; **Doctor6** |
| 전달 final gate | full unit/type/lint/Doctor/build/browser/CI **PENDING** |

r1/r2 remote raw log는 이번에 가져오지 않았다. 표의 숫자는 manifest의 전달 사실로만 기록하며, r2가 e2a 최종 full suite를 증명한다고 간주하지 않았다. 이후 737/dirty 수정이나 다른 head 결과를 e2a 성공으로 소급하지 않았다. 사용자 지정 자원 경계(root/tmp 부족, N150 heavy 최대2)를 따라 새 install/fullbuild/Doctor 및 중복 suite를 실행하지 않았다.

## 5. 실제 명령과 재현 범위

모든 shell 호출은 Windows PowerShell workdir C:\ 에서 wsl.exe -e bash -lc 또는 wsl.exe -e python3를 사용했다. 제품 checkout/worktree 수정 없이 아래 종류의 명령으로 Git object만 읽었다.

~~~text
git -C REPO ls-tree -r -z BASE
git -C REPO ls-tree -r -z HEAD
git -C REPO rev-parse HEAD^{tree}
git -C REPO show REF:PATH
git -C REPO diff --unified=3 BASE HEAD -- PATH
git -C REPO diff BASE LIVE -- packages/kor-travel-transport-admin/frontend/lib/dagster.ts
git -C REPO grep -n -F stationSeq HEAD -- packages/kor-travel-transport-admin/frontend/
git -C REPO grep -n -F korail.com/ticket HEAD -- packages/kor-travel-transport-admin/frontend/
git -C REPO grep -n -F general_rail_timetable_collection_job BACKEND499 -- backend/app/dagster
python3 /home/digitie/dev/common-unification-20261111/review-B-transport-admin-preservation-e2a925-evidence/static-audit.py
~~~

REPO/BASE/HEAD/LIVE/BACKEND499는 §1의 exact 값이다. static-audit.py는 Git inventories/hash/메모리 archive metadata를 검사하는 보존된 실제 실행 스크립트다. 애플리케이션 함수의 Python mirror 테스트나 제품 test suite가 아니다. findings-static.json에는 각 소스 참조의 실제 Git blob OID/SHA256과 실행하지 않은 공격 경계의 정적 판단을 별도로 기록했다. 참고 inventory는 validation/transport-ui-compatibility-936-readonly-20261112의 static-evidence.json/기능보존-정적조사.ko.md/C11 supplement이며, 이를 runtime receipt로 바꾸어 읽지 않았다.

## 6. 최종 disposition

**e2a SOURCE BLOCK.** B-TR-P2-01과 B-TR-P3-02는 이 원문에서 OPEN이다. packages/lock/C11 bytes 및 auth/proxy/backend 경계에는 이번 정적 검토에서 추가 finding을 발견하지 못했다.

manifest의 mergeAllowed=false와 admin936ActivationAllowed=false는 유지한다. Public936 상태는 별도 owner의 운영 사실이며 이 admin 리뷰로 변경하거나 확대하지 않는다. 최종 X의 정확한 Git/manifest에서 두 finding closure와 기존 기능 계약을 재확인하고, Doctor6 및 최종 tests/build/browser/exact CI 증거를 분리 검토해야 한다. 본 원문과 e2a 입력은 이후 수정/성공 여부와 무관하게 불변 보존한다.
