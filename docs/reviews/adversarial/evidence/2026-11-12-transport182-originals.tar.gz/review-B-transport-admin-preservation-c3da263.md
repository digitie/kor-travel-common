# Transport admin c3da263 INPUT2 — 독립 B 후속 원문

- Reviewer: Epicurus / original B. 구현 비참여, 읽기 전용 packaging/provenance/security/release 및 기능 비회귀 리뷰.
- Run ID: Epicurus-B-transport-c3da263-input2-20261112T005854Z.
- UTC: 입력 관찰 2026-11-12T00:58:54Z; Git/hash 증거 생성 2026-11-12T01:01:09.781527Z.
- **Verdict: SOURCE PASS / 본인 finding 2건 FIXED / 새 finding 0건.**
- **실행·merge·배포 승인은 OPEN.** exact c3 full gates/browser/CI를 이번에 관찰하거나 실행하지 않았다. 최종 X 실행 증거와 merge/image/실제 수용에 대한 후속 검토가 필요하다.
- 최초 e2a 원문 BLOCK과 그 severity/증거는 그대로 보존했다. 상대 현재 A2 원문/결과는 읽지 않았다.

## 1. 불변 입력과 검증 방법

입력:
`/home/digitie/dev/common-unification-20261111/validation/review-transport-admin-preservation-c3da263-input2/manifest.json`

직접 읽고 고정한 SHA256:
`70ce298c0c57efbb3016665b3cf3ca13924354000115c51802cc34b07dca4473`

Repository:
`/home/digitie/dev/common-unification-20261111/kor-travel-transport`

| 구분 | exact Git ref |
|---|---|
| base936 | 936fdb90b0ee9f6392d2f888255053ee1f4066b2 |
| 원 리뷰 head e2a | e2a925086925fd353bd3705f8ea3ae96ac3810a5 |
| INPUT2 head | c3da2632101c347a5e4fc288762de635c9c255b5 |
| INPUT2 tree | 077e7c14f87aa55fe1774c0a706bcf9f1e3e509c |
| 실제 live admin 기준 source | 6bd594e606ef7d0326ec5742942e83997708946e |
| 실제 backend 계약 비교 source | 499822601abca3f050aa0cfe0e27fb446d22281d |
| 교정 focused 증거의 after source | b96290aca3cfb8d92b1c0b22e8669dfb15864272 |

Git ls-tree/show/diff로 base→c3 **53개 변경**, e2a→c3 **13개 경로**, 보호 **295개**의 mode/type/OID 동일성을 직접 확인했다. changed-blobs 53개 각각의 base/head OID, head SHA256/길이, changedAfterFirstReview 표기와 세 inventory/sidecar hash도 대조했다. moving worktree의 추가 변경은 포함하지 않았다.

최초 본인 원문 `review-B-transport-admin-preservation-e2a925.md`의 SHA256은 여전히
`f8ee357e7b0aab88b0f3261c464e50abc58ab9e8b51500afef068e694a02a2f1`이다. 이를 수정하지 않았고 이전 BLOCK을 소급하여 PASS로 바꾸지 않았다.

## 2. 본인 finding closure

아래 소스 경로 prefix는 `packages/kor-travel-transport-admin/frontend/`이고 line은 c3 head 기준이다.

### B-TR-P2-01 — FIXED (원 severity P2 보존)

**공식 링크:** `components/general-rail-station-detail.tsx:14`에서 고정된 코레일 HTTPS URL에 encodeURIComponent(station.provider_id)를 붙인다. provider가 없으면 링크를 생성하지 않고 target=_blank / rel=noreferrer를 지정한다. 외부 입력은 URL의 stationSeq 값으로만 들어간다.

**전화 링크:** 같은 파일 :13에서 원 표시 번호와 별개로 tel href에는 기존과 같은 /[^+\d]/g 정제를 적용한다. 테스트의 `+82 (2) 123-4567`은 `tel:+8221234567`을 요구한다. React가 전화 문자열을 텍스트로 렌더링하며 외부 href scheme을 입력값으로 선택하지 않는다.

**주소 지도 action:** 같은 파일 :11–12는 onShowMap과 주소가 있는 경우 실제 Button을 만들고 hasCoordinates가 거짓이면 disabled 처리한다. `components/general-rail-guide.tsx:46`은 callback에 setView("map")과 choose(selected)를 연결한다. choose는 기존 selection/focusRevision 경로를 사용한다. 따라서 단순 callback prop 추가에 그치지 않고 실제 부모 지도 이동까지 연결되어 있다. 새 compact 시간표 상세도 같은 renderer에 유지된다.

**회귀 증거:**

- `components/general-rail-station-detail.test.tsx:12` 이하가 특수문자 provider ID `역/1 &?=`의 정확한 encoded href, target/rel, 정확한 tel href 및 새 시간표 유지까지 검사한다.
- :21 이하가 실제 버튼 click의 callback 횟수와 좌표 없는 경우 disabled/no callback을 검사한다. :32 이하는 provider/전화 부재 시 가짜 링크가 없음을 검사한다.
- `e2e/admin-review-regressions.spec.ts:16` 이하에 375/1440 실제 상세의 href, 전화 링크, 지도 탭 선택, detail focus, 화면 overflow 검사가 추가됐다. **해당 browser는 이번에 실행/통과 관찰하지 않았다.**
- 수정 renderer/부모 연결/label 소스 3개는 b962와 c3 Git blob이 같다. 본인 상세 테스트 및 label 테스트의 c3 bytes도 교정 focused 증거의 SHA256과 같다.
- 전달된 교정 before JSON에서는 공식·전화 테스트와 주소 action 테스트가 각각 failed, after JSON에서는 passed다. 이 파일들의 실제 hash와 결과를 본인이 직접 확인했다. 자신의 새 테스트 실행으로 표기하지 않는다.

이 근거로 **소스 finding을 FIXED**로 닫는다. 실제 375/1440 browser 수용은 별도 미완 gate다.

### B-TR-P3-02 — FIXED (원 severity P3 보존)

`lib/dagster.ts:13`에 다음 exact mapping이 복원됐다.

~~~ts
JOB_LABELS.general_rail_timetable_collection_job = "일반철도 예정 시간표";
~~~

이 key는 backend499에 정의·등록·스케줄된 실제 작업명과 일치한다. 기존 collection-status/dagster-operations/operations-home 소비 코드는 e2a와 동일하고, mapping을 공통으로 읽으므로 raw 영문 이름 fallback 대신 원 한글 표시를 받는다. 작업 실행/취소/스케줄 lifecycle 변경은 없다.

`components/dagster-shadcn.test.tsx:103` 이하의 실제 job snapshot 테스트는 run과 schedule 양쪽에서 한글 이름이 두 번 출력되고 raw 이름은 노출되지 않음을 요구한다. 교정 before에서는 이 테스트가 failed, after에서는 passed다. c3 mapping과 테스트 bytes의 bridge도 직접 확인했다. 따라서 **소스 finding FIXED**이며 실제 운영 Dagster 호출이나 job 실행은 하지 않았다.

## 3. e2a 이후 13개 경로의 독립 delta 검토

실제 구성은 runtime 소스 5개, 테스트 6개, 문서 2개다.

**Map helper 추출:** transport-map의 region state/memo/배치 effect를 useFuelRegionCards로 옮긴 부분과 MapStatusSummary/MapFuelGuidance, truncatedListKinds/onlyRailStations, REFERENCE_LIST_KINDS를 전후 대조했다. 기존 조건·empty-array 처리·유종 집계·좌표 없는 reference list 범위·truncation·summary 전달을 유지한다. hook은 조건 없이 호출하고 setFuelRegions는 React state setter이므로 새 effect dependency로 추가되어도 매 render마다 새로운 setter를 만드는 구조가 아니다. 추가된 mapContainer dependency 역시 기존 ref를 전달한다.

**클러스터 identity:** `components/transport-map.tsx:555`의 React key는 count/kind_counts를 포함하는 JSON 전체값에서 full precision longitude/latitude 조합으로 바뀌었다. 같은 좌표의 집계만 바뀌어도 key가 유지되고, 반올림 시 충돌하던 두 근접 좌표는 다른 key를 가진다. 추가 테스트는 count label 갱신뿐 아니라 같은 DOM 참조와 document.activeElement, 두 근접 묶음의 순서 변경 후 각각의 DOM 참조를 검사한다. 450ms debounce flush가 act를 빠져나온 뒤 identity/focus assertion을 수행하도록 교정됐고, 해당 assertion을 삭제하지 않았다.

interactionId의 기존 소수점 여섯 자리 표기는 React key와 구분해 읽었다. 실제 불변 VWorld tgz의 Marker.tsx/VWorldMapView.web.tsx에서 이 값이 dataset/interaction context로 전달되는 경로를 확인했다. 이 소비 경로에 같은 interactionId로 React marker를 합치는 registry 동작은 발견하지 못했다. 실제 SDK focus 보존은 여전히 browser gate가 필요하다.

**Metro notice 추출:** metro-station-detail의 collection_status별 no_data/error/pending 문구를 MetroCollectionNotice로 옮겼다. 같은 조건과 JSX 문구이며 API/status 계약을 바꾸지 않는다.

**미지원 API 테스트 정정:** route.test.ts/upstream.test.ts의 `transport/fuel/regions`를 성공 경로에서 제거하고, 인증 후에도 404/no upstream call 및 null URL을 요구하는 음성 검사로 바꿨다. backend499에 없는 endpoint를 추가 허용하는 수정이 아니다. 실제 fuel_regions는 기존 features/places payload 경로로 계속 소비한다. lib/transport.ts, lib/upstream.ts 및 실제 proxy/auth 소스는 e2a와 동일하므로 allowlist 범위나 인증을 넓히지 않았다.

**Loopback fixture 경계:** `e2e/admin-review-regressions.spec.ts:7–9`는 Playwright config와 같은 E2E_BASE_URL/default를 파싱하고 hostname이 정확히 127.0.0.1/localhost/[::1]인 경우에만 mock cookie를 추가한다. mock API route 설치와 page.goto보다 앞에서 검사하며, 도메인 suffix 매칭은 아니다. URL의 origin을 cookie URL로 사용한다. Playwright config 자체는 변경되지 않았다. 이 증거는 격리 local server의 frontend 렌더/SDK 회귀 검사이며 정상 운영 인증이나 backend499 end-to-end 검증을 증명하지 않는다.

두 SDK marker browser case는 E2E_MAP_SDK가 true가 아니면 skip한다. 최종 gate는 true로 실행한 결과와 실제 skip 수를 확인해야 하며, 상세 두 case만 통과한 결과를 네 case 전체 수용으로 읽을 수 없다.

**문서:** journal/resume의 새 prepend만 검토했다. 25P4F→29P를 b962 focused 결과로 제한하고 초기 harness 실패를 보존하며, 전체 CI/운영 수용과 구분한다. 관리자936 적용 전 미완 상태를 유지한다. 현재 c3 배포 완료나 운영 정상 인증 완료라는 주장으로 확대하지 않았다.

이 delta에서 **새 finding은 0건**이다. 상대 finding의 독립 closure 판정을 대신한 것은 아니다.

## 4. C11 동일 bytes / API499 / security 경계

보호 295개 경로는 base936/c3에서 모두 동일하다. public frontend, backend/app/tests/migrations/uv.lock, admin package/lock/common-artifacts/vendor 및 지도 vendor 고지가 포함된다.

public 4개/admin 6개 실제 Git tgz 사본, 총 **10개**를 메모리에서 읽어 SRI를 재계산했다. 실제 archive package.json name/version/license, common-artifacts entry와 lock resolved/integrity/version/license가 일치한다. base936/e2a/c3의 해당 tgz blob도 모두 같다. LICENSE/NOTICE 경로를 기록했고 source/package 재발행·repack·설치는 하지 않았다.

UI/tokens GPL-3.0-or-later, VWorld GPL-3.0-only, LightningCSS MPL-2.0, Scope MIT 선언과 고지는 이번 delta에서 변하지 않았다. 과거 fork의 전체 license/sourcegate를 다시 승인한 것이 아니라 동일한 전달 bytes와 이번 경계의 보존을 확인한 것이다.

주차장/도시철도/일반철도 API 호출 소스와 route allowlist는 e2a 이후 바뀌지 않았다. 이전 backend499 schema/route 대조의 입력도 동일하다. 새 server endpoint/provider/임의 upstream host 또는 세션·origin·write 범위 확장은 없다. backend499는 계약 대조 ref이며 candidate backend0036/실제 DB0042의 migration·sync·교체를 승인하거나 수행하지 않았다.

## 5. 증거의 실행 수준과 한계

교정 focused 증거:
`validation/transport-admin-review-followup-before291-20261112/corrected-before-after-manifest.json`

SHA256:
`921f6e311bbe596a3e84dd7ef65287864ee59b453f8ffac9786ce3b441efc5e6`

manifest가 지목한 **10개 artifact hash를 직접 확인**했고, 실제 corrected JSON에서 before291 29개 중 25 PASS/4 FAIL/0 pending/success=false, after b962 29 PASS/0 FAIL/0 pending/success=true를 읽었다. before의 네 실패는 label, official/tel, address action, cluster DOM identity였다.

기존 after 28P1F의 act 대기 문제를 실제 DOM focus 실패 재현으로 재사용하지 않았다. 교정된 동일 테스트에서 label 갱신 뒤 DOM identity assertion이 실패한 before와 after의 차이를 구분했다.

c3는 b962 이후 docs·loopback browser fixture·map test 교정/추가·full precision cluster key 변경을 포함한다. 특히 map source/test는 b962와 동일하지 않다. 본인 finding의 동일 소스/테스트 bridge는 입증했지만 **29 PASS를 c3 full suite나 근접 좌표 browser PASS로 확대하지 않는다.**

| gate | 본인 관찰/처리 |
|---|---|
| manifest/tree/53변경/13delta/295보호/10tgz | 직접 정적 검증 |
| 본인 P2/P3 소스 closure | FIXED |
| 교정 focused before/after | 전달된 실제 파일의 hash/JSON 결과 직접 확인, 본인 재실행 아님 |
| 신규 own targeted product tests | NOT_RUN |
| exact c3 type/lint/full unit/Doctor/guard | 이번 미실행; freeze 시 pending |
| exact c3 native/Alpine build/browser | 이번 미실행; freeze 시 pending |
| exact c3 remote CI/policy | 이번 직접 조회/관찰 없음; 이전 head green 대체 금지 |
| 실제 merge tree/image/common bytes bridge | NOT_RUN / 별도 gate |
| 실제 운영 정상 인증/관리자 UI 수용 | NOT_RUN / 별도 gate |
| 설치·source 수정·backend/DB/운영 mutation | 0 |

N150 owner heavy slot을 사용하지 않았고 새 install/full suite/Doctor/build/browser를 중복 실행하지 않았다. Git/hash/archive 읽기는 제품 실행 테스트가 아니다. 이후 gate 성공이 별도로 들어와도 이 원문의 시점/관찰 한계는 바꾸지 않는다.

## 6. 명령·독립 evidence와 최종 판정

모든 shell 호출은 Windows PowerShell workdir C:\ 에서 wsl.exe를 통해 수행했다.

~~~text
git -C REPO ls-tree -r -z BASE936
git -C REPO ls-tree -r -z E2A
git -C REPO ls-tree -r -z C3
git -C REPO rev-parse C3^{tree}
git -C REPO show EXACT_REF:PATH
git -C REPO diff --unified=3 E2A C3 -- PATH
git -C REPO diff B962 C3
python3 -       # 보존한 static-audit.py 내용으로 inventory/hash/archive 검증
~~~

REPO/ref는 §1 값이다. 직접 실행 스크립트는 다음 evidence 폴더에 동일 내용으로 저장했다.

`/home/digitie/dev/common-unification-20261111/review-B-transport-admin-preservation-c3da263-evidence/`

| 파일 | SHA256 |
|---|---|
| manifest.json | 70ce298c0c57efbb3016665b3cf3ca13924354000115c51802cc34b07dca4473 |
| focused-proof-manifest.json | 921f6e311bbe596a3e84dd7ef65287864ee59b453f8ffac9786ce3b441efc5e6 |
| static-audit.py | 0b32403fcf9df6a31d160468d30af61bafc26f7c9e0f3aeac9cf460c4d76854c |
| static-proof.json | dd33f9a7fe142fd9aa742f94f7520070d38cd837581890f1e63fafa5c4b860fa |

static-proof.json에는 변경 blob 증명, 13개 delta, 보존 boundary, vendor별 SHA/SRI/license, b962→c3 차이, 본인 finding의 source/test bridge, 원문1 보존 hash와 focused 결과를 기록했다. evidence/raw 이외의 source/index/설치 모듈은 변경하지 않았다.

**c3 SOURCE PASS — B-TR-P2-01 FIXED, B-TR-P3-02 FIXED, new findings 0.**

manifest의 mergeAllowedAtFreeze=false / admin936ApplyAllowed=false를 그대로 존중한다. exact 최종 gates/CI/375·1440 browser, merge-tree→image provenance 및 공식 admin-only 적용 후 정상 수용은 별도 충족해야 한다. 본 원문은 그 실행 gate를 닫지 않는다. 최종 X bounded followup은 여전히 필요하다.
