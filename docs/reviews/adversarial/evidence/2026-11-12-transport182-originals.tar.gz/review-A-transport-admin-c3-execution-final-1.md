# Transport c3 실행 증거 — 독립 리뷰 A 최종 bounded 확인

- runid: `review-A-transport-admin-c3-execution-final-1-20261112T013146Z`
- 원 리뷰어 A/Mill. 구현 비참여·읽기 전용. 현재 상대 B3 결과 미열람.
- 감사 UTC: `2026-11-12T01:31:46`–`2026-11-12T01:34:22`.
- **판정: PREMERGE SOURCE + QA GATE PASS. 신규 finding 0건. 운영 배포/수용 승인은 별도 미완이다.**

## 고정 입력·과거 기록

manifest `validation/review-transport-admin-c3-execution-final-1/manifest.json`의 직접 SHA256은 `32ad35db674592834cdd74be247b6ddf65f69c3df22ab398c81acc5cae92bd2d`로 일치한다.

검토 source는 변경 없이 `c3da2632101c347a5e4fc288762de635c9c255b5`, tree `077e7c14f87aa55fe1774c0a706bcf9f1e3e509c`다. 실제 CI log의 checkout은 synthetic `072c51d1991eed79ed768d7c029ca7dabf45fad1`이고, 로컬 Git object를 직접 읽어 이 synthetic의 부모가 base936/c3da이며 **전체 tree가 c3da와 동일**함을 확인했다. 실제 main merge M의 증명은 아직 아니다.

원문1 SHA256 `489b0cb8d344297867986a921e76160bde5f1b9a8a02619c5e3d41b7b57cc07b`, 원문2 SHA256 `0a5f55a4998502eddc383c38ec388d020d4035fb5b60af57a6a4114fee50c476`이 그대로다. 원문1 BLOCK, 원문2 SOURCE CODE PASS/실행 pending은 당시 관찰로 보존한다. 원문2의 본인 A-P2-01·A-P2-03·A-P3-02 소스 FIXED 판정을 유지하고, 여기서는 실행 증거만 확인했다. packet에 포함된 이전 B 원문은 hash만 계산했으며 텍스트를 읽거나 판정 근거로 사용하지 않았다.

## 직접 확인한 실행·바이트 근거

| 대상 | 독립 감사 결과 |
| --- | --- |
| GitHub main `43130997296` / 정책 `43130998009` | connector로 두 run completed/success 직접 조회. main frontend/admin/backend 및 정책 두 job success |
| 실제 CI raw logs | 세 job log 직접 조회. public 164P, admin 432P, backend **1548P/2skip/6warnings/1788.26s**. checkout072c51 확인. admin Doctor `No issues found!`; type/lint/build/guard step success |
| CI live-e2e `130894804548` | **skipped**. 이를 PASS로 세지 않음. 별도 exact-source native/Alpine QA가 아래 실행 근거 |
| QA handoff | `validation/transport-admin-c3-harvey-qa-20261112/handoff-manifest.json` SHA256 `5de3d250e99aad051e122056fbca98607adc6720bd24bdfefa9daaf23d65c0c7` 및 열거된 **56개 원시 파일** hash 전부 직접 일치 확인 |
| QA 소스 연결 | source receipt의 904개 hash를 `git ls-tree` + `git cat-file --batch`로 c3da 실제 blob 내용과 직접 검산. Git blob 집합도 정확히 904개로 같고 불일치0 |
| c3da 로컬 gate | 제공 raw type/lint/unit/Doctor/guard의 exit0 및 432P 확인. 집계 갱신과 근접 좌표 재정렬 unit 두 case의 실제 통과 줄도 확인 |
| 브라우저 원시 JSON 6개 | native 18+4+6, Alpine 18+4+6 = **56 PASS**. 모든 개별 test가 expected/passed, 단일 result/retry0/errors0. skipped/flaky/unexpected/report errors 모두0 |
| 실제 common 바이트 | harness가 lock/SRI와 각 tarball 전체 파일을 실제 설치 경로와 비교하는 방식 확인. native 25+94+19+25+85+15=263개, Alpine `ALL_ACTUAL_BYTES_MATCH 263` 원시 기록 일치 |
| build/image source | native/Alpine build exit0. 이미지 source audit 293개 일치와 compiled route32, `/parking-lots`, `/rail/timetable` 확인. 293개 입력도 Git receipt에서 직접 도출. 제외 `.env.example` 1개는 committed Dockerignore와 일치 |

56개 원시 **파일**과 56개 브라우저 **사례**는 서로 다른 집계다. 부모의 summary만 신뢰한 것이 아니라 파일 hash, 실제 Playwright result 배열, 실행 config/harness, 검사 대상 테스트 assertion을 직접 대조했다. 자체 테스트를 다시 실행하거나 새 build/install을 하지 않았다.

QA 이미지 `sha256:61c8581a26f187680908c6939deaca2b93973895df67365835d755bf45324a79`의 audit는 **linux/x64 builder 이미지**다. 이를 미래 merged M의 ARM 운영 이미지 증거로 사용하지 않는다. cleanup 영수증은 자체 native server 종료 및 컨테이너 running=false/activeOwnHeavyJobs0을 기록한다. 새로운 실호스트 process 검사는 실행하지 않았다.

## 실제 SDK focus·UI 의미 확인

동일 c3da Git test와 hash 고정된 QA harness를 대조했다. E2E_MAP_SDK=true가 설정되고 모듈 바이트 비교 후 실제 Next production build를 구동한다. 실제 VWorld Marker를 mock button으로 바꾸는 단위 모형이 아니다. 타일은 격리 PNG fixture다.

- repo 회귀 4개/환경: 375·1440px 각각 공식 안내 URL encoding·전화 정제·주소 지도 이동을 확인하고, 각각 실제 Marker를 focus한 뒤 count 2→3 응답에서 **동일 DOM element와 focus 유지**를 검사한다. 새 요소를 다시 focus해서 통과시키는 검사가 아니다. native/Alpine의 이 네 Marker 사례가 모두 실제 passed/retry0이다.
- 별도 기능 계약 6개/환경: 일반 주차장 검색 trim/특수문자·cursor 전달/중복 합치기·무좌표 상세·0원/정적 정보 의미, 안내명으로 운행 station ID를 추측하지 않고 실제 후보 선택 후 조회·교환/지난 편 필터, 공식 코드 역의 첫막/전체표·운행기준7/8/9 및 다른 운행일의 분후예정 억제를 검사한다. 375·1440px 모두 통과했다.
- 기존 18개/환경: RHF 로그인 실패 재시도·Pretendard/반응형, 다중 필터·탭 작업면, 버스/공항 표시, 수동 매핑의 오래된 변경 방지·Dialog Tab/Escape 복귀 등을 유지한다.
- 근접 좌표 재정렬의 full-precision key는 이번 exact c3da unit432 안에서 통과했다. 위 실제 SDK browser는 count 갱신 사례다. 브라우저에서 근접 좌표 재정렬까지 추가 검증했다고 확대하지 않는다.

모의 쿠키/API/PNG를 사용하는 격리 UI 동작 증거다. 정상 운영 인증, 실제 API499 데이터/수집/DB0042, 외부 타일 서비스 가용성의 최종 수용을 대신하지 않는다. 테스트의 공식 링크 href 검증도 외부 Korail 사이트의 실시간 응답 보장은 아니다.

## 한계·남은 gate

이번 premerge 실행 조건은 통과했다. 원문2에 남아 있던 exact source QA/CI 미완을 이 새 기록에서 해소하되, 아래는 **아직 미완/별도**다.

1. 실제 merge M 및 전체 tree bridge.
2. merged M의 새 ARM image, OCI/default ENV/source 연결 및 실제 common263 바이트 audit.
3. Aquinas의 공식 admin-only SDK dryrun/confirm/apply/current/postproof.
4. Mendel의 정상 운영 로그인과 table/font/map 및 기능 보존 실제 수용.

CI live-e2e skipped와 backend의 2skip/6warnings를 숨기지 않았다. 소스 평가 전체를 반복하지 않았고 새 코드·배포·계정·운영 API 조작은 없다. 기존 raw와 현재 상대 결과는 보존/비공개 조건을 지켰다.

명령/도구: PowerShell workdir `C:\`→`wsl.exe --exec python3 -`, hashlib/SHA256, `git show -s --format=%H%n%T%n%P`, `git ls-tree -r -l -z`, `git cat-file --batch`; GitHub connector의 exact-head workflow runs, 두 run jobs 및 세 job logs 조회. 자기 tests/build/browser 재실행0, 운영 변경0.

자기 증거 디렉터리: `review-A-transport-admin-c3-execution-final-1-evidence/`의 `packet-hash-verification.json`, `independent-evidence-audit.json`(904/56파일/56사례), `github-direct-observation.json`, `audit-observations.json`. 최종 판정은 **동일 c3da의 PREMERGE SOURCE+QA PASS / 신규0 / 미래 운영 승인 미완**이다.
