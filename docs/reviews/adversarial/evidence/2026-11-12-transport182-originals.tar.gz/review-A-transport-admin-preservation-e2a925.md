# Transport 관리자 기능 보존 e2a925 독립 리뷰 A 원문

- runid: `review-A-transport-admin-preservation-e2a925-20261112T001246Z`
- 역할: 원 독립 리뷰어 A/Mill, frontend/accessibility/domain regressions. 구현 비참여, 읽기 전용. 상대 리뷰의 원문·판정 미열람.
- 관찰 시작 UTC: `2026-11-12T00:12:46.040238+00:00`
- 종료 관찰 UTC: `2026-11-12T00:24:35.647527+00:00`
- 판정: **BLOCK — e2a 소스 P2 2건 OPEN, P3 1건 OPEN. 최종 X 별도 불변 입력 재검토 필수.**
- 집계: P0 0 / P1 0 / P2 2 / P3 1. 아래 세 건은 서로 다른 원인이다. 미실행 테스트를 실패 실행으로 세지 않았다.

## 불변 입력 및 실제 관찰

저장소는 `/home/digitie/dev/common-unification-20261111/kor-travel-transport`다. 검토 packet은 `validation/review-transport-admin-preservation-e2a925086925/manifest.json`이며 직접 계산한 SHA256은 `0721412625b76db6ee1eda5c789ab319b6a20950f5ac630c94afad9ac1a6e136`이다. 시작·종료 모두 같은 값이었다.

| 역할 | 정확한 Git 값 |
| --- | --- |
| C11 baseline | `936fdb90b0ee9f6392d2f888255053ee1f4066b2` |
| 이번 검토 head | `e2a925086925fd353bd3705f8ea3ae96ac3810a5` |
| 이번 검토 tree | `21b87f7b2e38152d09c8cbec372f682405dbfdc7` |
| 기존 운영 관리자 기능의 소스 | `6bd594e606ef7d0326ec5742942e83997708946e` |
| 기능 분기 공통 조상 | `59e1d8213c09a82a4ed9cc4396a6414ef0332b9c` |
| 운영 API 계약 대조 Git | `499822601abca3f050aa0cfe0e27fb446d22281d` |

시작 시 작업트리 HEAD는 `73739c8c52d9a5d42bb4e1dce089e615f9b6a4be`였고 `components/transport-map.tsx`가 dirty였다. 종료 시 HEAD는 `291389565ab923a6eea5c2ed87097a1071292e0e`, status는 clean이었다. **두 작업트리 상태의 제품 소스를 검토 입력으로 사용하지 않았다.** 아래 모든 제품 파일·줄 번호는 e2a Git blob 기준이다. 이후 head에 이미 수정이 있어도 이번 원문을 소급해 닫지 않는다.

`git diff base head --name-status`의 변경 49개, 변경하지 않은 tracked path 854개, 보호 목록 295개를 Git tree 기준으로 확인했다. 보호 목록의 mode/type/blob은 모두 base와 동일하다. backend/public frontend/auth/vendor/package/lock/C11 원장의 변경은 이번 carry에 없다. 이것은 base 대비 바이트 보존 근거이며 운영 서비스나 DB를 새로 점검했다는 뜻이 아니다.

packet의 세 부속 파일 SHA256도 일치했다.

| 파일 | SHA256 |
| --- | --- |
| `base-git-inventory.json` | `dd170bddeeba3e1fe878c634f5ab457ee47adc0cf17de27dc24f03510901c401` |
| `head-git-inventory.json` | `78096fb4eb4ffa5df86a7e8ad301500f3fd7213c2195d6d5949be6d63b1cdbe5` |
| `changed-blobs.json` | `45fb4c452838862044395a2de103842a702d5269a0e3e14617141853bbd00a20` |

변경 49개 각각의 base/head mode/type/Git blob, 실제 head 내용의 SHA256/길이를 `changed-blobs.json`과 재대조해 불일치 0개였다.

## Findings

아래 파일 경로는 모두 `packages/kor-travel-transport-admin/frontend/`에 상대적이다.

### A-TRANSPORT-P2-01 — 실제 없는 지역 유가 endpoint의 성공을 요구하는 테스트 계약

- 위치: `lib/upstream.test.ts:20` 및 `:21`; 실행 분기 `lib/upstream.ts:12`, `lib/transport.ts:34`–`:38`.
- disposition: **OPEN / P2**. 기존 live에서 carry된 잘못된 계약을 새 API 허용 요구로 해석하면 안 된다. manifest가 이미 공개한 테스트 미완료와 별도로 원인을 특정한 것이며, 단위 테스트를 직접 실행한 결과라고 주장하지 않는다.
- 정적 재현 입력: `transportUpstreamUrl(["transport", "fuel", "regions"], new URLSearchParams("day_code=7"))`.
- 실제 소스 분기: `TRANSPORT_ENDPOINTS`에 이 경로는 없고, 별도 허용 네 패턴에도 해당하지 않으므로 반환은 `null`이다. 따라서 테스트의 `?.pathname`은 `undefined`인데 기대값은 `/v1/transport/fuel/regions`여서 해당 case는 통과할 수 없다.
- 계약 대조: 운영 API Git499의 `backend/app`에 `fuel/regions` 경로가 없다(`git grep -F`, exit1, matches0). 지역 유가는 `transport/features/places` 응답의 `fuel_regions`이며 API source의 `main.py:1437`, `:1589`, `schemas.py:444`에 연결된다. e2a 지도도 이 응답을 읽는다. inventory의 legacy endpoint 경고와 일치한다.
- 영향: 제출한 정확한 소스의 회귀 테스트가 실제 API 계약과 모순된다. 테스트를 green으로 만들려고 허용목록/백엔드에 가짜 endpoint를 추가하면 UI 보존 범위를 벗어난다.
- 권고: `/features/places`의 `fuel_regions` 수신을 검사하고, `/fuel/regions`는 unsupported 음성 case로 보존한다. 실제 존재하는 공식 코드 역/역별 시간표의 양성 case는 유지한다. 최종 X에서 수정된 정확한 테스트와 제품 분기 일치를 재확인해야 한다.

### A-TRANSPORT-P3-02 — 일반철도 수집 작업의 한국어 표시명 누락

- 위치: `lib/dagster.ts:13`–`:14`; 사용처 `components/dagster-operations.tsx:12`.
- disposition: **OPEN / P3**.
- 정적 재현: 일반철도 작업명이 `general_rail_timetable_collection_job`인 snapshot을 공통 Dagster 화면에 전달한다. 현재 `JOB_LABELS[name] ?? name`은 한국어 이름 대신 내부 job 식별자를 그대로 표시한다.
- 원본 대조: live6bd의 `lib/dagster.ts:14`에는 `JOB_LABELS.general_rail_timetable_collection_job = "일반철도 예정 시간표"`가 있다. e2a는 이 파일이 936과 그대로여서 해당 한 줄을 이관하지 않았다.
- 영향: 이미 운영하던 일반철도/도시철도 작업의 사용자 구분이 후퇴한다. 수집 실행이나 API 권한의 결함으로 확대하지 않는다.
- 권고: 기존 한국어 label만 복원하고 실제 snapshot의 표시명 회귀 검사를 둔다. job lifecycle·실행 예산·스케줄·backend 변경은 이 수정에 필요하지 않다.

### A-TRANSPORT-P2-03 — 집계 값이 React key에 들어가 같은 클러스터의 포커스 DOM을 교체

- 위치: `components/transport-map.tsx:527`.
- disposition: **OPEN / P2**. React key/Marker 정리 경로를 근거로 한 소스 결함이며 실제 브라우저의 activeElement 전후 측정은 **NOT_RUN**이다.
- 코드: `serverClusters.map(item => <MapMarkerButton key={JSON.stringify(item)} ... interactionId={좌표 기반 값} ...>)`.
- 반례: 좌표와 순서가 같은 cluster에 대해 count만 2→3으로 갱신한다. `interactionId`는 동일하지만 JSON key는 바뀐다. `kind_counts` 등의 내용 갱신도 같은 문제가 된다.
- 유효 경로: 지도 조회 effect는 필터가 같으면 기존 결과를 유지한다(`:359`–`:364`). 이후 `applyPayload`가 새 `payload.clusters`를 넣는다(`:367`–`:382`). 따라서 기존 cluster DOM을 유지하며 집계만 갱신할 수 있는 상황이다.
- 정리 경로 확인: `components/map-overlays.tsx:79`가 실제 `vworld-map-web`의 `Marker`를 사용한다. e2a가 담은 정확한 `vendor/vworld-map-web-1.0.3.tgz`의 `package/dist/components/Marker.js:147`은 새 Marker를 만들고, `:206`–`:219` cleanup은 `marker.remove()`를 호출한다. key가 바뀌면 기존 포커스 요소가 제거되고 새 Marker는 일반 갱신에서 포커스를 복원하지 않는다. `transport-map.tsx:245`–`:264`의 observer는 overlap 팝업을 닫았을 때만 잠시 실행되므로 일반 cluster 갱신을 보호하지 않는다.
- 바이트 근거: 이 tgz는 88,106 bytes, SHA256 `1ab9af8794979a5a19e5ac635cd04a9e87b9847058eaf4e9df743143b8ad4104`이고 루트 C11 동결 pack과 전체 바이트가 같다. 다른 버전의 Marker 구현으로 추정하지 않았다.
- 원본 비교: 936 key는 `${item.longitude}:${item.latitude}`, live6bd는 좌표와 index다. 둘 다 같은 좌표·순서에서 count 변경만으로 key를 바꾸지 않는다. 이번 JSON 전체 key 변경은 이 보존 성질을 잃는다.
- 영향: keyboard 사용자가 cluster에 초점을 둔 상태에서 늦은 응답/재조회로 집계가 갱신되면 DOM 정체성이 사라지고 포커스를 잃을 수 있다. 같은 항목의 데이터 갱신이 탐색 위치를 초기화한다.
- 권고: 도메인/좌표의 안정된 정체성으로 key를 고정하고 집계·접근 이름만 갱신한다. 동좌표의 여러 항목이 가능하면 변하는 전체 객체 대신 안정된 도메인 구분자를 사용한다. 최종 X에서 같은 좌표·순서/count만 변경하는 응답 전후에 DOM 동일성 및 실제 포커스를 검증해야 한다. 이 원문은 브라우저 재현 PASS나 운영 장애 관찰을 주장하지 않는다.

## 기능 보존 대조 및 추가 공격 범위

`validation/transport-ui-compatibility-936-readonly-20261112/기능보존-정적조사.ko.md`와 `static-evidence.json`은 소스 inventory로만 이용했다. 상대 리뷰 결과로 사용하지 않았다. 44개 live 차이 경로의 실제 Git blob을 e2a와 대조한 결과, same-live 21개 / functional-C11-merge 19개 / same-936 4개 / absent 0개다. `functional-C11-merge`는 바이트가 양쪽 원본과 다르다는 분류이며 전체 기능 동등성 PASS 표시가 아니다.

same-936 네 개는 두 기존 E2E 파일, `lib/dagster.ts`, `vendor/README.md`다. vendor는 C11을 유지하는 대상이다. 두 E2E의 차이는 과거 dev.9 로그인 slot/문구에 관한 것으로 현재 C11에 무조건 복사하면 안 된다. 복사하지 않았다는 이유만으로 추가 회귀 finding을 만들지 않았다. Dagster 표시명은 위 P3로 별도 특정했다.

| 기능/공격 | e2a 소스 관찰 | 남은 경계 |
| --- | --- | --- |
| `/parking-lots`, `/rail/timetable` | 실제 page/메뉴 및 현재 메뉴 구분 복원, route-content/navigation 계약 테스트 추가 | 링크만 있는 빈 화면으로 대체된 상태는 아님. 실제 렌더/브라우저 미실행 |
| 일반 주차장 | q/cursor 검색, query 키+AbortSignal로 늦은 응답 방어, id별 상세, 좌표 없는 항목의 목록, 정적 수용면/실시간 잔여면 구분, 0과 null 표시 대조 | 실제 API 응답/페이지 전환 미실행 |
| 일반철도 | 안내 provider ID를 TAGO 운행 station ID로 확정하지 않음, 출발/도착 검색의도와 후보 직접 선택, 날짜/등급/첫막/미래편, request key+abort, 카탈로그 부분 실패 취급 대조 | 네트워크 레이스 실행 미실행 |
| 도시철도 | 공식 code_id 역 선택, 저장표 status/stale/generated_at, day_code 7/8/9, arrival-only와 24시 초과 시간 표현, visible 시 재조회 및 abort 검사 | 실 API 시간표/시간 경계 브라우저 미실행 |
| Proxy/API499 | 양성 parking-lots/공식 역 경로와 음성 0/admin/delete 경로의 분기, 인증/no-store 경계, 반복 query 전달, guide만 60초 대조 | 직접 인증/API 요청/DB·수집 작업 없음. P2-01 테스트 계약 모순 별도 |
| 지도/유가/목록 | 5종 지역 유가와 미제공 구분, `features/places.fuel_regions`, 라벨/배치, 일반주차장 상세, 목록 truncation 표시/상한, 철도 운영기관·노선 label 대조 | 실제 타일/충돌/반응형/클러스터 클릭/포커스 미실행. P2-03 별도 |
| 콤보박스/폼 | single 선택, controlled 검색, 직접 선택 전 제출 억제, IME 키 처리, label/combobox/listbox 연결, 검색의도별 focus 요청 대조 | 스크린리더·모바일·터치 실기 미실행 |
| C11 소비 | 승인된 packages/lock/vendor 고정, 기존 공통 컴포넌트 경계 유지, backend/auth/schema/public frontend 바이트 보호 | 과거 Common7/Scope2 판정을 새 관리자 runtime 승인으로 사용하지 않음 |

지도 지역 카드의 수동 닫힘 이후 viewport 변경 시 다시 열릴 수 있는 경로도 살폈다. 해당 effect의 overflow-open 방식은 live6bd에도 동일하므로 **새 기능 보존 회귀로 확정하지 않고 finding에서 제외**했다. 테스트가 다루는 동일 effect 내 MutationObserver와 viewport effect 재실행을 혼동하지 않았다.

새 route-content 계약 테스트는 실제 page 모듈을 로드하되 지도를 mock한다. 그 테스트의 존재를 실제 VWorld 지도/타일/브라우저 검증으로 확대하지 않았다. general-rail-station-intent, 주차장, metro, truncation 테스트의 소스와 핵심 assertion도 검토했지만 직접 실행은 하지 않았다.

## 실행한 명령과 원시 근거

Windows cwd가 무효여서 모든 명령은 PowerShell `workdir C:\`에서 `wsl.exe --exec python3 -`로 실행했다. Python `subprocess`로 다음 읽기 전용 Git 명령을 호출했다. checkout/worktree/install/build는 만들지 않았다.

```text
git -C <repo> rev-parse <e2a>^{tree}
git -C <repo> rev-parse HEAD
git -C <repo> status --short
git -C <repo> ls-tree -r <base|e2a>
git -C <repo> diff --name-status <936> <e2a>
git -C <repo> diff <936> <e2a>
git -C <repo> diff <live6bd> <e2a> -- packages/kor-travel-transport-admin/frontend
git -C <repo> show <e2a|936|live6bd>:<path>
git -C <repo> grep -n -F fuel/regions <499> -- backend/app
git -C <repo> grep -n -F fuel_regions <499> -- backend/app
```

추가로 `hashlib.sha256`으로 manifest/부속 파일/변경49blob을 검산하고, `tarfile`을 메모리에서 읽어 정확한 e2a vendored Marker 구현을 검사했다. `CLAUDE.md`, `AGENTS.md`, `SKILL.md` 및 관련 적대적 리뷰 지침을 참고했다. source/lock/config 변경 0, 운영 접속/배포/apply/계정 조작/테스트 생성 0이다.

원시 근거 디렉터리: `/home/digitie/dev/common-unification-20261111/review-A-transport-admin-preservation-e2a925-evidence/`

- `observations-start.json`: 최초 고정 SHA/tree/작업트리 상태, 보호295개 대조.
- `base-head.patch`, `live-head.patch`: 정확한 Git diff.
- `live44-preservation-matrix.json`: live44개별 blob 분류.
- `changed49-verification.json`: 변경49개 실제 blob SHA/길이/mode/type 검산, errors0.
- `finding-source-evidence.json`: finding별 정확한 rev/path/줄 원문, vendored Marker hash/cleanup, API499 검색 결과.
- `observations-finish.json`: 최종 manifest SHA/tree, 움직인 작업트리의 관찰값, own tests/browser/remote-heavy 모두0.

## 미실행·사전 공개 검증 및 최종 경계

자기 실행은 Git/object/hash/정적 소스 검사뿐이다. unit/type/lint/Doctor/전체 build/browser/반응형/스크린리더/API499 실호출/remote CI는 **NOT_RUN 또는 NOT_QUERIED**다. 저장 공간 및 N150 heavy slot 제한을 지켰고 새로운 test job도 시작하지 않았다. 종료 관찰 가용 공간은 root224,821,248 bytes / tmp430,399,488 bytes였다.

manifest가 인계한 r1은 type/guard PASS, unit412PASS7FAIL+1unhandled, lint1/Doctor17이다. r2는 type/lint PASS, targeted38PASS/Doctor6이며 final full unit/type/lint/Doctor/build/browser/CI는 PENDING이다. 이것은 **부모/구현 담당자의 인계 기록**으로만 표기한다. remote 경로의 개별 로그와 e2a 실행 소스의 연결을 독립 재증명하지 않았으므로 exact e2a 테스트 PASS로 사용하지 않았다. Doctor6은 이미 공개된 gate이며 새로 발견한 6건이라고 세지 않는다.

**e2a의 자체 소스 finding 세 건은 OPEN이다.** 최종 X에서 각 원인 수정의 Git delta와 실제 회귀 증거를 원 리뷰어가 확인해야 한다. 이후 움직인 737/291 또는 dirty 수정에 대한 승인, 공용 backend0042와 후보0036의 동기화/마이그레이션 승인, 관리자 이미지 활성화, 실제 기능 수용, 최종 merge/배포 승인으로 이 원문을 사용할 수 없다. 기존 모든 보고서·manifest는 그대로 보존했다.
