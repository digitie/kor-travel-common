# Transport 관리자 기능 보존 INPUT2 — 독립 리뷰 A

- runid: `review-A-transport-admin-preservation-c3da263-20261112T005853Z`
- 원 리뷰어: A/Mill, frontend/accessibility/domain regressions. 구현 비참여, 읽기 전용, 상대 현재 B2 원문·판정 미열람.
- 시작 UTC: `2026-11-12T00:58:53.160572+00:00`
- 종료 관찰 UTC: `2026-11-12T01:03:30.734786+00:00`
- **판정: SOURCE CODE PASS. 원 A finding 3건은 이번 고정 소스 기준 FIXED, 신규 P0/P1/P2/P3 finding 0건.**
- **실행·머지·활성화 승인: 보류. 정확한 c3da 전체 gate, 실제 SDK 브라우저, CI 최종 결과 및 후속 머지/이미지/정상 인증 수용을 이 소스 판정으로 대체하지 않는다.**

## 입력 고정과 원문 보존

manifest: `/home/digitie/dev/common-unification-20261111/validation/review-transport-admin-preservation-c3da263-input2/manifest.json`

직접 검산 SHA256: `70ce298c0c57efbb3016665b3cf3ca13924354000115c51802cc34b07dca4473`. 시작과 종료 모두 같은 값이다.

| 항목 | 관찰값 |
| --- | --- |
| repo | `digitie/kor-travel-transport`, PR182 |
| base | `936fdb90b0ee9f6392d2f888255053ee1f4066b2` |
| 검토 HEAD | `c3da2632101c347a5e4fc288762de635c9c255b5` |
| 검토 tree | `077e7c14f87aa55fe1774c0a706bcf9f1e3e509c` |
| 원 리뷰 HEAD | `e2a925086925fd353bd3705f8ea3ae96ac3810a5` |
| 기존 운영 기능 소스 | `6bd594e606ef7d0326ec5742942e83997708946e` |
| 운영 API 계약 대조 소스 | `499822601abca3f050aa0cfe0e27fb446d22281d` |

제품 소스는 `git show`, `git diff`, `git ls-tree`로 해당 object만 읽었다. 작업트리는 시작·종료 모두 c3da HEAD/clean으로 관찰했지만, 이 상태를 Git object 대조 대신 사용하지 않았다.

원문1 `review-A-transport-admin-preservation-e2a925.md`의 SHA256은 여전히 `489b0cb8d344297867986a921e76160bde5f1b9a8a02619c5e3d41b7b57cc07b`다. 원문1의 BLOCK/OPEN/미실행 기록은 변경하지 않았다. 이번 FIXED는 새 입력의 별도 판정이다. 중간 291 자체의 최종 승인도 아니다.

직접 확인한 범위는 base→c3da 총 53개 변경, e2a→c3da 정확히 13개 경로다. packet의 세 부속 파일 길이/SHA256이 모두 일치했고, 변경 53개의 base/head mode/type/OID 및 실제 head blob의 길이/SHA256도 모두 일치했다. 각 행의 `changedAfterFirstReview`도 실제 e2a diff와 일치한다. 보호 경로 295개는 base와 mode/type/OID 전부 동일하다. unchanged tracked path는 852개다.

Input2 행 스키마는 `mode/kind/gitOid`다. 처음 자체 검산기가 input1의 `mode/type/gitBlob`과 dict를 비교해 낸 전 행 mismatch는 검산기 스키마 오류였고 제품 실패가 아니었다. 원 출력을 `git-packet-verification-initial-schema-mismatch.json`에 보존한 뒤 명칭을 맞춰 다시 검산했다. 최종 `git-packet-verification.json`의 changedErrors/protectedDifferences/changedAfterFirstErrors는 모두 빈 배열이다.

## 본인 원 finding의 직접 재확인

아래 상대 경로는 모두 `packages/kor-travel-transport-admin/frontend/` 아래다.

### A-TRANSPORT-P2-01 — FIXED (소스/테스트 계약)

- 원 심각도 P2 유지. 현재 위치: `lib/upstream.test.ts:19`–`:25`, `app/api/transport/[...path]/route.test.ts:71`–`:92`.
- `/transport/fuel/regions`를 성공 요구 목록에서 빼고, `transportUpstreamUrl`의 null 음성 case로 옮겼다. 인증된 GET에서도 404 및 upstream 호출 0회를 요구하는 회귀 검사를 추가했다.
- 실제 존재하는 공식 코드 역·역별 시간표·일반 주차장 경로의 성공/인증/반복 query 전달 assertion은 유지한다. `lib/transport.ts`의 허용목록, proxy 제품 경로, backend에 가짜 API를 추가하지 않았다.
- 지도에서 지역 유가를 가져오는 계약은 그대로 `transport/features/places` 응답의 `fuel_regions`다. 지도 helper 추출 뒤에도 `applyPayload`→`setFuelRegions(payload.fuel_regions ?? [])` 경로가 유지된다. 따라서 원 테스트와 제품 분기의 모순은 해소됐다.
- 근거 수준: 정확한 Git 제품/테스트 소스의 분기 직접 대조. 이번 리뷰에서 해당 unit/route test를 직접 실행하지 않았으며 전체 c3da unit PASS를 주장하지 않는다.

### A-TRANSPORT-P3-02 — FIXED (한국어 표시 계약)

- 원 심각도 P3 유지. 현재 위치: `lib/dagster.ts:13`; 회귀 검사 `components/dagster-shadcn.test.tsx:103`–`:109`.
- live의 `JOB_LABELS.general_rail_timetable_collection_job = "일반철도 예정 시간표"`를 정확히 복원했다. 공통 Dagster 컴포넌트에 넘기는 `JOB_LABELS[name] ?? name` 소비 경계는 그대로다.
- 실제 jobName과 pipelineName이 들어간 runs/schedules snapshot을 렌더해 한국어 이름 2회, raw job 식별자 노출 0회를 요구한다. job 실행·스케줄·권한·예산은 바꾸지 않았다.
- 제공된 교정 원시 JSON에서 before291은 이 표시 assertion이 실패하고 after b962 tree는 통과함을 직접 확인했다. 테스트 파일은 c3da Git blob과 SHA256까지 동일하다. 기존 의미를 약화한 변경은 없다.
- 근거 수준: source 직접 대조 + hash 검산한 제공 단위/SSR 로그. 해당 테스트를 본인이 새로 실행한 것은 아니다.

### A-TRANSPORT-P2-03 — FIXED (마커 React 정체성 원인)

- 원 심각도 P2 유지. 현재 위치: `components/transport-map.tsx:555`; 회귀 검사 `components/transport-map.test.tsx:313` 이후.
- key를 `JSON.stringify(item)`에서 `server-cluster:${item.longitude}:${item.latitude}`로 바꿨다. count/kind_counts/배열 순서는 key에 들어가지 않는다. React key에서는 `.toFixed(6)`도 사용하지 않는다.
- 같은 좌표에서 count 2→3 변경, 객체 필드 갱신, 다른 cluster와 배열 순서 교환을 해도 같은 항목 key가 유지된다. 126.9999999와 127.0000001처럼 6자리 반올림 값이 같아지는 서로 다른 좌표도 React key가 구분한다.
- 기존 `interactionId`의 6자리 표현은 유지하지만 React key로 쓰지 않는다. 두 정체성을 혼동하지 않았다. 일반 server cluster의 count 갱신을 overlap-close observer가 보완한다는 설명에도 의존하지 않는다.
- 정확한 고정 vendor의 `Marker.js`를 다시 읽었다. 생성/정리 effect의 deps는 `[map, hasChildren, color, draggable, anchor, container]`이고, ariaLabel/children count의 갱신은 생성 effect를 다시 실행시키지 않는다. 위치 갱신도 별도 setter다. 따라서 같은 key/좌표의 count 변경에서 원 finding의 `marker.remove()` 재생성 원인이 사라진다. vendor/lock은 base와 같다.
- 첫 회귀 검사는 count가 3으로 바뀐 것을 확인한 뒤 원 DOM과 동일함 및 `document.activeElement === original`을 요구한다. 근접 좌표/순서 교환 검사는 각 DOM 2개의 동일성, 전체 2개 유지, 기존 포커스를 각각 검사한다. count만 같거나 새 요소를 다시 focus한 뒤 통과시키는 테스트가 아니다.
- 근거 수준: source 원인 제거 직접 확인 + 아래의 교정 단위 증거. **정확한 c3da 실제 VWorld Marker 브라우저 실행/포커스 PASS는 이번 리뷰에서 확인하지 않았다.** 이것은 남은 실행 gate이며 이번 소스 FIXED와 별도다.

## 제공 전후 증거를 독립 대조한 결과

제공 manifest `validation/transport-admin-review-followup-before291-20261112/corrected-before-after-manifest.json`의 SHA256 `921f6e311bbe596a3e84dd7ef65287864ee59b453f8ffac9786ce3b441efc5e6`을 검산했다. 열거한 원시 JSON/log/snapshot/patch 10개의 hash가 모두 일치했다.

- 교정 before 제품 commit: `291389565ab923a6eea5c2ed87097a1071292e0e`, tree `3d9e45e0ca8a4a20c392a379b8840a9f0fc737e5`.
- 교정 after 제품 **tree**: `b96290aca3cfb8d92b1c0b22e8669dfb15864272`. 이를 c3da commit이나 exact c3da 실행이라고 부르지 않는다.
- 같은 교정 테스트 3개의 before/after 바이트 및 manifest hash가 같다. source-before-corrected의 present tracked 267개, source-after-corrected의 269개를 Git과 대조해 허용된 테스트 overlay 외 차이가 없었다. 이는 해당 snapshot 바이트 검사이며 별도 모듈 설치·실행 환경 전체의 증명은 아니다.
- 원시 `before-corrected-29-cases.json`: 25 PASS / 4 FAIL / pending0. 네 실패는 작업 label, 공식 안내/전화, 주소 지도 버튼, cluster DOM 동일성이다. `after-corrected-29-cases.json`: 29 PASS / 0 FAIL / pending0.
- cluster before 실패 위치는 `expect(cluster()).toBe(original)`이다. label 갱신 assertion은 이미 통과했고, 이후 focus assertion에는 도달하지 못했다. 따라서 before에서 실제 focus assertion까지 실패했다고 과장하지 않는다. after에는 DOM 및 focus assertion이 모두 통과한다.
- 옛 `vi.waitFor(label)`를 act 안에서 기다리던 harness의 after 실패는 React flush 전에 막혔던 것이다. 교정 patch는 act 안에서 기존 debounce가 끝나도록 450ms 대기한 뒤, label/DOM/focus assertion을 밖에서 그대로 수행한다. 테스트의 DOM/focus 기대값을 삭제·완화하지 않았다. 옛 harness 실패를 제품 causal proof로 사용하지 않는다.
- c3da의 general-rail-station-detail/dagster 테스트는 교정 snapshot과 전체 바이트가 같다. map 테스트는 교정 snapshot 전체를 유지한 prefix 뒤에 근접 좌표 재정렬 case를 추가했다. 그러므로 29P는 그 추가 case나 c3da full gate의 실행 결과가 아니다.
- 집중 로그의 모듈 설치 바이트는 이번 리뷰에서 새로 검산하거나 로드하지 않았다. 소스/회귀 assertion 확인과 제공 증거의 일관성 확인에 사용했고, 이를 C11 실제 SDK 또는 exact c3da 브라우저 통과로 전환하지 않았다.

## 추가 13경로의 적대적 delta 검토

| 변경 | 본인 확인 및 공격 관점 | 판정 경계 |
| --- | --- | --- |
| full precision cluster key | 집계/종류별 count 변경, 같은 객체의 재생성, 순서 교환, 반올림 충돌 좌표를 대조. key가 동적 count/index/6자리 반올림을 포함하지 않음 | 소스 원인 수정. 실제 브라우저 별도 |
| 지도 helper 추출 | `useFuelRegionCards`로 옮긴 position/observer/cleanup 본문은 원 e2a 본문과 바이트 동일. React useState setter의 안정성, 추가 effect deps의 안정된 ref/setter, grouping·5유종 기준, 넘침 목록 및 rAF/observer 해제 대조 | 기존 지역 카드 viewport 재열림 성질을 새 수정/해결로 주장하지 않음 |
| 지도 표현 분리 | summary/guidance/rail-only/truncation helper 및 REFERENCE_LIST_KINDS를 기존 조건과 대조. ferry_port/bus_terminal/public_parking_lot만 reference 목록으로 취급 | 조회/API/선택 수명 의미를 바꾼 새 결함 미확인 |
| 일반철도 상세 | 고정 Korail URL에 `encodeURIComponent(provider_id)`를 붙여 slash·공백·&·?·=가 query value 안에 남음. 새 창/rel, phone의 숫자·+ 정제, provider/phone null 분기, 좌표 없는 주소 버튼 disabled 확인 | 실제 외부 Korail 사이트 응답/전화 실행 미검증. 상대 finding의 독립 closure를 대신하지 않음 |
| 일반철도 주소 callback | map view 전환과 기존 choose(selected)의 focusRevision 경로를 사용. 지도/목록 detail ref 및 새 시간표 기능을 유지 | 실제 responsive/focus 수용 미실행 |
| MetroCollectionNotice | no_data/error/pending 문구와 분기만 별도 컴포넌트로 이동. stale/저장표/미제공 의미, API 및 요청 수명은 동일 | 시간표 실제 운영 조회 미실행 |
| unit 회귀 | 공식 안내/전화/주소/label/cluster 정체성의 양성 및 null/무좌표 음성 검사 검토. 기존 assertion 삭제나 skip 추가 없음 | 정확한 c3da unit 실행은 별도 |
| loopback browser guard | URL 파싱 후 hostname을 127.0.0.1/localhost/[::1]만 허용. fake cookie/API route 설치보다 먼저 호출. Playwright 기본 baseURL과 같은 환경변수/기본값을 사용. 외부 host·suffix·userinfo로 위장한 외부 hostname은 목록에 없음 | 소스 차단 분기 확인. 임의 외부 config/redirect/운영 인증의 안전성 전체를 검증했다는 뜻 아님 |
| 실제 Marker browser case 소스 | 375/1440 폭, map/좌표 표시/초기 label, 실제 marker element 저장과 focus, 공개 zoom 제어로 응답 갱신, 최종 label·DOM equality·focus 검사를 유지. 내부 `_maplibreMap` 사유 속성 의존 제거 | E2E_MAP_SDK=true로 실제 실행하고 skip0 확인해야 함. PNG 타일 fixture는 실제 VWorld 서비스 가용성 증거가 아님 |
| docs | 25P4F→29P를 b962 집중 증거로 한정하고 exact 후속 전체 CI/운영 수용과 구분. 최초 BLOCK/옛 harness 이력을 보존 | 문서 문구를 실행 승인으로 사용하지 않음 |

브라우저 파일의 `isolated-review-regression` 쿠키는 정상 운영 인증 증거가 아니다. 제품 session 검증/auth 경로를 변경하지 않았고, 격리 fixture 환경에 한한 테스트다. 기존 제품 세션 검증을 우회하도록 승인하거나 운영에 이 fixture를 실행하지 않았다. 실제 관리자 수용에는 승인된 정상 로그인 절차와 해당 이미지의 증거가 별도로 필요하다.

## 직접 CI 관찰과 실행 미완 경계

GitHub connector `fetch_commit_workflow_runs(repo_full_name="digitie/kor-travel-transport", commit_sha="c3da2632101c347a5e4fc288762de635c9c255b5")`를 직접 호출했다. 기록 시점 UTC `2026-11-12T01:03:30` 기준 다음 결과다.

| run | 직접 반환 상태 |
| --- | --- |
| 공통 프론트엔드 정책 `43130998009` | completed / success |
| CI `43130997296` | in_progress / conclusion null |

이 connector는 PR-triggered 첫 페이지 조회다. 각 job log/checkout synthetic tree의 head tree 동등성까지 확인하지 않았다. 정책 run의 성공을 full CI 또는 browser 성공으로 확대하지 않는다. 이후 CI 상태가 바뀌더라도 이 원문 시점의 관찰은 소급 변경하지 않는다.

이번 자기 실행은 Git/hash/소스·제공 증거 대조 및 CI 상태 조회뿐이다. 자체 unit/type/lint/Doctor/build/browser 실행 **0**, N150 heavy 작업 **0**, install/운영 접속/apply/코드 수정 **0**이다. 과거 b962의 전체 type/lint/unit/Doctor/guard 성공 인계도 c3da exact full gate 대신 쓰지 않았다. 남은 gate는 manifest와 같다.

1. exact c3da full type/lint/unit/Doctor/dependency guard.
2. native/Alpine build 및 기존+신규 browser, E2E_MAP_SDK=true, 실제 DOM/focus, 새 skip/flaky/error 없음.
3. exact CI 완료와 checkout/머지 tree 연결, 각 원 리뷰어의 자기 finding closure.
4. 승인된 merged source의 새 ARM image와 common 전체 바이트/provenance, 공식 admin-only 적용 및 실제 기능 보존/정상 인증 수용.

## 재현 명령 및 원시 근거

PowerShell의 `workdir C:\`에서 `wsl.exe --exec python3 -`로 읽기 전용 Git 명령을 호출했다. 무효 Windows cwd를 사용하지 않았다.

```text
git -C <repo> rev-parse <c3da>^{tree}
git -C <repo> rev-parse HEAD
git -C <repo> status --short
git -C <repo> ls-tree -r <936|c3da>
git -C <repo> diff --name-only <936|e2a> <c3da>
git -C <repo> diff --unified=4 <e2a> <c3da>
git -C <repo> diff <b962-tree> <c3da> -- <source/test paths>
git -C <repo> show <e2a|291|b962-tree|c3da>:<path>
```

부속 파일/원문/테스트 snapshot은 hashlib로 SHA256/길이를 검산했다. 보호 경로는 파일명이 아니라 mode/type/OID로 대조했고, vendored Marker는 정확한 Git tgz를 메모리에서 tarfile로 읽었다. 새 checkout·설치·재pack은 없다.

증거: `/home/digitie/dev/common-unification-20261111/review-A-transport-admin-preservation-c3da263-evidence/`

- `observations-start.json`, `observations-finish.json`: UTC/head/tree/status/원문1 hash, 자체 실행0.
- `e2a-c3da.patch`: 이번 13경로 전체 diff.
- `git-packet-verification.json`: 정확한 53행 및 295 보호 경로 최종 검산.
- `git-packet-verification-initial-schema-mismatch.json`: 자체 검산기 스키마 오류 보존; 제품 실패 아님.
- `closure-source-excerpts.json`: 세 원 finding과 추가 UI/browser 변경의 정확한 줄 원문.
- `focused-proof-independent-inspection.json`: 제공 원시 JSON의 실패 위치/통과 및 10개 hash/테스트 byte 대조.
- `focused-snapshot-git-bridge.json`: 전후 snapshot의 present tracked bytes와 exact Git/허용 overlay 대조.
- `additional-static-comparisons.json`: region effect 본문 동일성, 실제 cluster key, 유지된 DOM/focus assertion.
- `github-ci-observation.json`: exact-head 조회 run 상태와 조회 한계.

최종 상태는 **A 세 건 소스 FIXED / 새 finding 0 / SOURCE CODE PASS / 실행·최종 승인 보류**다. 원문1과 다른 기존 보고서·manifest는 변경하지 않았다. 다음 최종 X가 다른 소스를 포함하면 그 불변 delta와 남은 실제 실행 증거를 다시 대조해야 한다.
