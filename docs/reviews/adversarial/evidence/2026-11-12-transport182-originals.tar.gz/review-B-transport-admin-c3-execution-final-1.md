# Transport c3 실행 증거 최종 bounded 리뷰 — 원 B

- Run ID: Epicurus-B-transport-c3-execution-final-1-20261112T013147Z
- UTC: 2026-11-12T01:31Z 이후 관찰. Reviewer Epicurus / original B, 구현 비참여.
- **Verdict: PREMERGE SOURCE + QA GATE PASS / 새 finding 0건.**
- **실제 merge M·ARM·공식 apply·정상 운영 수용 gate는 OPEN.** 이 원문은 미래 production 승인이 아니다.

입력: `validation/review-transport-admin-c3-execution-final-1/manifest.json`
직접 고정한 SHA256: `32ad35db674592834cdd74be247b6ddf65f69c3df22ab398c81acc5cae92bd2d`

## 직접 확인한 연결

1. exact source c3da2632101c347a5e4fc288762de635c9c255b5와 CI synthetic checkout 072c51d1991eed79ed768d7c029ca7dabf45fad1의 실제 Git tree가 모두 **077e7c14f87aa55fe1774c0a706bcf9f1e3e509c**다. synthetic의 부모는 base936/c3이며 실제 최종 merge M은 아니다.
2. QA handoff SHA256 `5de3d250e99aad051e122056fbca98607adc6720bd24bdfefa9daaf23d65c0c7`와 지목한 **56개 파일 hash**를 직접 대조했다. QA source receipt의 **904개 파일 전체 집합/각 SHA256**을 moving worktree가 아닌 exact c3 Git blob과 대조했고 모두 일치했다. 로컬 gate input hash도 이 receipt와 일치한다.
3. 이전 INPUT2 manifest 및 본인 SOURCE PASS 원문 SHA256 `291f96c4bf06a1ce577819af0c924049deb57e61aeb0ef497adbfca097564c5f`를 확인했다. B-TR-P2-01/P3-02 FIXED는 유지한다. 이전 원문의 실행 pending 표기는 당시 관찰로 보존하며 수정하지 않는다.
4. GitHub API를 직접 조회해 [CI 43130997296](https://github.com/digitie/kor-travel-transport/actions/runs/43130997296)와 [정책 43130998009](https://github.com/digitie/kor-travel-transport/actions/runs/43130998009)의 completed/SUCCESS를 확인했다. public/admin/backend 및 정책 두 job은 SUCCESS다. CI raw checkout도 위 synthetic SHA와 일치한다.

## 실행 gate와 skip 보존

| 범위 | 확인된 결과 |
|---|---|
| CI public frontend job130894802913 | unit164 PASS, guard/Doctor/type/lint/build step SUCCESS; 직접 API/log 조회 |
| CI admin job130894803054 | unit432 PASS, guard/Doctor/type/lint/build SUCCESS; hash 고정 raw log와 API 대조 |
| CI backend job130894803137 | **1548 PASS / 2 SKIP / 6 warnings / 1788.26초**; hash 고정 raw summary와 API 대조 |
| CI live-e2e job130894804548 | **SKIPPED — PASS 아님** |
| exact c3 owner local gates | type/lint/unit432/Doctor/guard exit0; Doctor225파일 “No issues found” |
| native browser | 선택 기존18 + repo regression4 + private feature6 = **28 PASS** |
| Alpine browser | 같은 구성 **28 PASS** |

6개 실제 Playwright JSON의 각 case/result를 읽어 총 **56 PASS, skip/flaky/unexpected/report errors 모두0, 전 case 단일 시도 passed**임을 확인했다. 전체 앱의 모든 E2E를 실행했다고 확대하지 않는다. 본인 finding의 공식 encoded href/tel/address-map action은 native/Alpine 각각 375·1440 case에서 passed다. marker regression도 양쪽 375·1440에서 passed이며 E2E_MAP_SDK=true 배선을 확인했다.

CI backend의 2 SKIP과 live-e2e SKIPPED를 통과 건수에 넣지 않았다. 별도 56건의 exact-source QA가 존재한다는 사실도 skipped CI live-e2e 자체를 PASS로 바꾸지 않는다. 과거 r1 실패/Doctor6 및 INPUT2 시점 pending 원문은 그대로 남긴다. 이번에는 새 source audit 전범위나 제품 테스트를 재실행하지 않고 고정 raw 증거를 검토했다.

## 실제 package bytes / 이미지 / ENV의 범위

owner harness는 lock에서 도달하는 각 common package의 실제 설치 파일을 Git tgz member bytes와 대조한다. native **263파일**, Alpine **263파일**이 일치하고 Alpine raw의 “ALL_ACTUAL_BYTES_MATCH 263”도 확인했다. tgz/lock/C11 source 연결은 이전 불변 SOURCE PASS의 동일 입력이며 신규 repack은 없다.

Alpine QA image는 `sha256:61c8581a26f187680908c6939deaca2b93973895df67365835d755bf45324a79`다. hash 고정된 image/source audit와 실행 harness에서 image ID/OCI revision label/c3 연결, source **293파일 일치**, compiled routes **32개**, /parking-lots 및 /rail/timetable 포함을 확인했다. compiled route 수는 모든 route의 실제 수용 통과 건수가 아니다.

**이 이미지는 linux/x64의 Docker builder target**이다. ARM 검증이나 최종 production runner 검증으로 읽지 않는다. Dockerfile의 runner 단계에 있는 production ENV 및 TRANSPORT_ADMIN_RELEASE_SHA default를 이 builder 실행으로 검증한 것도 아니다. QA의 OCI c3 label이나 builder에 전달한 build argument가 향후 runner의 effective ENV 검증을 대신하지 않는다.

source audit에서 제외된 admin `.env.example` 1개는 exact committed .dockerignore의 `**/.env.*` 경계와 맞는다. 904개 Git source 증명에는 포함되지만 이미지 source293에는 포함되지 않는다. 실제 운영 env/env-file/비밀값의 동일성·보존을 증명하지 않는다.

QA는 loopback server, 격리 cookie/API fixture, 시험용 VWorld key 및 대체 PNG tile을 사용한다. 실제 MapLibre/VWorld SDK 렌더 경로의 회귀 증거이며 live provider 인증·실제 tile 가용성·backend499/DB0042의 실제 수용이나 정상 운영 로그인 증거가 아니다. receipt의 own heavy0/서버·컨테이너 cleanup은 owner 기록으로 확인했으며 이번 B가 운영 프로세스나 Docker를 조작하지 않았다.

## 증거와 남은 경계

독립 evidence: `review-B-transport-admin-c3-execution-final-1-evidence/`

- `manifest.json`: 입력 exact copy.
- `github-observation.json`: 직접 조회한 workflow/jobs 및 public log의 checkout/164 PASS 발췌.
- `verify.py`: 실제 수행한 Git/hash/report 검증 스크립트.
- `verification.json` SHA256: `994cccc91ea0c90cfd57c59bd3b5d530a835daaad9d3aa1b176c05f43d942959`.

명령은 PowerShell workdir C:\ → wsl.exe를 통해 Git ls-tree/rev-parse/cat-file --batch, Python SHA256/JSON 검증만 수행했다. CI는 GitHub fetch_commit_workflow_runs / fetch_workflow_run_jobs / fetch_workflow_job_logs로 읽었다. 상대 현재 A3 원문/결과는 열지 않았다. 소스·기존 raw·manifest·모듈을 바꾸지 않았고 install/test/build/브라우저 재실행 및 live mutation은 0이다.

**premerge source+QA gate PASS**로 인계한다. 다음은 별도 미완 gate다: 실제 merge M의 full-tree bridge → M 기반 ARM image의 source·실제 common263/OCI/default·effective ENV 검증 → Aquinas 공식 admin-only dryrun/confirm/current/postproof → Mendel 정상 인증·표·폰트·지도·기능의 실제 운영 수용. 본 리뷰만으로 admin936 apply 또는 이후 production 성공을 선언할 수 없다.
