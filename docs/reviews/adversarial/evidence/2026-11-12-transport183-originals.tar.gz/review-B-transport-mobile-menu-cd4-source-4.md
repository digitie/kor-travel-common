# Transport mobile menu cd4 INPUT4 — 원 B bounded source 리뷰

- Reviewer: Epicurus / original B, 구현 비참여. 현재 peer4 원문 접근 0.
- Run ID: Epicurus-B-transport-mobile-menu-cd4-source4-20261112T035448Z.
- UTC: 2026-11-12T03:54:48Z 이후 관찰.
- **SOURCE PASS / B-MENU-P2-01 FIXED 유지 / 새 finding 0건.**
- cd4 실행·CI·실제 browser·merge·배포 승인은 별도 미완이다.

입력: `validation/review-transport-mobile-menu-cd4-source-input4/manifest.json`
SHA256: `ee4fc31a4b59d124f12b6f06ffb20af5967c85c4b8805347adfc74045b11388d`

Repository: `/home/digitie/dev/common-unification-20261111/kor-travel-transport`

| 구분 | exact Git ref |
|---|---|
| 이전 | ee45a482eeabd33c448c8061d9a3ea3b400705b6 |
| head | cd4ff768894d29199674c9f540399f7aeaf65170 |
| tree | 510888aa00fa949531e392c68061ff9ee72a5b83 |

Git object로 **4개 경로 delta와 나머지903개 blob 동일성**, 보호298개 경로의 mode/OID 동일성을 확인했다. 총907 blobs이며 runtime JS·helper·unit·API/auth/backend·package/lock/vendor는 바뀌지 않았다. packet sidecar hash/길이와 두 patch의 실제 Git diff bytes도 일치한다. 기존 본인 source1/2/3 raw hash는 그대로다. 전체 소스·suite·artifact 재검증을 반복하지 않았다.

## 변경 의미와 회귀 경계

경로 prefix: `packages/kor-travel-transport-admin/frontend/`

- `app/globals.css:831`: max-width1023px의 일반 .admin-layout에도 grid-template-rows: auto minmax(0,1fr)를 적용한다. 첫 rail 행은 콘텐츠 높이로 두고 남는 공간은 main 행이 받게 하여, 기본 auto 행에 viewport 여분이 배분되던 일반 화면의 빈 공간을 줄이는 방향이다. 새 고정171px 높이를 넣는 수정은 아니다.
- 기존 모바일 지도·공항 조건부 선언을 같은 값의 일반 규칙으로 통합했다. 지도에만 적용하던 유한 block-size/main overflow 규칙과 공항 화면의 기존 조건은 유지된다.
- 새 선언은 max1023px 안에 있어 desktop min1024px의 rail/collapse sizing을 바꾸지 않는다. 확대 지도 selector(:650)는 더 높은 specificity로 단일 main 행을 유지하며 새 일반 규칙이 이를 덮지 않는다.
- 고정 height/max-height/overflow:hidden을 새로 강제하지 않았으므로, 긴 non-map 본문을 메뉴 높이에 맞춰 잘라내는 변경은 아니다. 실제 긴 본문·지도 작업면·공항 sizing 수용은 fresh browser에서 별도로 확인해야 한다.

`e2e/admin-mobile-navigation.spec.ts:106–111`은 기존 /parking·/rail/timetable case에서 fonts.ready 후 rail 높이를 읽고 **폭768을 유지한 채 높이900→1100**으로 바꿔 차이가 1px 미만인지 검사한다. 기존 nav 방향/19 links/popup 부재/문서 overflow assertion을 제거하지 않았고, 높이 변경 뒤 overflow도 다시 검사한다. 정확한 절대 높이를 하드코딩하지 않아 같은 폰트/폭에서 viewport 높이에 따른 불필요한 stretch를 잡는 assertion이다.

packet의 기존 ee45 + 단일 CSS override 진단에서 768px rail 높이 변화가 **기존100px / override0px**임을 직접 읽었다. 따라서 새 assertion은 전달된 실패 형태에 대응한다. 이 진단은 이전 빌드에서의 가설 검증이며 **cd4 새 빌드/실행 결과가 아니다**. freeze 시 1023 진단·최종 cleanup도 미완인 기록을 그대로 보존한다.

## 본인 closure·실행 한계

B-MENU-P2-01의 actual baseURL→검증된 origin/target→cookie/scoped API/절대 goto 연결은 byte 동일하므로 **FIXED를 유지**한다. 이전 direct pure27 controls는 같은 helper에 대한 bridge 증거로만 남기며 이번에 재실행하거나 cd4 새 run으로 표기하지 않았다.

문서2개는 ee45 unit451/native39 성공과 시각 여백 문제를 함께 기록하고, override 진단과 cd4 새 검증을 구분한다. 기존 source3 PASS/raw와 native39·451 결과는 소급 변경하지 않았다. 현재 exact cd4 QA/CI/browser 결과는 직접 관찰하지 않았고, source PASS를 실행 승인으로 확대하지 않는다.

새 install/test/build/server/browser/Docker/prod auth/Map 작업 및 추가 heavy는 모두0이다. Geo 키 승인·실제 새 key UI 적용과 정상 지도 수용도 별도 범위다.

## 증거·판정

PowerShell workdir C:\ → wsl.exe에서 Git ls-tree/show/diff/rev-parse 및 Python hash/JSON 대조만 수행했다.

새 evidence: `review-B-transport-mobile-menu-cd4-source-4-evidence/`

- static-audit.py SHA256: `8b7b87bce3f96673999da96332818b90d742427b8a1a50379a5b36851c927762`
- verification.json SHA256: `c45d5f86924b1a22893885b93999563f1e7aec60efd745c56ef8fa5fc6d9934c`
- manifest.json: 입력 exact copy.

**SOURCE PASS / 본인 finding FIXED 유지 / 새 finding 0건.** mergeAllowed=false를 유지한다. exact cd4 실행·CI·실제 geometry/브라우저 및 후속 merge/image/ENV/apply/정상 수용은 별도 gate다.
