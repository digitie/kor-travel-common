# Transport 모바일 메뉴 db58 — 원 리뷰어 A 후속 소스 검토

- runid: `review-A-transport-mobile-menu-db58-source-2-20261112T032313Z`
- 원 리뷰어 A/Mill. UI/UX·접근성·breakpoint/cache/keyboard 담당, 구현 비참여.
- 관찰 UTC: `2026-11-12T03:23:13`–`2026-11-12T03:27:24`.
- **SOURCE verdict: PASS. A-TR-MENU-P2-01 FIXED(소스 원인 및 자체 pure 검증). 신규 finding 0건(P0/P1/P2/P3 모두0).**
- **정확한 db58 실행·CI·머지·이미지·실제 UI/인증·배포 승인은 별도 미완 gate다.**

## 불변 입력과 보존

packet: `validation/review-transport-mobile-menu-db58-source-input2/manifest.json`.

직접 SHA256: `937c35fbdae1f9b219c1601fc1507efccad90caac9f2636bd6d114748a777939`.

| 역할 | 정확 값 |
| --- | --- |
| base actual M | `6b75c3b3d1e6dec8fc346a847428f15e4f3153b4` |
| 이전 source1 | `b043c0d8a57df5ea4ec7de780551dff7ea171dc0` |
| 이번 head | `db58b22cbd512ad8288fb48c15717e8ffb2d5160` |
| 이번 tree | `2b5d54ea5816868926b933bf27d29edc322dc2d3` |

시작·종료 작업트리는 db58/clean으로 관찰했으며 제품 읽기는 Git object만 사용했다. base 대비8경로, b043 이후7경로가 manifest와 같고 blob907/기존 불변 blob899개/보호298개를 직접 확인했다. packet의10개 첨부 파일 길이/SHA256도 전부 일치했다. 이전 B raw는 hash만 계산했으며 내용·판정을 읽지 않았다. 상대 현재2 원문은 접근하지 않았다.

source1 A 원문 `review-A-transport-mobile-menu-b043-source-1.md` SHA256은 `1fe986e6350ac9ac4bc3d8125c291f6840377bbd2300958d5ce7833820ccbb5f` 그대로다. 그 BLOCK/소스 기반 반례/당시 browser NOT_RUN을 수정하지 않았다. 이번 FIXED는 새 소스의 별도 판정이며 REJECTED나 이전 판정의 소급 변경이 아니다.

## A-TR-MENU-P2-01 — FIXED 근거

현재 파일은 `packages/kor-travel-transport-admin/frontend/components/admin-shell.tsx:47`–`:83`이다.

1. 원인의 `active.scrollIntoView(...)`와 window resize listener가 모두 제거됐다. 컨테이너의 rectangle/clientWidth/clientLeft/현재 scrollLeft로 목표 left를 계산하고 **컨테이너 자신의** `scrollTo({left, top:container.scrollTop, behavior})`만 호출한다. 문서/상위 스크롤 영역이나 입력 focus를 직접 변경하는 API가 없다.
2. ResizeObserver는 container.clientWidth를 기억해 폭이 동일하면 반환한다. 높이만 바뀔 때 불필요한 정렬 호출 자체를 생략한다. 폭 변경·모바일 진입 시에는 실제 새 폭을 기준으로 계산한다.
3. 폰트 초기 완료는 `document.fonts.ready`, 이후 완료는 `loadingdone`으로 반영한다. 늦은 glyph 폭 변경 뒤 재계산하며, ready 후에도 effect를 방치하던 b043 경로가 수정됐다.
4. pathname 변경/언마운트 cleanup에서 cancelled 플래그, observer.disconnect, loadingdone unsubscribe를 수행한다. 이미 예약된 ready/observer callback도 cancelled 검사로 막는다.
5. `e2e/admin-mobile-navigation.spec.ts:117`–`:134`가 fonts.ready 후 긴 문서·nav가 화면 위에 사라진 전제를 확인하고,375px에서 높이300→280만 변경한 전후 window.scrollY 및 input focus를 검사한다. 짧아서 스크롤할 수 없는 fixture를 성공으로 처리하지 않도록 maxScroll>200과 nav.bottom<0 조건이 있다. **이 새 E2E의 실제 db58 실행은 이번 리뷰에서 하지 않았다.**

원 심각도 P2는 유지한다. source1 반례를 실제 동작으로 인계한 hash 고정 진단도 직접 확인했다. 기존 b043의36행 UI에서 documentY441→106(-335), 입력 top119.5→454.5, focus 유지였다. DOM append0/실서비스 인증0/provider 요청0이라는 진단 범위를 보존한다. 본인이 그 브라우저를 새로 재실행했다고 주장하지 않는다.

폰트 진단은 glyph 변경 후 중앙 오차82px가 fonts.ready 뒤에도 남고 높이만 강제 변경하면 사라진다. 그 실제 rectangle에 새 계산식을 대입하면 left899가 나오며, 과거 강제 resize로 정상 정렬된 실제 scrollLeft899와 같다. 이는 계산식의 대조이며 db58 실제 browser PASS가 아니다. 이전760px 가정으로 생긴768px 하네스 실패와도 구분한다.

## 자체 작은 pure 검증

WSL Node `v22.22.2`의 core VM과 `node:module.stripTypeScriptTypes`만 사용했다. 정확한 db58 effect 본문과 helper를 Git에서 읽어 TypeScript 타입만 제거했으며 product 파일을 바꾸지 않았다. React/DOM/폰트 엔진/브라우저/네트워크/서버는 실행하지 않았다.

**33 PASS / 0 FAIL / exit0**:

- effect10개: border/clientWidth 좌표 계산·top 유지, 동일 폭/높이 변경 생략, 폭 변경·smooth, 늦은 ready의82px glyph 위치 변화, loadingdone의 라벨 폭 변화, observer/이벤트 cleanup, cleanup 뒤 ready 차단, desktop 무시 후 좁은 폭 진입, 폭0→측정 가능, FontFaceSet 없는 경우.
- helper23개: 원격/잘못된 caller9개, origin 이탈 path8개에서 cookie/route/goto 부작용0, 안전 origin5개 정규화·결박, API predicate의 다른 origin/port/sibling prefix 차단1개.127.1/정수형 IPv4는 WHATWG URL이127.0.0.1로 정규화하는 안전 경로로 확인했다.

probe의 outer scroll API와 window resize listener는 호출되면 throw하도록 두었고, 새 effect는 이를 사용하지 않았다. 이것을 실제 scrollY/폰트/React 실행 증거로 부르지 않는다. Node 타입 제거 API의 ExperimentalWarning은 로그에 보존했다. 제품 warning이나 테스트 실패로 바꾸어 세지 않았다.

## 신규 delta 공격·한계

| 공격 범위 | 소스/pure 관찰 |
| --- | --- |
| 높이만 변경·읽기 위치 | 컨테이너의 가로축만 이동, 현재 top 유지, 같은 clientWidth observer 호출 생략. source1의 상위 문서 이동 원인이 제거됨 |
| 늦은 font/폭/스크롤 영역 | ready/loadingdone 재계산, clientLeft 고려, 기존 scrollLeft 합산. 클리핑 경계의 left는 브라우저가 clamp하는 구조. 실제 폰트 layout/첫·끝 메뉴 clamp/터치 smooth는 정확 db58 browser 검증이 필요 |
| route/back/정리 | pathname effect가 새 active link를 query하고 이전 callback은 취소. same-path query만 바뀐 경우 active 메뉴는 같음. 실제 Next Link/history/back/스크롤 복원은 새로 실행하지 않음 |
| media 변경 | 1023/1024 CSS는 b043과 전체 blob 동일. clientWidth 변경에서만 observer 재정렬하며 desktop에서는 미디어 조건으로 반환. 실제 map/nonmap geometry와 회전/가상 키보드의 브라우저 동작은 미실행 |
| 저장/cache/logout | groups19경로가 b043과 동일. 인스턴스별 Zustand/저장 예외 처리, collapsed aria-label/title, 모바일 라벨, POST logout 및 login cache 재정리 경계에 추가 제품 변경 없음 |
| modal 제거 | b043의 strip 전략을 유지, drawer/dialog/body lock을 다시 도입하지 않음. 기존 source1의 CSS·키보드 정적 관찰을 유지하고 전범위 실제 QA 통과로 확대하지 않음 |
| fixture의 실제 caller | resolved Playwright baseURL을 명시적으로 넘김. HTTP(S) loopback/no userinfo 확인 후 target도 같은 origin/protocol/no userinfo인지 확인. 검증이 context/cookie/routes/goto보다 먼저임 |
| fixture 부작용/범위 | fake cookie는 검증한 origin에만, API route predicate는 같은 origin과 `/api/transport/`에만, goto는 검증한 절대 URL 사용. 외부 protocol/host/port/path escape pure 음성 대조. 운영 로그인/사이트를 테스트하지 않음 |
| 단위/E2E 의미 | 기존10개 메뉴 E2E의19링크·수평 geometry·중앙 오차<8·collapse/title/reload·모달 없음·login 분리 assertion은 유지. 새 높이 case를 더해 소스상11개 메뉴 사례. 기존435/모바일5P5F나 이전 전체76수치를 새11개 실행으로 전용할 수 없음 |
| 남은 assertion 경계 | 기존 last.focus()는 Tab/Shift+Tab 순서 자체가 아님. page.goto 기반 route 검사는 persistent client shell history를 독립 증명하지 않음. root 가로 overflow만으로 모든 map/nonmap 시각 geometry를 증명하지 않음 |

새 fixture 계약은 별도 상대 finding을 읽고 폐쇄 판정을 복사한 것이 아니라 새 파일을 직접 검사한 결과다. 본인은 A finding만 자기 closure로 닫는다. 상대의 own closure를 대행하지 않는다.

## 미완 gate와 원시 근거

이번 **SOURCE PASS**는 source+33개 pure probe의 판정이다. 정확 db58 full unit/type/lint/Doctor/guard/native/Alpine/browser/CI는 freeze 때 진행 중으로 인계됐으며, 이번에 자체 재실행/현재 CI 조회하지 않았다. 실제 runtime geometry·폰트/scrollY 회귀 통과나 배포 PASS를 주장하지 않는다. b043/prototype 성공 결과는 db58의 실행 근거로 사용하지 않았다.

실제 merge/새 merged-source ARM/common263 audit/공식 적용/정상 인증·지도 기능 수용은 별도 gate다. Geo 키의 사용자 승인 재사용·2PNG probe는 별도 운영 범위이며 새 키 실제 UI/배포가 완료됐다고 주장하지 않는다. Map ops0, 새 install/전체 build/server/실서비스 auth/Docker/추가 heavy0이다.

PowerShell workdir `C:\`에서 `wsl.exe --exec python3 -`, `git ls-tree -r`, `git show <sha>:<path>`, `git diff base|previous head`, hashlib/tgz 및 `wsl.exe --exec node`의 작은 pure script만 사용했다. source/index/branch를 변경하지 않았다.

자기 evidence: `review-A-transport-mobile-menu-db58-source-2-evidence/`.

- `git-packet-verification.json`: manifest/10파일/907blob/899불변/보호298 검산.
- `b043-db58.patch`:7경로 전체 delta.
- `effect-body.ts.txt`, `mobile-navigation-fixture.ts`: 고정 Git에서 추출한 검증 입력.
- `pure-probe.mjs`, `pure-probe-result.json`, `pure-probe-run.log`, `pure-probe-run.exit`: 자체33 pure 검증과 한계/경고.
- `b043-actual-geometry-closure-check.json`: 원 실제 반례/좌표 계산 대조.
- `closure-source-excerpts.json`, `observations-finish.json`: exact source 줄/불변 원문 및 관찰 metadata.

최종: **A-TR-MENU-P2-01 소스 FIXED / 신규0 / SOURCE PASS / exact 실행·CI·배포 승인 미완**. source1 BLOCK 원문은 그대로 보존한다.
