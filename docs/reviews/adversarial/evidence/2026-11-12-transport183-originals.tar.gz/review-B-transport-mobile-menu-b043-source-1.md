# Transport mobile menu b043 source INPUT1 — 독립 B 원문

- Reviewer: Epicurus / original B. 구현 비참여; 운영보존·packaging/provenance·API/auth·상태 격리·테스트 신뢰성 관점.
- Run ID: Epicurus-B-transport-mobile-menu-b043-source1-20261112T025515Z.
- UTC: 입력 직접 관찰 2026-11-12T02:55:15Z; 정적 hash 증거 생성 2026-11-12T02:58:40.650635Z.
- **SOURCE verdict: BLOCK / new findings 1 (P2).**
- 제품 테스트·build·설치·실서비스 인증·Docker·Map ops·추가 heavy 작업: **모두 0**.
- 상대 현재/기존 peer 리뷰 원문을 읽지 않았다. 구현/index/branch와 기존 raw/manifests를 변경하지 않았다.

## 불변 입력과 실제 Git byte 검증

입력: `validation/review-transport-mobile-menu-b043-source-input1/manifest.json`

직접 고정 SHA256:
`a754a6b88c234a9c928c8393fb1542dd6d1c2698250996a05214336839617079`

Repository: `/home/digitie/dev/common-unification-20261111/kor-travel-transport`

| 구분 | exact Git ref |
|---|---|
| 실제 M base | 6b75c3b3d1e6dec8fc346a847428f15e4f3153b4 |
| 이번 head | b043c0d8a57df5ea4ec7de780551dff7ea171dc0 |
| 이번 tree | fc4c8854fe0f6f046ea6e2997edea2aa5903ab17 |

Git object로 base904/head905 blob을 직접 세고, 변경 **6개**, 기존 동일 **899개**, 보호 **298개**의 실제 mode/blob을 확인했다. packet invariants, 7개 sidecar의 길이/SHA256 및 실제 Git diff와 diff.patch bytes가 일치한다. moving workingtree나 이후 QA 변경을 입력에 섞지 않았다.

변경은 docs 2개, admin CSS/셸 2개, 셸 unit/E2E 2개다. 보호 경로에는 workflow/backend/public frontend/package/lock/common-artifacts/vendor가 포함되며 모두 base와 같다.

## B-MENU-P2-01 — guard가 caller의 실제 baseURL을 검증하지 않아 loopback fixture 경계가 우회됨

**P2 / OPEN / 새 테스트 소스의 안전 경계·provenance 결함.**

파일 prefix: `packages/kor-travel-transport-admin/frontend/`

- `e2e/admin-mobile-navigation.spec.ts:13`: 검사할 origin을 process.env.E2E_BASE_URL 또는 고정 localhost 기본값에서 만든다.
- :14–20: 이 origin의 hostname만 검사한 후 cookie를 추가한다.
- :21–29: actual target origin에 묶이지 않은 API/타일 route mock을 설치한다.
- :30: page.goto(path)는 실제 Playwright caller config의 baseURL로 상대 URL을 해석한다. helper는 그 baseURL fixture나 test.info().project.use.baseURL을 읽지 않는다.
- 저장소 기본 `playwright.config.ts:8`은 환경변수와 같은 값을 사용하므로 기본 config 한 가지에서는 문제가 가려진다. 별도 QA config/프로젝트가 use.baseURL을 override하는 경우는 보장하지 않는다.

**실패 시나리오 / 정적 재현 조건:**

1. caller가 `use: { baseURL: "https://menu-guard.invalid" }`를 지정한다. E2E_BASE_URL은 unset 또는 `http://127.0.0.1:12305`로 둔다.
2. isolatedPage의 guard는 loopback으로 판단하여 통과한다.
3. cookie는 loopback origin에 추가되지만, API glob mock은 원격 target에도 적용될 수 있고 page.goto("/fuel")는 caller의 non-loopback origin을 향한다.
4. 따라서 “loopback 외에는 mock 설치/탐색 전에 거부”한다는 계약은 성립하지 않는다. authenticated storageState 등이 있는 caller에서는 원격 앱의 응답을 fixture로 대체한 결과를 격리 QA처럼 소비할 위험도 있다.

**근거 수준:** 실제 b043 helper와 호출·config의 불일치를 Git 소스에서 직접 확인했다. 실제 원격 서버/인증/브라우저에 접속하거나 이 공격을 실행하지 않았다. b043에서 실제 false PASS가 발생했다거나 원격 서버에 mock cookie를 보냈다는 주장이 아니다.

**영향:** product 인증 구현의 우회는 아니지만, 운영 대상에 fixture를 적용하지 않겠다는 테스트 경계와 exact QA provenance가 caller variation에서 깨진다. 기본 환경에서 76건이 통과하더라도 이 negative contract가 입증되는 것은 아니다.

**권고 / parent·QA scoped 요청:** 실제 resolved baseURL fixture를 helper에 전달해 그 protocol/hostname/origin을 검사하고 cookie/mock/navigation을 같은 검증 대상에 결속한다. E2E_BASE_URL이 실제 config와 다르다는 이유로 안전 판정을 해서는 안 된다. non-loopback caller + env unset, non-loopback caller + env loopback을 각각 **addCookies/route/goto 전** 거부하는 no-network negative control을 추가한다. loopback caller의 정상 경로와 localhost suffix 사칭도 함께 확인한다. reviewer의 실제 원격 호출이나 추가 heavy 실행은 필요 없다.

이 finding의 수정·exact input closure 전에는 SOURCE PASS로 닫지 않는다.

## B 범위의 나머지 정적 검토

### 패키지·라이브러리·운영 경계

public4/admin6, 실제 Git tgz 사본 **10개**의 SRI를 계산해 lock와 common-artifacts integrity/version을 대조했다. 해당 base/head blob이 같고 repack/버전·lock 변경은 없다. 기존 라이선스 고지와 vendor bytes도 그대로다.

실제 UI0.2.0 tar의 AppMenu JS/type hash가 packet의 공통 packed contract hash와 일치한다. Button은 `./primitives` export에서 실제 Button 모듈로 연결되고, 명시한 type="submit"과 aria/title props를 전달한다. 단순 이름만 비슷한 로컬 Button 대체나 라이브러리 미지원 prop 사용은 발견하지 못했다.

Zustand는 기존 dependencies/lock의 **5.1.0**을 실제 import하여 useStore로 subscribe하고 setState/getState를 사용한다. 새로운 React copy나 package 축 변경은 없다. AppMenu root와 primitives import는 동일 불변 UI package 안이다.

backend/API/auth/schema/workflow 변경은 없다. 세션/CSRF/origin/proxy/logout handler·layout의 base/head blob도 대조했다. Geo 키 재사용은 사용자 승인된 별도 운영 작업이며 이 diff에 실제 key/ENV 변경이나 배포 증거는 없다.

### 19개 경로·login/logout/cache

`components/admin-shell.tsx:21–30`의 groups 문자열 전체가 base와 정확히 같다. 고유 링크 19개가 유지되고 가장 긴 segment-boundary 일치로 activeHref 하나를 고르는 로직도 유지한다. `/rail/mapping/variant`는 mapping으로 가지만 비슷한 문자열 접두사를 자동 활성화하지 않는 기존 SSR 테스트는 unchanged다.

:86–87은 action=/api/auth/logout, method=post, Button type=submit이다. GET 링크로 바뀌지 않았고 onSubmit은 기존 cache clear를 호출하며 기본 제출을 막지 않는다. 서버 handler는 origin 확인 후 상대 /login 303과 session cookie 만료를 유지한다.

:58의 dashboard-v1/v2 sessionStorage 제거 및 :61의 /login 도착 후 재정리는 그대로다. :62의 login early return 전까지 hook 호출 순서도 일정하여 로그인 화면에 관리자 메뉴/로그아웃을 노출하는 변경은 없다. 이전 auth/cache 계약의 실제 서버 동작을 이번에 재실행한 것은 아니다.

### SSR/hydration·상태 격리·저장소 오류

:37의 createStore는 모듈 singleton이 아니라 각 AdminShell의 useState lazy initializer 안에서 생성된다. 초기 sidebarCollapsed=false는 server/client 첫 렌더에서 동일하고 localStorage 읽기는 :39–41 effect에서만 한다. render 중 window 접근이나 저장된 값에 따른 server/client 초기 markup 분기는 없다.

두 instance의 store/context는 독립이고, 동일 앱의 localStorage key만 의도적으로 공유한다. 한 instance의 toggle은 그 store만 갱신하며, 새 instance는 mount effect에서 공유 preference를 읽는다. 이미 살아 있는 다른 instance/tab에 storage event로 즉시 동기화하는 구현은 아니며, 이번 요구의 persistence와 별개다.

getItem/setItem 예외는 catch하고 메모리 상태 toggle은 계속 수행한다. storage 값은 정확한 "1"일 때만 복구하며 개인정보나 인증 토큰을 저장하지 않는다. login return 전에도 hook 수는 유지된다. MenuLink는 module scope의 안정된 component이고 nearest provider의 collapse 상태를 읽는다.

이 설명은 정적 코드 판단이다. 실제 hydrateRoot/StrictMode·동시 두 instance·저장소 거부 browser를 reviewer가 실행했다는 뜻은 아니다. exact QA에서 저장값=1 SSR hydration 경고, 두 instance 독립 toggle 및 재mount preference 복구를 따로 확인할 범위로 남긴다.

### strip/desktop·접근성·규약

packet의 RW-9/UX-G1.2는 strip 기본과 Geo drawer 옵션을 구분한다. 19개 항목을 이유로 drawer를 MUST로 강제하는 규약은 없으며 ≤10 상한은 후보다. 이 소스는 개별 popup을 제거하고 같은 공통 AppMenu를 유지한다.

CSS :821 이후 desktop collapse는 4rem rail과 icon labels/title을 제공한다. :830 이후 max1023px에서는 nav/ul row, 가로 overflow, 라벨 표시, collapse button 숨김으로 전환한다. JS active scroll media와 1023/1024 경계가 같다. collapsed 상태의 라벨 숨김 CSS는 min1024px 안에 있어 mobile로 넘어가면 원 라벨이 다시 나타난다.

:47–57의 active scroll은 navigationRef 범위에서 선택하고 reduced-motion에 auto, 그 외 smooth를 지정하며 resize listener를 해제한다. AppMenu packed markup의 aria-label과 아이콘 aria-hidden wrapper를 확인했으므로 desktop label 시각 숨김이 접근 가능한 이름까지 지우지는 않는다. modal/portal/focus-trap/body lock을 새로 소유하는 소스는 없다.

실제 320/375/414/768/1023/1024/1440 geometry, keyboard scroll·최초/마지막 항목, 확대 지도·공항 주차장의 CSS cascade와 focus 복귀는 actual browser gate다. 62rem 콘텐츠 규칙 잔존을 전체 셸 breakpoint가 이미 같았다는 역사 주장으로 바꾸지 않았다.

## 테스트 강도·provenance 공격과 미완 gate

새 unit 소스는 19 links, 실제 store toggle/persistence, active route, reduced-motion, 저장소 예외를 검사한다. 기존 popup의 Escape-close 검사를 없앤 것은 popup 자체 제거에 따른 계약 교체다. 새 strip에서는 Escape 후 nav가 남고 dialog가 없는지를 검사한다. 기존 POST/logout/login SSR assertion은 그대로다.

새 E2E 소스의 10개 case는 320/375/414/768/1023 strip, 1024 collapse 복구와 mobile 전환, 화면 전환, non-map 두 경로, login을 검사한다. scroll width·active center·focus·pageerror assertion이 있다. pageerror 수집만으로 React의 모든 console hydration warning까지 검사했다고 간주하지 않는다.

| 공격/범위 | 이번 B 판단 |
|---|---|
| 잘못된 nested active route / 19개 링크 소실 | groups/active source 유지; 실제 기존 테스트는 이번 미실행 |
| collapse 상태에서 접근 가능한 이름·submit type 소실 | packed AppMenu/Button 및 caller props 대조; 새 결함 미발견 |
| SSR에서 localStorage 접근 / module global store 공유 | effect-only read 및 instance store 확인; runtime 미실행 |
| storage get/set 예외 / malformed value | catch/정확한 "1" 처리 확인; runtime 미실행 |
| caller baseURL과 env 불일치 | **B-MENU-P2-01 OPEN** |
| 이전 drawer prototype 24 unit/10 browser를 이 head로 전용 | 불허; b043 통과 증거로 사용하지 않음 |
| exact b043 fullunit/type/lint/Doctor/guard/native/Alpine/76 browser/CI | owner 진행 중이라는 freeze 사실만 수신; 본인 실행·통과 관찰 없음 |
| base 실제 M의 지도 실패를 이번 UI 성공으로 대체 | 불허; packet의 actualQAOverall=FAIL 보존 |
| live auth/Geo key 적용/새 이미지 실제 map acceptance | NOT_RUN / 별도 운영 gate |

base M의 실제 run2 tile은 HTTP200이어도 XML 36건, PNG 아님, InvalidParameterValue/locator=key였다는 packet 기록을 읽었다. 이를 인증 오류의 세부 subtype까지 확정하거나 지도 정상으로 확대하지 않는다. key 재사용 승인과 실제 새 key browser/apply 수용은 분리한다. noFurtherCurrentMAuthOrBrowserLaunch 경계를 지켰다.

## Commands/evidence와 판정

모든 shell은 PowerShell workdir C:\ 에서 wsl.exe를 통해 수행했다. Git ls-tree -rz / rev-parse / show exact:PATH / diff BASE HEAD / grep와 Python SHA256·SRI·메모리 tar metadata 읽기만 사용했다. 제품 함수나 테스트를 실행하는 mirror harness는 만들지 않았다.

독립 evidence:
`/home/digitie/dev/common-unification-20261111/review-B-transport-mobile-menu-b043-source-1-evidence/`

| 파일 | SHA256 |
|---|---|
| manifest.json | a754a6b88c234a9c928c8393fb1542dd6d1c2698250996a05214336839617079 |
| static-audit.py (실제 수행 스크립트 보존) | f71aac8bf56ac1ab118db7067663215c91647babc6e6207c931e97d4d58dd8e2 |
| static-verification.json | a2d698a86a5c706f415732761d7af1c5454cbf8335954dd8206cf18d13afd213 |

static-verification에는 6개 source blob/SHA/길이, 298보호 대조, 19경로, SRI10, packed export hash, 불변 API/auth 경계와 정적 caller-variation 반례를 기록했다. 파일은 root의 새 보고서/evidence만 작성했다.

**SOURCE BLOCK — B-MENU-P2-01 OPEN, new findings 1.** 실제 메뉴/로그아웃/상태 격리 product 코드에는 이번 정적 검토에서 추가 finding을 발견하지 못했다. guard 수정의 새 exact input과 scoped negative control 후 본인 finding을 재검토해야 한다. 별도로 b043 또는 후속 exact head의 QA·CI·merge·image/default/effective ENV·공식 적용·정상 수용은 아직 승인하지 않는다. 과거 c3/원문 판정은 변경하지 않는다.
