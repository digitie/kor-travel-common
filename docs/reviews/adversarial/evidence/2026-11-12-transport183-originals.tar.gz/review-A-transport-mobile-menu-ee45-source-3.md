# Transport 모바일 메뉴 ee45 — 원 리뷰어 A bounded 소스 검토3

- runid: `review-A-transport-mobile-menu-ee45-source-3-20261112T033148Z`
- 원 리뷰어 A/Mill. 구현 비참여·읽기 전용. 상대 현재 리뷰2/3 원문·판정 미접근.
- 관찰 UTC: `2026-11-12T03:31:48`–`2026-11-12T03:33:13`.
- **SOURCE verdict: PASS / 신규 finding 0건(P0/P1/P2/P3 모두0).**
- **A-TR-MENU-P2-01: 소스 FIXED 유지. 정확한 ee45 실행·CI·배포 승인은 미제공/별도 gate.**

## 불변 입력·원문

packet `validation/review-transport-mobile-menu-ee45-source-input3/manifest.json`의 직접 SHA256은 `d41227e062aac2a3b91876097cd8fd76c0f871c1ff7725bf81bb1af593eae927`로 일치한다.

- base actual M: `6b75c3b3d1e6dec8fc346a847428f15e4f3153b4`.
- previous: `db58b22cbd512ad8288fb48c15717e8ffb2d5160`.
- exact head: `ee45a482eeabd33c448c8061d9a3ea3b400705b6`.
- exact tree: `be68e1a99ec364a4624ea4c4061922af64d891be`.

시작/종료 관찰은 ee45/clean이었고 소스는 Git object로만 읽었다. packet의11파일 길이/SHA256이 전부 맞았다. 이전 B source1 raw는 hash만 계산하고 텍스트를 읽지 않았다. 상대 현재 원문을 읽거나 그 closure를 대행하지 않았다.

source1 A 원문 SHA256 `1fe986e6350ac9ac4bc3d8125c291f6840377bbd2300958d5ce7833820ccbb5f`, source2 A 원문 SHA256 `82f53138d34bea8f75d2214c9755c5525901f2a6b1cfb8e763ed2fde79edcfbd`가 그대로다. source1 BLOCK과 source2 SOURCE PASS/실행 미승인을 수정하지 않았다.

## Disposable mock delta

previous→head의 변경은 정확히3경로다. `docs/journal.md`, `docs/resume.md`, `packages/kor-travel-transport-admin/frontend/lib/mobile-navigation-fixture.test.ts` 외 차이는 없다. 총907blob 중 previous 대비904blob이 동일하고, base 대비 불변899blob/보호298경로도 동일하다.

제품 의미가 있는 delta는 없다. test의 `fakePage():8`–`:14`에서 Page.route 모의 반환값만 바꾼다.

```ts
const dispose = vi.fn<() => Promise<void>>().mockResolvedValue(undefined);
const route = vi.fn<Page["route"]>().mockResolvedValue({
  dispose,
  [Symbol.asyncDispose]: dispose,
});
```

직접 읽은 로컬 선언은 **playwright-core1.65.0**이며 고정 package-lock의 @playwright/test/playwright-core1.65.0과 버전이 같다. 정확한 선언 경로·실제 resolve 경로·파일 SHA256은 자기 evidence에 기록했다. 해당 모듈을 실행하지 않았다.

- `playwright-core/types/types.d.ts:4504`–`:4509`: `Page.route(...): Promise<Disposable>`.
- `:21524`–`:21533`: `Disposable`의 `dispose(): Promise<void>`와 `[Symbol.asyncDispose](): Promise<void>` 두 메서드.

새 mock은 두 메서드를 모두 제공하고 각각 Promise<void>를 반환하는 같은 typed spy를 사용한다. return type을 any/void로 낮추거나 ts-ignore/설정/타입 검사를 억제하지 않았다. 기존 partial fakePage의 `as unknown as Page`는 변경하지 않았다. 다른 addCookies/goto의 기존 반환 계약도 건드리지 않았다.

구형 route 반환 한 줄과 새 Disposable block을 각각 같은 marker로 정규화하면 **나머지 테스트 파일 전체 바이트가 동일**하다. 부작용0·origin/path 거부·cookie/route/goto 결박 assertion과16개 case는 삭제·완화하지 않았다. 실제 helper는 route 반환 객체를 사용해 분기하지 않으므로 이 대역 변경이 주소 경계 검사의 의미를 바꾸지 않는다. 새 타입 계약에 구조적으로 맞는다는 소스 확인이며 **정확 ee45 tsc 성공을 본인이 실행했다는 뜻은 아니다.**

문서 두 경로는 db58의 unit451/Doctor0 등과 TS2345 실패 및 native/Alpine 미실행을 분리해 보존한다. 구형 실패를 성공으로 덮지 않았다. 새 소스 검증이 필요하다고 명시한 범위도 적절하다.

## 본인 finding closure·전체 소스 회귀 범위

**A-TR-MENU-P2-01은 ee45에서도 소스 FIXED**다. `components/admin-shell.tsx` 전체 blob이 source2와 같아서 다음 원인 제거가 그대로 남아 있다.

- 문서에 영향을 주는 scrollIntoView/window resize listener 제거.
- nav container의 horizontal scrollTo만 사용하고 top 유지.
- clientWidth가 변할 때만 ResizeObserver 재정렬.
- fonts.ready/loadingdone의 늦은 glyph 반영.
- pathname 재실행/언마운트 때 cancelled/disconnect/unsubscribe로 지연 callback 차단.

소스 회귀 연결을 파일명이나 commit 메시지로 추정하지 않았다. shell, CSS, shell-menu unit, mobile navigation E2E, 실제 fixture helper, package/lock/공통 원장 각각의 mode/type/OID 및 SHA256을 db58과 대조해 동일함을 확인했다. source2의 작은33 pure 검증 입력도 변경되지 않았다는 범위에서만 기존 근거를 유지한다. 이를 ee45 전체 실행33P나 native/browser PASS로 세지 않는다.

따라서 source2에서 직접 검토한1023/1024 cascade, map/nonmap 배치 조건, collapsed 이름/title 및 저장 차단,19개 경로와 POST logout/cache, 기본 strip/모달 제거, active route/폰트/폭/정리 수명, 실제 caller origin 경계에 새 delta가 없다. 새 근거 없는 finding을 만들거나 전체 브라우저 회귀 검증으로 확대하지 않았다. b043의441→106 실제 세로 이동/폰트82px 반례가 하네스 오판이었다고 소급 재분류하지도 않았다.

## 검증·한계

직접 수행: PowerShell workdir `C:\`→`wsl.exe --exec python3 -`, Git `rev-parse/status/ls-tree/show/diff`, packet/소스 SHA256, readonly Playwright 선언과 lock 버전 대조, test assertion 불변 비교. source/index/branch·설정·패키지 수정0, 새 install/fulltest/typecheck/build/browser/server/Docker/실서비스 auth/추가 heavy/Map ops0이다.

hash 고정 `db58-failure-checkpoint.json`의 실제 기록은 집중40/전체451P, type exit2 TS2345, native build/browser/Alpine NOT_RUN이다. 이것은 source2 실행 실패로 보존하며 본인 source2 원문을 다시 쓰지 않는다. 현재 ee45의 fresh QA·CI는 freeze 때 진행 중으로 인계됐고 결과가 정해졌다고 주장하지 않는다. 새 unit/type/lint/Doctor/guard/native/Alpine·폰트/height/포커스/메뉴 browser gate가 필요하다. 이전 b043/prototype 성공이나 db58 unit451을 이 head의 실행 PASS로 전용하지 않았다.

실제 merge·merged-source ARM image/263byte audit·공식 적용·정상 운영 UI/로그인/지도 수용은 별도 gate다. source PASS는 merge/실제 배포 승인 자체가 아니다. Geo 키 재사용 작업도 별도이며 새 키 실제 UI 수용을 수행하지 않았다.

자기 evidence: `review-A-transport-mobile-menu-ee45-source-3-evidence/`.

- `git-packet-verification.json`: manifest/11첨부/정확3delta/907blob/899불변/보호298 대조.
- `db58-ee45.patch`:3경로 전체 diff.
- `type-contract-and-source-identity.json`: 실제 PW1.65 선언/경로/hash, mock 외 테스트 전체 동일성, runtime/E2E 등 동일 blob/SHA.
- `observations-finish.json`: UTC/head/clean, 자기 새 실행0, 과거 원문 hash 불변.

최종 **SOURCE PASS / 본인 P2-01 소스 FIXED 유지 / 신규0 / exact 실행·CI·배포 gate 별도 미완**.
