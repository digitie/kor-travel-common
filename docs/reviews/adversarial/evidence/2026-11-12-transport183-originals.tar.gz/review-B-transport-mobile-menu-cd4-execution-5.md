# Transport mobile menu cd4 실행 INPUT5 — 원 B

- Run ID: Epicurus-B-transport-mobile-menu-cd4-execution5-20261112T043023Z.
- Reviewer: Epicurus / original B, 구현 비참여. UTC 2026-11-12T04:30:23Z 이후 검토.
- **FRONTEND EXEC PASS / CI PENDING / 새 finding 0건 / merge 미승인.**
- 본인 B-MENU-P2-01 FIXED 유지. 기존 source/실행 원문은 변경하지 않았고 peer5 원문은 읽지 않았다.

입력 manifest SHA256:
`15562d401152ab9be88629754c9df7b026c07581321eaa18f5a430bbd90f0195`

추가 supplement owner SHA256:
`c6e8fe89d0d0cfed164a6a2013c8b0a6105133f5e5b2e491a91e1544fef914c6`
parent receipt SHA256:
`3dcbe517663fb4f9b326dcc2cb147c88808e2b15a689aab86a5b65032be59580`

## 실행 연결과 실제 결과

source는 **cd4ff768894d29199674c9f540399f7aeaf65170**, tree는 **510888aa00fa949531e392c68061ff9ee72a5b83**다. CI synthetic **35045758e01f90509a8b8f4c7cd15f30eab95e76**도 실제 Git에서 같은 tree임을 확인했다. 실제 최종 merge M을 뜻하지 않는다.

packet42개 파일, supplement12개 참조와 중첩된 원 실패/복구·r2 raw hash, parent가 수집한24개 raw record를 직접 대조했다. source4 원문 SHA256 `0296a2382f1ccd8b334f7fef573e843e26162aa6f3d930f41e70fc6d2c43df34`도 동일하다. QA source907 최종 mismatch0은 hash로 묶인 owner/parent 확인 기록과 runner의 source 검사 경로를 대조한 것이며, 본인이 원격 clone 전체를 다시 읽은 것은 아니다.

| 확인 범위 | 결과 |
|---|---|
| native browser | 기존18 + review4 + feature6 + menu11 = **39 PASS** |
| Alpine browser | 같은 구성 **39 PASS** |
| 실제8개 Playwright JSON | **78개 모두 단일 시도 passed**, skip/flake/unexpected/report errors0 |
| common 실제 파일 | native263 / Alpine263, tgz member와 설치 bytes 대조 경로 및 raw 확인 |
| native compiled manifest | 실제32개, /parking-lots·/rail/timetable 포함 |
| 추가 image 감사 | COPY296 일치/mismatch0, compiled32, linux/x64 **builder** 범위 |

본인 guard의 negative controls는 실제 full recovery/CI log에서 lib/mobile-navigation-fixture.test.ts **16 tests PASS**로 확인했다. 기존 direct pure27 증거와 source FIXED bridge도 그대로다. browser caller는 실제 baseURL→검증 origin을 사용하는 immutable helper를 소비한다. 실제 browser가 임의 원격 caller를 공격했다는 의미는 아니다.

fresh native PNG375/768을 본인이 직접 열었다. 메뉴·로고·로그아웃 배치가 보이고, hash 고정 측정값은 rail **171px**, 로고/로그아웃 중심 차이0, 활성 항목 중심 오차 **0/−0.5px**다. 768의 높이900→1100에서도 rail171px로 일정하다. CDP font 기록은 Pretendard custom glyph6을 각 폭에서 확인했다. CSS injection0인 새 native paint이며 이전 빌드의 override171 결과를 전용한 것이 아니다. 본문/API의 실제 운영 정상 데이터 수용이나 전체 glyph 검증으로 확대하지 않는다.

## r1 실패와 r2의 gate 의미

r1은 **61 files/434 PASS + fork worker 시작 오류1**로 실패했고 map-overlays17개는 실행되지 않았다. assertion 실패로 관찰된 것은 아니지만 원 unit exit1과 raw SHA256 `ee58d1a0a537c17ef4e73d228dde1f8470351bf0b68f8c43900a2a569aaad48f`를 그대로 보존한다. resource 원인은 **확정되지 않았다**.

동일 source/config/pool/timeout/assertion으로 target17을 1회 통과한 뒤, 전체62 files/451을 1회 통과한 복구 log와 exit0을 확인했다. 기존 --passWithNoTests 유무와 무관하게 실제17/451 건수도 확인하여 empty run을 성공으로 읽지 않았다.

original/r2 driver diff를 직접 읽었다. r2는 출력만 별도 디렉터리에 두고, 원 six PASS gate와 원 unit exit1을 읽은 후 **명시적 target17＋full451 복구 성공을 새 선행조건으로 요구**한다. 원 gate를 전부 성공으로 다시 쓰거나 실패를 조용히 무시하는 방식이 아니다. 실제 source/tag/build args/payload 및 기존18＋4＋6＋11 case·assertion·skip·timeout·pool은 유지되며, 추가된 것은 별도 fresh paint 수집이다. 따라서 복구된 effective unit gate는 인정하되 “최초 r1 전체 PASS”로 기록하지 않는다.

## CI 단일 직접 조회와 승인 경계

2026-11-12T04:34:12Z에 기록한 단일 GitHub readonly checkpoint:

| exact cd4 CI | 직접 관찰 |
|---|---|
| main run43151188851 | **IN_PROGRESS** |
| public130960449425 / admin130960449790 | SUCCESS, raw164/451 PASS·Doctor0 및 type/lint/build step 성공 |
| policy43151189609 / 두 policy jobs | SUCCESS |
| backend130960449807 | **IN_PROGRESS / conclusion null — PASS 아님** |
| live-e2e130960450824 | **SKIPPED — PASS 아님** |

이후 재poll하지 않았다. frontend 실행 PASS와 전체 CI 완료를 분리한다. parent가 merge 직전에 **same cd4 head + effective QA + 모든 필수 CI SUCCESS**를 확인해야 하며 이 원문은 merge 승인이 아니다.

## 범위와 후속 운영 입력

QA는 loopback/mock session·API·시험용 VWorld key/대체 tile을 사용했다. x64 Alpine builder COPY296/실제 package263 감사는 production runner의 원본 파일 존재·default/effective ENV·ARM이나 실제 provider/key 인증을 증명하지 않는다. compiled32도32 route 전부의 정상 운영 수용을 뜻하지 않는다.

owner 기록의 PID/port/fixture 종료와 ownHeavy0을 확인했다. 본인은 install/build/test/browser/server/Docker/prod auth/Map 작업을 실행하지 않았다. 모든 기존 raw와 QA 실패 이력은 보존했다.

**freeze 이후 별도 운영 입력 알림을 구분한다.** parent가 사용자 승인된 Transport .env.prod의 NEXT_PUBLIC_VWORLD_API_KEY 한 값 갱신을 Aquinas에게 별도 인계했다는 사실을 수신했다. QA mutations0은 해당 QA 기간과 본 리뷰 활동에만 한정되며, 현재 전체 production ENV가 무변경이라는 주장이 아니다. 이 operator 입력 receipt는 여기서 감사하지 않았다. 실제 새 키 browser acceptance는 여전히 FALSE/미완이고 새 M build·apply 역시 완료로 주장하지 않는다.

## Evidence와 인계

새 evidence: `review-B-transport-mobile-menu-cd4-execution-5-evidence/`

- verification.json SHA256: `34e2672d36e575bd2be913fb3449f65321291c46d4840e91da2e779d00a85686`
- github-observation.json: 단일 직접 조회의 workflow/jobs 및 기록 UTC.
- verify.py, 입력/supplement exact copy, operator-scope-note.json 보존.
- operator-scope-note.json SHA256: `35fb42553056d20505fbe81419d427804f679dca9e35d320dec07672da98ee0b`

PowerShell workdir C:\ → wsl.exe의 hash/JSON/Git tree 대조, 로컬 PNG 열람 및 GitHub 읽기만 수행했다. 전체 source audit나 테스트를 재실행하지 않았다.

**FRONTEND EXEC PASS / CI PENDING / 본인 finding FIXED / 새 finding 0건.** 전체 CI 완료 후 최종 merge M의 tree bridge → ARM/common263/OCI·ENV 감사 → 공식 admin-only apply → 실제 새 키·정상 인증·표/폰트/지도/기능 수용은 별도 후속 gate다.
