# A 추가 정적 관찰 — ee45 모바일 strip 여백
UTC 2026-11-12T03:47:01Z. 원 리뷰어 A/Mill; source/PNG만 읽음, 구현·heavy·browser·build·install0.
Source ee45a482eeabd33c448c8061d9a3ea3b400705b6 / tree be68e1a99ec364a4624ea4c4061922af64d891be.
원 SOURCE3 보고서 SHA256 81a796a3e7097bab98df5294c864a08e2901b6a97d4f5966e6a10e1703140b2a 그대로 보존. 기존 판정 소급 변경 없음.
입력 PNG 원위치: C:\Users\digit\AppData\Local\Temp\transport-ee45-native-mobile-strip-{width}.png.
768×900 PNG SHA256 7512231e9e6b2371e277cf637a7fff17f5ba53c5c1adf28e43f7a293be4d5f01 (60,776bytes).
375×900 PNG SHA256 8033753030d01e23138b728303644cec22a2c821aa04f9745754f3aa9861fe6f (55,224bytes).
관찰: 같은 /rail/timetable의 레일 경계가 이미지상 약 y282/y194로 달라지고,768에서 로고와 로그아웃 높이 어긋남이 특히 큼. DOM rectangle 실측 아님.
영향: 정상 strip보다 헤더가 불필요하게 많은 세로 공간을 차지하고 본문 시작을 밀어냄. native39P 인계만으로 이 시각 문제를 해소할 수 없음.
관련 파일은 packages/kor-travel-transport-admin/frontend/app/globals.css. :366은 grid에 min-height:100dvh를 유지함.
:831–:840은 모바일1열/rail height:auto/align-self:auto 및 내부2행 grid를 설정하지만 일반 화면의 바깥 행 크기는 지정하지 않음.
:841–:842의 grid-template-rows:auto minmax(0,1fr)는 map-workbench/parking 화면에만 적용되어 /rail/timetable은 제외됨.
가장 유력한 원인: 일반 화면의 implicit auto/auto 두 행이 남는 최소 뷰포트 높이를 나눠 받아 첫 rail 행까지 늘어나는 grid stretch.
:368의 rail-shell height:100%가 늘어난 rail을 채우고, 내부 auto 행에도 여유가 배분되어 여백을 키우는 방향으로 작용함.
:369의 header 고정40px와 :840의 footer align-self:center가 늘어난 첫 내부 행에서 서로 다른 Y에 놓이는 설명과 PNG가 일치함.
인과 확정은 Mendel의 실제 geometry/CSS 한 override 전후값으로 해야 함. 본인은 해당 재현을 실행하지 않음.
최소 검증 범위: 마지막 max-width:1023px의 .admin-layout에 grid-template-rows:auto minmax(0,1fr)를 일반 화면까지 적용하는 한 override부터 비교.
rail-shell height:auto만 바꾸면 바깥 첫 행의 공간은 남을 수 있음. 전역 min-height 제거/고정 헤더 높이/desktop·지도 높이 재설계는 우선 불필요.
Mendel 확인:375/768 및1023/1024에서 header/footer/nav/main rect, 긴 문서·지도·공항·확장 지도, 기존 수평 중앙/높이 변경 회귀를 대조. 별도 새 불변 source delta 필요.
증거: review-A-transport-mobile-menu-ee45-layout-observation-1-evidence/에 PNG 원본 바이트 복사·hash·CSS/page Git 원문 보존. 새 실행·운영 승인 아님.
