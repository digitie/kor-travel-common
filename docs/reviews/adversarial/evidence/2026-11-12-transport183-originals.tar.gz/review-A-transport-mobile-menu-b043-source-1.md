# Transport 모바일 메뉴 b043 — 독립 소스 리뷰 A

- runid: `review-A-transport-mobile-menu-b043-source-1-20261112T025511Z`
- 원 리뷰어 A/Mill. UI/UX·접근성·breakpoint·cache·keyboard 담당. 구현 비참여, source/index/branch 변경0, 기존/현재 상대 리뷰 원문 미열람.
- 관찰 UTC: `2026-11-12T02:55:11`–`2026-11-12T03:00:07`.
- **SOURCE verdict: BLOCK. 신규 finding 1건: P0 0 / P1 0 / P2 1 / P3 0.**
- 판정은 아래의 소스 경로에 근거한다. 실제 b043 높이 변경 반례의 브라우저 수치 측정은 요청했으며 본인은 실행하지 않았다. 진행 중인 QA/CI/운영 승인을 대신하지 않는다.

## 입력·검산

불변 packet: `validation/review-transport-mobile-menu-b043-source-input1/manifest.json`.

직접 SHA256: `a754a6b88c234a9c928c8393fb1542dd6d1c2698250996a05214336839617079`.

- base actual M: `6b75c3b3d1e6dec8fc346a847428f15e4f3153b4`.
- exact head: `b043c0d8a57df5ea4ec7de780551dff7ea171dc0`.
- exact tree: `fc4c8854fe0f6f046ea6e2997edea2aa5903ab17`.
- 시작/종료 작업트리 관찰: 같은 b043, clean. 제품은 작업 파일 대신 Git object로 읽었다.

변경6경로가 manifest와 정확히 같다. head blob905/base blob904, 영향 없는 기존 blob899개 및 gitlink1개가 동일하다. 보호298개도 mode/OID 모두 base와 동일하다. packet의 정본·비교·invariants·이전 handoff·diff 등 7개 파일 길이/SHA256 전부 일치한다. backend/auth/schema/package/lock/vendor/workflow 변경은 없다.

참고 비교의 Geo/Weather/Concierge/Manager/Pinvi/Map 확정 Git 소스 12파일·23개 excerpt를 직접 다시 읽어 file SHA 및 줄 원문이 비교 packet과 같음을 확인했다. 현재 Transport의 고정 UI0.2.0 tgz와 packed AppMenu JS/타입의 hash도 packet의 정본 값과 같다. 이는 참고 snapshot의 소스 확인이지 여섯 앱의 새 browser/runtime 재승인이 아니다. Map 설치·빌드·운영 작업0이다.

## A-TR-MENU-P2-01 — 활성 메뉴 중앙 정렬이 문서의 세로 스크롤까지 변경

- severity/disposition: **P2 / OPEN**.
- 제품 위치: `packages/kor-travel-transport-admin/frontend/components/admin-shell.tsx:52`; resize 연결 `:55`, 전체 effect `:47`–`:57`.
- 코드 경로: 1023px 이하에서 모든 window `resize`마다 활성 링크에 `scrollIntoView({block:"nearest",inline:"center",behavior})`를 호출한다. 너비가 그대로이고 높이만 바뀌어도 실행한다. `scrollIntoView`는 해당 가로 strip만 대상으로 하는 API가 아니며 상위 스크롤 컨테이너와 문서 뷰포트도 이동시킨다. `block:"nearest"`도 화면 밖의 대상을 드러내기 위한 세로 스크롤을 허용한다.
- 성립 조건: 비지도 긴 폼/결과 화면에서 상단 nav가 위로 사라질 만큼 사용자가 문서를 스크롤한 상태. 이 상태에서 resize가 발생하면 현재 width가 여전히 좁으므로 effect가 활성 링크를 드러내기 위해 문서를 메뉴 방향으로 되돌린다. 본문 입력 포커스 자체를 `.focus()`로 변경하는 버그라고 주장하는 것은 아니다. 입력 포커스가 남아 있어도 읽던/입력하던 영역이 뷰포트 밖으로 밀릴 수 있다.
- 기준: RW-9·UX-G1.2의 목적은 **nav strip 안의 수평 활성 항목 노출**이다. 사용자가 보던 문서를 메뉴 쪽으로 이동시키는 동작까지 요구하지 않는다. 모바일 창 높이/방향 변경 및 resize를 발생시키는 키보드 환경에서 반복될 수 있다. 모든 모바일 키보드가 window resize를 발생시킨다고 일반화하지 않는다.
- 기존 소스와의 차이: base의 popup 상태 관리에는 이러한 resize listener/자동 스크롤이 없다. 이번 새 effect에서 도입된 경로다. 이전 768px/760px 테스트 가정 실패를 근거로 재분류한 것이 아니다.

**정확한 b043 QA에 요청한 실패 시나리오(본인 실행 NOT_RUN):**

1. 격리 b043의 `/rail/timetable`에서 긴 폼/결과가 생긴 상태, width375/height400, reduced-motion reduce를 사용한다. 문서가 충분히 길다는 전제를 먼저 확인한다.
2. nav가 뷰포트 위로 사라지도록 스크롤하고 `window.scrollY`, 폼 컨트롤의 rectangle/activeElement를 기록한다.
3. width375는 유지하고 height만400→380으로 바꿔 resize effect를 실행한 뒤 값을 다시 기록한다.
4. 요구 결과는 문서의 읽기 위치 보존과 필요한 **수평 nav 이동만**이다. 현재 소스는 nav를 다시 노출시키는 세로 이동 경로를 갖는다. 짧아서 문서가 스크롤되지 않는 fixture로 검사하면 이 반례의 전제를 충족하지 못한다.

권고: `.rail-nav`의 수평 스크롤 범위 안에서만 active centering을 수행하도록 한정한다. 문서 전체에 작용하는 `scrollIntoView`를 매 resize마다 호출하지 않는다. 높이만 바뀔 때의 불필요한 재정렬을 피하고, 길어진 비지도 화면의 resize 전후 `window.scrollY` 및 입력 컨트롤 위치가 유지되는 회귀 검사를 추가한다. reduced-motion/활성 경로/수평 center 계약도 함께 유지해야 한다.

현재 E2E의 root `scrollWidth`와 row/column 검사만으로 이 세로 위치 회귀를 검출할 수 없다. QA 원본 source/head와 실제 전후값으로 본인 closure를 다시 확인해야 한다. source 근거에 대한 finding이며 실제 b043 브라우저에서 측정한 실패 수치를 꾸며 쓰지 않았다.

## 나머지 소스·계약 공격 결과

| 범위/공격 | 확인한 내용·한계 |
| --- | --- |
| 정본 권위 | RW-9/UX-G1.2의 기본은 strip, Geo drawer는 허용 옵션. packed AppMenu는 nav/link/action 계약이며 drawer/open/overlay 엔진이 아니다. 다섯 참고 앱의 strip과 Geo 옵션을 동일 구현이라고 서술하지 않음 |
| 1023/1024 cascade | 새 unlayered max1023 규칙이 legacy의 rail 높이/position/columns를 덮고, nav/ul row와 overflow를 설정. min1024에서만 접힘 label 숨김/4rem 적용. map/parking의 legacy62rem 선택자도 대조했으며 남는 gap/padding 차이를 새로운 760px 셸 전환으로 오인하지 않음. 실제 rectangle·시각 diff는 NOT_RUN |
| map/nonmap·확장 지도 | 유한 높이를 주는 `:has(.map-workbench)`와 일반 문서 흐름, data-parking-page, 확장 지도에서 rail을 숨기는 별도 규칙을 구분. 새 CSS만으로 모든 map/nonmap 실제 geometry 통과를 선언하지 않음 |
| 19개 링크·그룹 | base와 `groups` 선언 전체 바이트 동일. `/parking-lots`, `/rail/timetable` 포함19경로 유지. longest-prefix active 판정과 aria-current 하나의 경계 유지 |
| collapsed labels/title | 실제 packed AppMenu는 아이콘 span에 aria-hidden=true, 링크 자체에 aria-label을 제공. 새 CSS는 표시 텍스트 span만 숨기며 MenuLink는 title/나머지 anchor props를 보존. 모바일에는 해당 숨김 CSS가 적용되지 않아 저장된 collapsed=true여도 라벨을 표시 |
| Zustand/localStorage | store는 인스턴스별 useState 생성, SSR/첫 client는 false, mount 뒤 저장값1만 복구. getItem/setItem 각각 try/catch이며 저장 차단이 in-memory toggle을 막지 않음. mount 지연에 따른 접힘 적용은 관찰 대상이나 hydration mismatch 원인으로 확정하지 않음 |
| keyboard/skip link | 항목은 실제 Next anchor, 아이콘만 남아도 이름 유지. 가짜 role=menu/roving-tabindex/trap을 새로 만들지 않음. popup과 닫기/Escape 상태 제거는 strip 전환에 맞음. skip link/main tabIndex=-1 유지. 실제 Tab/Shift+Tab/Enter·screen reader 미실행 |
| logout/cache | `action="/api/auth/logout" method="post" onSubmit={clearDashboardCache}` 및 cache clear 함수가 base와 동일. pending 응답 대비 `/login`에서 v1/v2 cache 재정리 effect도 유지. Button의 명시적 type=submit과 aria-label 제공. 실제 auth/logout 요청0 |
| active centering | pathname effect는 모바일에서만 실행하고 reduced-motion을 매 호출 시 읽어 auto/smooth를 구분. 중앙 정렬을 위해 focus를 직접 변경하지 않음. 다만 위 P2의 세로 scroll 범위 문제는 남음 |
| 기존 표준 격차 | expanded rail의 기존 폭·본문 typography/다른 legacy 콘텐츠 breakpoint 전체를 이번6파일 변경만으로 정본 완전 정합이라고 승인하지 않음. 이번 새 P2와 기존 범위를 혼동하지 않음 |

## 테스트 소스 검토와 미실행 경계

새 unit은 19개 링크/팝업 제거, 접힘·저장·title, 복구, longest-prefix, reduced-motion, 저장소 차단을 검사한다. 기존 popup의 Escape 닫기 테스트 제거는 기능 전략이 strip으로 바뀐 데 맞춘 것이며 그것만으로 테스트 약화 finding을 만들지 않았다.

E2E에는320/375/414/768/1023의 strip,1024 collapse/reload/mobile복귀, 여러 폭 전환, parking/timetable, login 분리를 추가했다. loopback guard 뒤에서만 mock cookie/API를 사용한다. 다음 한계는 실행 결과가 아닌 **assertion 범위**다.

- nav row/ul row와 수평 overflow는 확인하지만 header-strip-main의 전체 실제 배치가 올바른지 전부 단언하지 않는다.
- `.focus()`로 마지막 링크를 보이게 하는 검사는 순차 Tab/Shift+Tab 경로 자체를 증명하지 않는다.
- active route를 `page.goto`로 바꾸므로 지속된 client shell에서 Link/back/history 경로를 독립적으로 검사하지 않는다.
- 수평 root overflow만 검사하며, 긴 비지도 화면 높이 변경의 `window.scrollY` 불변 조건은 없다(P2의 검출 공백).
- reduced-motion은 unit의 호출 인자 및 E2E 설정으로 다루며 실제 smooth 경로/폰트 로드 후 geometry/모바일 가상 키보드는 별도 검증이 필요하다.

이 점들을 별도 신규 P3로 중복 집계하지 않았다. source finding을 보완할 targeted QA 요청은 자기 evidence의 `scoped-height-resize-qa-request.json`에 남겼고 부모에게 전달했다. 추가 heavy0/새 install0/전체 test·build·Doctor·browser0/Docker0/실서비스 auth0/Map ops0이다. owner의 exact b043 full QA와 CI는 freeze 시 미완으로 인계되었으며 이번에 직접 실행/현재 CI 조회하지 않았다. drawer prototype의24unit/10browser PASS나 과거768px 하네스 오판을 b043 성공·실패 근거로 쓰지 않았다. 기존 지도 운영 key/타일 문제와 새 키 정상 수용도 이 소스 리뷰 범위 밖이다.

## 실행 명령·원시 증거

Windows 무효 cwd 대신 PowerShell workdir `C:\`에서 `wsl.exe --exec python3 -`를 사용했다. Git object만 대상으로 `git rev-parse`, `git status --short`(관찰), `git ls-tree -r`, `git show <sha>:<path>`, `git diff base head`를 실행했다. SHA256·길이 검산은 hashlib, packed AppMenu 읽기는 메모리 tarfile을 사용했다. branch/index/제품 파일을 수정하지 않았다.

자기 evidence: `review-A-transport-mobile-menu-b043-source-1-evidence/`.

- `git-packet-verification.json`: manifest/7파일/905blob/보호298 검산. unaffected900은899blob+gitlink1이라는 구분 포함.
- `base-b043.patch`: 6개 경로 전체 Git diff.
- `reference-git-excerpts-verification.json`: 참고6repo의 실제 Git 파일/excerpt 대조.
- `common-menu-contract-verification.json`: 실제 vendored UI/AppMenu JS/타입 hash.
- `source-contract-and-findings.json`: 19경로, groups/cache 함수/POST 동등성과 finding 위치.
- `scoped-height-resize-qa-request.json`: P2의 좁힌 QA 요청과 미실행 표시.
- `observations-finish.json`: 정확 head/tree/clean·불변 manifest 및 이전 A 보고서 hash 보존.

최종: **b043 SOURCE BLOCK / A-TR-MENU-P2-01 OPEN 1건 / 현재 실행·CI·배포 승인 미제공**. 이후 소스 수정 또는 동일 head의 scoped 반례 증거가 오면 본인이 새 불변 입력에서 따로 재확인한다. 기존 c3 원문들과 그 PASS/BLOCK 판정은 그대로다.
