# Transport mobile menu ee45 INPUT3 — 원 B 후속 소스 리뷰

- Reviewer: Epicurus / original B. 구현 비참여, peer 원문 접근 0.
- Run ID: Epicurus-B-transport-mobile-menu-ee45-source3-20261112T033151Z.
- UTC: 입력 직접 관찰 2026-11-12T03:31:51Z 이후.
- **SOURCE PASS / B-MENU-P2-01 FIXED 유지 / 새 finding 0건.**
- ee45 typecheck·full QA·CI·browser·merge·운영 승인은 별도 gate다. freeze 시 미정이며 본인도 재실행하지 않았다.

## 불변 입력과 delta

입력: `validation/review-transport-mobile-menu-ee45-source-input3/manifest.json`

직접 고정 SHA256:
`d41227e062aac2a3b91876097cd8fd76c0f871c1ff7725bf81bb1af593eae927`

| 구분 | exact Git ref |
|---|---|
| 실제 M base | 6b75c3b3d1e6dec8fc346a847428f15e4f3153b4 |
| 이전 source2 | db58b22cbd512ad8288fb48c15717e8ffb2d5160 |
| source3 | ee45a482eeabd33c448c8061d9a3ea3b400705b6 |
| source3 tree | be68e1a99ec364a4624ea4c4061922af64d891be |

Repository: `/home/digitie/dev/common-unification-20261111/kor-travel-transport`

Git object로 **907 blobs / base 변경8 / 기존 동일899**를 직접 확인했다. db58 이후 delta는 docs/journal.md, docs/resume.md, admin frontend의 lib/mobile-navigation-fixture.test.ts **3개 경로뿐**이다. 나머지 **904개 blob과 보호298개 경로**는 db58과 mode/OID가 같으며 runtime과 E2E assertion 변경은 없다. packet의 두 patch도 실제 Git diff bytes와 일치한다.

peer A raw를 제외한 참조 sidecar의 hash/길이를 검증했다. 본인 기존 원문은 다음 hash로 보존했다.

- source1 BLOCK: `0449986801c914722cfaf2022afbc678d858d433aadb39a80f3cb30a98e4144e`
- source2 SOURCE PASS: `adede37a904d766839de3425a9ab7647acd97ea7320836a4ea75e1ec67b2b49f`

## Disposable mock 수정 검토

대상 prefix: `packages/kor-travel-transport-admin/frontend/`

`lib/mobile-navigation-fixture.test.ts:9–13`은 Page.route의 mockResolvedValue(undefined)를 다음으로 바꾼다.

~~~ts
const dispose = vi.fn<() => Promise<void>>().mockResolvedValue(undefined);
const route = vi.fn<Page["route"]>().mockResolvedValue({
  dispose,
  [Symbol.asyncDispose]: dispose,
});
~~~

lock의 Playwright/core는 **1.65.0**이다. 기존 readonly 설치의 같은 version 선언에서 Page.route가 Promise<Disposable>을 반환하고, Disposable이 dispose(): Promise<void>와 [Symbol.asyncDispose](): Promise<void>를 요구함을 직접 대조했다. 새 mock은 두 member를 모두 제공한다.

참조한 타입 파일 SHA256은 `345bf3cb397fafe89a44a170c0eac639ed620a2e3fde3f09fbad8c6dd29022ce`이며 resolved cache path/version은 evidence에 기록했다. 이 읽기는 타입 계약 참조일 뿐, 해당 cache를 이번 소스나 runtime QA의 baseline으로 사용한 것이 아니다.

이전 stub을 새 stub으로 정확히 치환하면 test 파일 전체가 ee45와 같다는 것도 검증했다. negative/positive assertion, fake context/goto, actual helper import는 그대로다. assertion 완화·skip 추가·타입 cast로 반환 계약을 숨기는 수정은 없다.

**db58의 이 typed mock 불일치는 앞선 정적 리뷰에서 놓쳤다.** 본인의 pure helper 27 PASS는 URL guard 실행 증거였으며, Vitest typed mock을 포함한 project typecheck 성공 증거가 아니었다. 원문2는 소급 변경하지 않는다. 이번에는 실제 타입 선언을 대조해 수정의 소스 정합성을 확인했지만, ee45 typecheck PASS를 실행 관찰했다고 주장하지 않는다.

## 본인 finding closure와 소스 회귀

**B-MENU-P2-01 FIXED를 유지한다.** actual helper, 모든 caller/E2E 및 admin shell은 db58과 Git blob이 같다.

- 실제 baseURL fixture에서 HTTP(S), exact loopback, userinfo 부재를 확인한다.
- target의 HTTP(S), 동일 origin, userinfo 부재 검증이 cookie/route/goto보다 앞선다.
- cookie, API matcher, 절대 goto는 검증된 origin에 결속된다.
- actual helper SHA256 `00a2b610fb1ae1fa3924ddc7e68a60bed30a8accedc7cb356b7912895258443d`는 이전 direct probe의 exact 복사본과 같다.

db58에서 본인이 직접 실행한 no-network27 controls(제공16＋추가11)의 source bridge가 성립한다. 해당 결과 SHA256은 `44502e9185e7b784f36bc9ae9430c1c6c07ffabf436342b12601a625809847f6`이다. **이번에는 재실행하지 않았으므로 ee45의 새 test run으로 표기하지 않는다.**

19개 routes, POST logout, login early return, dashboard cache 삭제, 인스턴스별 Zustand/공유 preference·예외 처리·SSR 초기 상태는 source2와 같다. 수평 container scroll, width-only ResizeObserver, font ready/loadingdone 및 cleanup도 동일하다. 새로운 state/listener/SSR 경로는 늘어나지 않았다.

current packed AppMenu/Button, C11 vendor/lock/versions, backend/auth/API/schema/workflows는 보호 대상 또는 동일904개 blob으로 유지된다. source2의 tgz10 실제 SRI 검증 이후 artifact 변경은 없으며 이번에 repack/install을 하지 않았다.

새 disposal mock은 테스트 내부 resource다. 실제 browser route나 운영 auth/logout 구현을 바꾸지 않으며, fake resource 제공이 production resource lifetime 검증을 대신하지 않는다. **추가 finding은 0건**이고 상대 reviewer의 closure를 대신 판정하지 않았다.

## 실패 이력과 실행 경계

hash로 고정된 db58-failure-checkpoint.json을 확인했다. db58은 focused40·unit451(62 files)·lint·Doctor0·guard 성공 후 TS2345/type exit2로 중단됐으며 native build/browser/Alpine은 NOT_RUN이다. journal/resume는 이 실패를 보존하고 ee45의 새 실행과 구분한다.

| 항목 | 본인 관찰 범위 |
|---|---|
| ee45 manifest/Git/diff/실제 타입 계약 | 직접 확인 |
| 본인 원 P2 | FIXED 유지 |
| ee45 typecheck/full unit/Doctor/guard/build/browser | NOT_RUN, fresh QA 결과 미관찰 |
| ee45 exact CI | 직접 미조회, 성공 가정 없음 |
| db58 unit451/type FAIL, b043/prototype 결과 | 이력으로만 보존, ee45 통과로 전용 금지 |
| 새 install/server/browser/network/Docker/prod auth/Map 작업 | 0 |
| 실제 merge/image/ARM/ENV/apply/정상 수용 | 별도 미완 gate |

긴 화면 height-only/font/active-center, SSR hydration·상태 격리의 실제 browser/full regression은 owner exact-head QA 범위다. typed stub의 작은 수정이라는 이유로 실행 gate를 생략하거나 성공 처리하지 않는다. Geo 키 사용 승인과 실제 UI key 적용·지도 정상 수용 역시 별도이며, 본 diff에 key/ENV bytes 변경은 없다.

## 명령과 evidence

PowerShell workdir C:\에서 wsl.exe를 통해 Git ls-tree -rz/show/diff/rev-parse, Python hash·구조 대조와 기존 타입 선언 읽기만 수행했다.

새 evidence: `review-B-transport-mobile-menu-ee45-source-3-evidence/`

| 파일 | SHA256 |
|---|---|
| manifest.json | d41227e062aac2a3b91876097cd8fd76c0f871c1ff7725bf81bb1af593eae927 |
| static-audit.py | 4f2d64efe30089f620459ef3b1115a0bc0bba8d5932ada10a7db5c19f98ee730 |
| verification.json | c3721b6956324c265b974e9a3623f440118c22ffeede17df6ce10b5674584867 |

기존 raw/manifest, source/index/branch 및 공유 module/cache는 변경하지 않았다.

**SOURCE PASS / B-MENU-P2-01 FIXED / 새 finding 0건.** mergeAllowedAtFreeze=false는 유지한다. ee45 fresh QA·CI와 후속 실행 provenance를 별도 확인해야 하며, 이 원문은 실행·merge·배포 승인이 아니다.
