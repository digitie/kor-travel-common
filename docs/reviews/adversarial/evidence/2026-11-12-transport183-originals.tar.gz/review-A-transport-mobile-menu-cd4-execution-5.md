# Transport cd4 — 원 리뷰어 A bounded frontend execution5
runid review-A-transport-mobile-menu-cd4-execution-5-20261112T043022Z; 원 A/Mill, 구현 비참여·읽기 전용·peer5 미열람.
감사 UTC 2026-11-12T04:30:22Z → 2026-11-12T04:34:26.333208+00:00. 새 테스트/build/browser/install/Docker/운영 auth/Map ops/추가 heavy0.
입력 validation/review-transport-mobile-menu-cd4-execution-input5/manifest.json SHA256 15562d401152ab9be88629754c9df7b026c07581321eaa18f5a430bbd90f0195 일치.
추가 owner-final-manifest SHA c6e8fe89d0d0cfed164a6a2013c8b0a6105133f5e5b2e491a91e1544fef914c6 / parent-supplement-receipt SHA3dcbe517663fb4f9b326dcc2cb147c88808e2b15a689aab86a5b65032be59580 일치.
**FRONTEND EXEC PASS / 신규 finding0 / 전체 CI PENDING / merge 승인0.**
정확 source cd4ff768894d29199674c9f540399f7aeaf65170/tree510888aa00fa949531e392c68061ff9ee72a5b83. Git의 synthetic35045758e01f90509a8b8f4c7cd15f30eab95e76 전체 tree도 동일함을 직접 확인.
원 source4 보고서 SHA efe24af9dd7979f35d52e1949b7f9c2446643d1c57db5cbbdab80e8672e9c14b 및 앞선 원문들은 불변 보존. source4 이후 제품 delta 없음.
packet42파일 및 supplement12참조 길이/hash 직접 대조 불일치0. 추가 raw hash 목록15+15개도 일치. 부모/owner summary만으로 판정하지 않음.
원시 Playwright8보고서의 개별78사례를 파싱: native18+4+6+11=39, Alpine39. 모두 expected/passed, result1회/retry0, skip/flaky/unexpected/errors0.
**A-TR-MENU-P2-01: 소스 FIXED와 격리 실제 browser closure 확인.** 두 환경 모두 긴 화면 높이 변경의 window.scrollY/입력 focus 유지 case가 실제 passed.
폰트 뒤 중앙 정렬·폭 전환·collapsed 복구/title·19링크·map/nonmap·login 분리 case도 포함. 실제 SDK Marker count 변경의 DOM/focus 회귀도 두 환경에서 통과.
새 여백 실제 closure: native fresh-paint PNG375/768를 직접 열람했고 로고/로그아웃 정렬과 레일 축소를 확인. 기록상 CSSOverrides0, rail171/171, 중심오차0/0.
768의 height900→1100에서 rail171불변·main729→929. active nav 중심오차375=0px/768=-0.5px. CDP/glyph 기록은 Pretendard Variable custom6glyphs씩.
이는 과거 ee45에 넣었던 CSS override 수치가 아니라 새 native paint 기록이다. Alpine의 새 높이 불변 E2E 두 case도 passed이며 native PNG를 Alpine 시각 측정으로 전용하지 않음.
**r1 unit 실패 보존:** 원 로그는61파일434P+fork worker 기동 timeout error1, map-overlays17개 미실행/exit1. 434P만 보고 gate 성공이라고 하지 않음.
이후 같은 설정/명령의 target1파일17P/exit0, 이어 full62파일451P/exit0 기록을 확인. 로그 이름의 once와 상태/결과에 단일 bounded 복구로 명시됨.
Git과 package/lock/vitest config/map-overlays test SHA를 직접 대조해 같고, 명령·pool/timeout/assert/skip을 바꾼 흔적 없음. 자원 원인은 **확정하지 않음**.
R2 driver diff는 별도 출력 경로, 원 stage/config 사용, 명시 복구 prerequisite, 추가 freshpaint뿐. 원 unit exit1을 요구하고 여섯 원 PASS gate+target17/full451 성공을 따로 읽음.
원 r1 실패를 덮거나 전체 gate의 실패를 무시하는 일반 skip으로 바꾸지 않음. 브라우저 case수18/4/6/11 및 retry/skip/timeout/assert 조건은 유지. R2 gate는 명시적 복구 승인 의미임.
출처 범위: local Git blob907와 exact tree 확인. owner/parent의 최종907개 stage 대조0mismatch 영수증 및 runner의 source hash 검사 경로를 확인했으며 원격 stage907개를 본인이 재접속·재해시한 것은 아님.
actual common263개씩: native 파일별 tar/SRI/lock 대조 방식·결과와 Alpine ALL_ACTUAL_BYTES_MATCH263 기록 확인. 새 pack/설치 없음.
native 실제 app-paths manifest를 직접 파싱해32route와 parking-lots/rail-timetable 존재 확인. 추가 Alpine COPY296 audit도 source 일치/route32·mismatch0/exit0 기록.
COPY audit는 x64/Linux Alpine **builder QA 이미지** sha256:e01bac54f5bcbc447114ca173cfb8ecb9a8e236972e3ca5645b1c55db7302e6b에 한정. 미래 ARM/prod runner의 원본 소스 존재 증거가 아님.
loopback actual caller/origin에 cookie·API 모의를 결박하는 고정 helper/단위 계약을 유지. PNG fixture/모의 인증의 UI 검증이므로 실제 Geo 키·provider·정상 운영 인증 수용이 아님.
정리 receipt는 기록된 PID/port/fixture 종료, audit container 제거·heavy0을 확인함. 본인이 새 실호스트 process/Docker 검사를 한 것은 아님.
리뷰 끝의 직접 CI 1회 조회 UTC 2026-11-12T04:33:16.462919+00:00: frontend130960449425/admin130960449790 SUCCESS, 정책43151189609의 두 guard SUCCESS.
주 CI43151188851는 in_progress, backend130960449807 in_progress/conclusion null. live-e2e130960450824는 **skipped이며 PASS 아님**. packet public164/admin451·Doctor0/type/lint/build 성공 기록과 job 성공 상태도 일치.
따라서 프런트 실행 조건은 통과했지만 전체 CI/최종 premerge gate를 통과했다고 하지 않음. parent가 변경 없는 동일 head+모든 CI SUCCESS를 확인하기 전 merge 승인0.
실제 mergeM/tree bridge→새 ARM image/common263/provenance→공식 admin-only apply→정상 운영 UI/auth/지도·Geo 새 키 수용은 별도 미완 gate.
도구: Windows cwd C:\에서 WSL Python/Git/hash/JSON/PNG 읽기 및 GitHub readonly 조회. 전체 소스 재감사·33pure 재검증·재테스트 중복 없음.
자기 evidence review-A-transport-mobile-menu-cd4-execution-5-evidence/: independent-evidence-audit.json,runner-r1-r2.diff,github-end-observation.json,observations-finish.json.
최종: source4 유지+격리 frontend EXEC PASS/본인 P2-01 실제 browser closure/레이아웃 실제171불변 확인/신규0. CIpending·merge0·미래 운영 승인과 구분.
