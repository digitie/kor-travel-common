# Transport mobile menu db58 INPUT2 — 원 B 독립 후속 리뷰

- Reviewer: Epicurus / original B. 구현 비참여, peer 현재/기존 리뷰 원문 접근 0.
- Run ID: Epicurus-B-transport-mobile-menu-db58-source2-20261112T032315Z.
- UTC: 입력 관찰 2026-11-12T03:23:15Z 이후.
- **SOURCE PASS / B-MENU-P2-01 FIXED / new findings 0.**
- 본인 직접 실행은 작은 **pure helper 27 PASS**뿐이다. db58 full QA·CI·browser·merge·배포 승인은 별도 pending이며 이 원문으로 통과 처리하지 않는다.

## 입력·Git bytes

입력: `validation/review-transport-mobile-menu-db58-source-input2/manifest.json`

관찰/고정 SHA256:
`937c35fbdae1f9b219c1601fc1507efccad90caac9f2636bd6d114748a777939`

Repo: `/home/digitie/dev/common-unification-20261111/kor-travel-transport`

| 구분 | exact Git ref |
|---|---|
| base 실제 M | 6b75c3b3d1e6dec8fc346a847428f15e4f3153b4 |
| 이전 source1 | b043c0d8a57df5ea4ec7de780551dff7ea171dc0 |
| INPUT2 head | db58b22cbd512ad8288fb48c15717e8ffb2d5160 |
| INPUT2 tree | 2b5d54ea5816868926b933bf27d29edc322dc2d3 |

Git object 기준 **907 blobs / base 변경8 / b043 이후 delta7 / 동일899 / 보호298**을 직접 대조했다. 두 patch는 실제 Git diff bytes와 같고, 접근한 sidecar의 SHA256/길이가 맞는다. packet의 peer A raw 파일은 읽거나 hash 검증하지 않았다. 보호 목록은 이전 불변 manifest에 hash로 묶인 invariants를 재사용하여 base/b043/db58 모두와 실제 대조했다.

본인 source1 raw SHA256은 여전히 `0449986801c914722cfaf2022afbc678d858d433aadb39a80f3cb30a98e4144e`이다. source1 BLOCK/severity/증거를 수정하지 않았다.

## B-MENU-P2-01: FIXED (원 severity P2 보존)

공통 경로 prefix: `packages/kor-travel-transport-admin/frontend/`

- `e2e/admin-mobile-navigation.spec.ts:5–6` beforeEach는 실제 Playwright **baseURL fixture**를 검사한다. 각 caller도 같은 fixture를 :13–14의 helper에 전달한다. 환경변수 fallback으로 안전을 판정하던 분기는 제거됐다.
- 새 `e2e/mobile-navigation-fixture.ts:3–9`는 parse 가능한 HTTP(S), exact 127.0.0.1/localhost/[::1], username/password 부재를 요구한다. undefined·empty·non-loopback·unsafe protocol·userinfo는 거부한다.
- :12–17은 실제 baseURL에서 origin을 얻고 target을 해석하여 HTTP(S), 동일 origin, userinfo 부재를 **모든 Page 부작용 전에** 확인한다.
- :19–22 cookie URL은 검증한 origin이다. :24 API matcher는 같은 origin의 /api/transport/ prefix에만 적용된다. :32는 검증한 target.href로 절대 goto한다.
- timetable 직접 이동(:44)과 login 직접 이동(:111)도 실제 baseURL의 검증된 origin을 사용한다. provider tile abort는 별도의 고정 VWorld matcher이며 원격 API 응답 fixture로 확대되지 않는다.

**본인 실제 재검증:** exact db58 Git blob을 bytes 변경 없이 private `actual-helper.mts`로 복사했다. Node v22.22.2의 built-in --experimental-strip-types로 type import/annotation만 처리하여 **actual exported helper를 직접 import**했다. 제품 로직을 Python/JS mirror로 다시 구현하지 않았다. Page/context/route/goto는 기록만 하는 fake이고 Playwright runtime/browser/server는 시작하지 않았다.

| direct pure controls | 결과 |
|---|---|
| 전달된 actual-helper controls | **16 PASS = 13거부 + 3정상** |
| B 추가 controls | **11 PASS = 9거부 + 2정상** |
| 합계 / exit / stderr / fetch calls | **27 PASS / 0 / empty / 0** |

원 실패인 remote caller + env unset / env loopback에서 context/addCookies/route/goto가 모두 호출되지 않았다. env가 반대로 remote여도 실제 caller가 정상 loopback이면 정상 작동했다. 잘못된 hostname suffix, protocol, URL userinfo, cross-origin/network-path/blob target도 부작용 전에 거부됐다.

추가로 ws scheme, encoded userinfo, localhost trailing dot, password-only userinfo, 다른 port·scheme target, javascript target, backslash network-path를 거부했다. normalized localhost/default port와 same-origin absolute target은 허용했다. 각 정상 case에서 cookie origin과 절대 goto를 검사하고, 실제 API route predicate가 foreign origin·logout·비슷한 prefix를 매칭하지 않는지도 직접 호출해 확인했다.

따라서 caller variation에 대한 **원 finding FIXED**다. 실제 원격 HTTP나 정상 운영 인증을 실행한 결과는 아니다.

## 나머지 delta 독립 검토 / 새 finding 0

**메뉴 가로 스크롤·수명:** `components/admin-shell.tsx:47–81`은 scrollIntoView 대신 해당 container.scrollTo만 호출한다. left는 현재 scrollLeft/양쪽 rect/clientLeft/폭으로 계산하고 top은 기존 scrollTop을 유지한다. reduced-motion의 auto/smooth도 유지한다. 문서 자체를 이동시키거나 input focus를 강제로 바꾸는 호출은 없다.

ResizeObserver는 clientWidth가 바뀐 경우에만 재정렬하며 height-only 통지는 무시한다. font ready/loadingdone은 폰트 폭 변경 후 재정렬한다. cleanup에서 cancelled 플래그, observer disconnect, font listener 제거를 수행하므로 이전 path의 ready Promise가 완료되어도 더 이상 스크롤하지 않는다. 이 판단은 소스 검토이며 실제 font/layout/browser 수용 통과를 대신하지 않는다.

**테스트 강도:** unit은 직접 container의 좌표·기존 scrollTop·auto/smooth와 height-only 무호출을 assert한다. 기존 10 browser case의 링크 수/geometry/focus/active-center assertion을 유지하면서 실제 fixture origin에 연결했다. 새 긴 화면 case(:117)는 실제 input focus, 충분한 문서 길이, nav가 화면 위에 있다는 선행조건과 height-only 변경 후 scrollY/focus 보존을 요구한다. DOM에 가짜 긴 행을 붙여 선행조건을 대신하는 코드는 없다.

**Zustand/SSR/state:** createStore의 instance별 useState 초기화, 실제 useStore/setState/getState, storage exception handling 및 effect-only preference 복구는 b043과 같다. SSR/client 초기 false 상태를 유지하고 browser storage를 render 중 읽지 않는다. 살아 있는 두 instance의 store는 독립이며 새 mount가 같은 앱 preference를 읽는 설계다. 실시간 cross-tab sync를 구현했다고 주장하지 않는다. hydrateRoot/StrictMode·두 실제 component instance의 browser 재현은 이번 pure URL helper 검증의 범위 밖이다.

**API/logout/cache·C11:** 19 routes groups는 base와 동일하다. POST logout/form submit, login early return, dashboard-v1/v2 cache 정리와 서버 auth/session/origin/proxy/API/schema 경계는 이전 source와 동일한 Git blob/소스를 유지한다. shared Button의 submit/aria 전달과 AppMenu import 계약도 변경하지 않았다.

보호298 및 public4/admin6 **tgz 10개**의 base/b043/db58 blob 동일성을 직접 확인하고 실제 SRI를 재계산해 lock/artifact metadata와 대조했다. package/lock/workflow/vendor 고지·버전 축·current packed AppMenu/Button·CSS는 b043 이후 변경하지 않았다. 재발행/repack/신규 React graph 변경은 없다.

**문서/provenance:** journal/resume는 b043의 단위435·기존 native28 성공과 새 메뉴5P5F/82px 실패 및 Alpine 미시작을 보존한다. packet의 b043 diagnostic는 이전 source의 실패 원인 증거로만 사용했다. 이를 db58 실행 성공으로 바꾸지 않았다. peer1 raw에 의존하여 본인 finding을 닫지도 않았다.

## 실행 경계·공격 및 남은 범위

- **직접:** manifest/patch/Git bytes/SRI 정적 검증, exact helper의 no-network pure 27건.
- **이번 미실행:** Vitest 전체/16개 원 libtest 파일 자체의 runner, React component suite, Doctor/type/lint, native/Alpine build, browser, CI 재조회, 실제 auth/Docker/Map/운영 작업.
- unit helper 파일의 16 controls는 같은 actual helper로 독립 재현했다. 이 말은 owner 전체 Vitest run을 본인이 수행했다는 뜻이 아니다.
- b043/prototype의 성공 또는 실패 수치를 db58 PASS로 전용하지 않는다. exact db58 full QA·CI는 freeze 시 진행 중이며 새 immutable 실행 증거에서 확인해야 한다.
- 실제 UI geometry/font/focus, old/new height failure의 browser red/green, SSR hydration console 오류, 실제 instance·preference·storage 오류, 전체 API/로그아웃 runtime은 owner exact-head QA의 영역으로 남긴다.
- Geo key 재사용 승인·2PNG bounded probe는 별도 운영 사실이다. db58에 실제 key/ENV 값 변경은 없고 새 key 실제 UI 배포/수용도 이번 승인 범위가 아니다. primary Map 작업 0을 유지했다.

## 명령·보존 evidence

PowerShell workdir C:\ → wsl.exe를 통해 Git ls-tree -rz / show exact:PATH / rev-parse / diff 및 Python hash·SRI를 읽었다. 직접 pure 실행 명령:

~~~text
/usr/local/bin/node --experimental-strip-types /home/digitie/dev/common-unification-20261111/review-B-transport-mobile-menu-db58-source-2-evidence/pure/probe.mjs
~~~

독립 evidence: `review-B-transport-mobile-menu-db58-source-2-evidence/`

| 파일 | SHA256 |
|---|---|
| manifest.json | 937c35fbdae1f9b219c1601fc1507efccad90caac9f2636bd6d114748a777939 |
| static-audit.py | e9372cf62606abd3b7fa1e66981b5268ebe5c6b14401c21d6bc5a966bcc95ad9 |
| static-verification.json | 0da987856e5b8fe53861eb0538db79d0c9f10c13f7c5847f0a1583e470948b95 |
| pure/actual-helper.mts (exact Git bytes) | 00a2b610fb1ae1fa3924ddc7e68a60bed30a8accedc7cb356b7912895258443d |
| pure/probe.mjs | 57b4c3bb844ad78ce95976bdc2d0e9da770a1b20641f2bdd3cde517b578926c2 |
| pure-results.json | 44502e9185e7b784f36bc9ae9430c1c6c07ffabf436342b12601a625809847f6 |

stdout/stderr/exit도 같은 evidence에 보존했다. 작성한 것은 본 리뷰의 private fixture/evidence와 새 raw뿐이며 source/index/branch·공유 modules/cache·기존 원문은 변경하지 않았다. 추가 heavy·install·server·browser·network·Docker·prod auth는 0이다.

**SOURCE PASS / B-MENU-P2-01 FIXED / new findings 0.** 본인 finding의 source/pure closure이며 다른 reviewer의 closure를 대신하지 않는다. mergeAllowedAtFreeze=false를 실행 승인으로 바꾸지 않는다. 실제 full QA·CI·merge/image/ENV/apply·정상 운영 수용은 별도 gate다.
