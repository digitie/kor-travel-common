# Transport 모바일 메뉴 cd4 — 원 리뷰어 A bounded source4
runid review-A-transport-mobile-menu-cd4-source-4-20261112T035450Z; 원 A/Mill, 구현 비참여·읽기 전용. 상대 현재4 결과 미접근.
UTC 시작2026-11-12T03:54:50Z. 고정 source cd4ff768894d29199674c9f540399f7aeaf65170 / tree510888aa00fa949531e392c68061ff9ee72a5b83.
입력 validation/review-transport-mobile-menu-cd4-source-input4/manifest.json SHA256 ee4fc31a4b59d124f12b6f06ffb20af5967c85c4b8805347adfc74045b11388d 일치.
**SOURCE PASS / 신규 finding0(P0/P1/P2/P3 모두0). 정확 cd4 실행·CI·머지·배포 승인은 별도 미완.**
ee45 이후 정확4경로(CSS/E2E/doc2)만 변경. packet11파일 길이/hash 전부 일치, prior-final.patch도 실제 Git diff와 전체 바이트 동일.
원 SOURCE3 SHA81a796a3e7097bab98df5294c864a08e2901b6a97d4f5966e6a10e1703140b2a 및 추가관찰 SHA4e2a45836351a498e14c86ae3b3a20f10291c6d87852043d631680b392060358 보존.
본인 A-TR-MENU-P2-01은 소스 FIXED 유지: 제품 JS 전체 동일이라 컨테이너 수평 이동·폭/폰트 수명·callback 취소에 새 변경 없음.
추가 여백 관찰은 최소 원인 수정이 소스에 반영됨. 실제 cd4 geometry closure는 새 실행으로 별도 확인해야 함.
CSS 위치 packages/kor-travel-transport-admin/frontend/app/globals.css:830–:841.
:831의 max-width1023px .admin-layout에 grid-template-rows:auto minmax(0,1fr)를 적용해 일반 화면의 implicit auto/auto 행 배분을 제거함.
기존 map/parking 전용 동일 선언2줄은 중복 제거. 범위를 전 화면 모바일로 통일하며 padding/height/제품 JS를 덧바꾸지 않음.
1024px 이상에서는 새 행 규칙이 적용되지 않아 desktop rail/collapse 크기와 무관함.
지도는 기존 auto+minmax(0,1fr) 의미를 유지. 확장 지도 :650의 더 높은 specificity 단일 행/rail 숨김 규칙도 남아 있음.
일반 긴 문서는 min-height만 유지하고 전체 고정 height/overflow 잠금을 추가하지 않음. 실제 긴 문서/지도/공항 sizing은 후속 gate.
기존 ee45 측정의 원인 연결:375px rail193.5→override171, logo/logout 중심오차5.625→0.
768px height900/1100에서 원 rail282.75/382.75, override171/171. 원 중심오차27.9375/52.9375→0/0.
위 수치는 hash고정 ISOLATED_GEOMETRY_ONLY의 **ee45 기존 빌드+CSS override** 기록이며 cd4 새 빌드·브라우저 증거가 아님.
새 E2E 위치 e2e/admin-mobile-navigation.spec.ts의 /parking·/rail/timetable 두 기존 case.
fonts.ready 후900px에서 rail boundingBox.height를 저장하고 같은768px 폭/높이1100에서 차이<1px를 poll함.
그러므로 기존 일반 시간표의 +100px 팽창을 잡는 assertion이다. 원 row/19links/팝업 없음/문서 가로 overflow 단언을 유지하고 재검사도 추가함.
두 기존 case의 단언 강화이므로 새 case 두 개를 실행했다는 의미가 아님. 절대171px나 logo/logout 중심 일치는 hardcode하지 않아 별도 실제 geometry 확인은 필요.
제품 shell/menu unit/fixture/helper test/package/lock/common 원장 blob이 ee45와 동일함을 직접 대조. Disposable mock 및 origin 경계에 delta 없음.
doc2는 old451/native39와 시각 문제·override 진단을 보존하고 새 소스 검증을 별도로 명시함. 과거 PASS를 cd4로 전용하지 않음.
새 unit/33probe/fullsourceaudit/type/build/browser/CI 조회/서버/설치/Docker/운영 auth/Map ops/추가 heavy 모두0. 실행 승인 미제공.
PowerShell workdir C:\→WSL Python, Git show/diff/rev-parse 및 hashlib/제공 geometry JSON만 사용. 실제 작업트리는 관찰 시 cd4/clean.
자기 evidence review-A-transport-mobile-menu-cd4-source-4-evidence/:verification.json,ee45-cd4.patch,old-override-geometry-summary.json,bridge-and-observations.json.
최종: bounded source4 PASS/신규0/원 finding 소스 FIXED 유지/여백 원인 수정 소스 확인. exact 새 QA·CI·ARM·공식 적용·정상 운영 수용은 별도.
