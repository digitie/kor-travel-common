from pathlib import Path
import argparse,hashlib,json,re,os
EXPECTED_SHA = "c08b2b9a8165677804b89e360359b046477dc01d5b573b3f9a860a3b2099536f"
OLD_SOURCE = "9aebd19947c3606c2953eb564e7eee4541be5856"
OLD_IMAGE = "sha256:cb611f30dd829c78e7d102724e7fe5e4dfe34bb84da9a363872c1ee7a3700bb6"
def bind(raw, identity):
    if hashlib.sha256(raw).hexdigest() != EXPECTED_SHA:
        raise ValueError("reviewed common input mismatch")
    if set(identity) != {"sourceSHA", "imageID"}:
        raise ValueError("identity metadata only")
    source, image = identity["sourceSHA"], identity["imageID"]
    if not isinstance(source,str) or not re.fullmatch("[0-9a-f]{40}",source) or source == OLD_SOURCE:
        raise ValueError("new merged source required")
    if not isinstance(image,str) or not re.fullmatch("sha256:[0-9a-f]{64}",image) or image == OLD_IMAGE:
        raise ValueError("new merged image required")
    old_source = ("const ADMIN_SOURCE='" + OLD_SOURCE + "';").encode()
    old_image = ("const ADMIN_IMAGE='" + OLD_IMAGE + "';").encode()
    new_source = ("const ADMIN_SOURCE='" + source + "';").encode()
    new_image = ("const ADMIN_IMAGE='" + image + "';").encode()
    if raw.count(old_source) != 1 or raw.count(old_image) != 1:
        raise ValueError("exact identity anchors required")
    out = raw.replace(old_source,new_source,1).replace(old_image,new_image,1)
    if out.replace(new_source,old_source,1).replace(new_image,old_image,1) != raw:
        raise ValueError("nonidentity mutation rejected")
    return out
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--source-file",required=True)
    parser.add_argument("--identity-file",required=True)
    parser.add_argument("--output",required=True)
    args=parser.parse_args()
    raw=Path(args.source_file).read_bytes()
    identity=json.loads(Path(args.identity_file).read_text())
    out=bind(raw,identity)
    with os.fdopen(os.open(args.output,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),"wb") as stream:
        stream.write(out)
    print(json.dumps({"sourceSHA":identity["sourceSHA"],"imageID":identity["imageID"],"commonSHA256":hashlib.sha256(out).hexdigest(),"identityConstantsOnly":True,"admissionEnabled":False}))
if __name__ == "__main__":
    main()
