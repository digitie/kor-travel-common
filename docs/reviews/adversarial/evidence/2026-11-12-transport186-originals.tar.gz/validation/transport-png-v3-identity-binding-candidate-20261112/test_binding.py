from pathlib import Path
import unittest,importlib.util,hashlib
spec=importlib.util.spec_from_file_location("binding",Path(__file__).with_name("bind_qa_identity.py"));binding=importlib.util.module_from_spec(spec);spec.loader.exec_module(binding)
RAW=Path('/home/digitie/dev/common-unification-20261111/validation/transport-png-bootstrap-v3-runtime-review-bundle-20261112/private/acceptance-common.cjs').read_bytes()
class IdentityBinding(unittest.TestCase):
    def test_valid_metadata_changes_only_two_identity_constants(self):
        identity={"sourceSHA":"1"*40,"imageID":"sha256:"+"2"*64}
        out=binding.bind(RAW,identity)
        self.assertNotEqual(out,RAW)
        restored=out.replace(identity["sourceSHA"].encode(),binding.OLD_SOURCE.encode(),1).replace(identity["imageID"].encode(),binding.OLD_IMAGE.encode(),1)
        self.assertEqual(restored,RAW)
        for token in [b"admission.enabled!==true",b"officialCurrentHealthy!==true",b"qaReady!==true",b"currentVerified!==true",b"role!==",b"input.credentials?.password"]:
            self.assertTrue(token in out,"guard marker missing")
    def test_invalid_or_old_tuple_and_mutated_input_rejected(self):
        good={"sourceSHA":"1"*40,"imageID":"sha256:"+"2"*64}
        for bad in [{"sourceSHA":binding.OLD_SOURCE,"imageID":good["imageID"]},{"sourceSHA":good["sourceSHA"],"imageID":binding.OLD_IMAGE},{"sourceSHA":"not-a-hash","imageID":good["imageID"]},{**good,"credentials":"forbidden"}]:
            with self.subTest(badKeys=list(bad)):
                with self.assertRaises(ValueError):binding.bind(RAW,bad)
        with self.assertRaises(ValueError):binding.bind(RAW+b" ",good)
if __name__=="__main__":unittest.main()
