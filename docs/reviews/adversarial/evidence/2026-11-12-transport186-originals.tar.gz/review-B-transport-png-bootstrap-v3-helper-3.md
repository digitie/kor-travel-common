# Original B — Transport PNG bootstrap v3 concrete helper3

- Run ID: `B-PNG-V3-HELPER3-20261112`; frozen UTC: `2026-11-12T12:33:23.287944+00:00`.
- Reviewer: 원 reviewer B / Epicurus, 구현 비참여. 현재 상대 helper3 원문·결과 열람 0.
- 판정: **HELPER_CONTRACT_PASS / 신규 finding 0 (P0/P1/P2/P3 모두 0)**.
- 범위: 봉인된 helper·실제 caller의 정적 연결, 새 시간/UX 계약, pure controls. runtime·CI·배포·운영 QA 승인 및 추가 운영 로그인 GO는 포함하지 않는다.

## 불변 입력과 직접 검산

Manifest: `review-manifest-transport-png-bootstrap-v3-helper-3.json`, SHA256 `c9352664899147136dc544ff29788f8a0aa6371830ce6e44ffe65de5442c2c0e`.

`validation/transport-png-bootstrap-v3-parent-candidate-20261112/`의 14개 입력과 `validation/transport-png-bootstrap-v3-runtime-review-bundle-20261112/`의 실제 7개 module을 각각 SHA256·bytes·mode 0600으로 검산했다. Manifest의 8개 reference도 해시·크기 일치. Bundle 5개는 과거 봉인 module과 byte-identical, 2개는 이번 helper/caller 원문과 일치한다. 모든 상대경로 require 대상이 bundle 안에 존재하며 7개 syntax check가 exit 0이다. 실제 browser factory는 import/실행하지 않았다.

| 대상 | 관찰 SHA256 |
| --- | --- |
| helper `actual-png.bootstrap-v3.cjs` | `5b4cbc4fe1347260f58acaea6c5f9e1377939f9adaaa90533493f22cabd51619` |
| caller `admin-actual.bootstrap-v3.cjs` | `a211d5ce8a7609d18229dcfe4f5c3b94c2710662e73e2dbd43ace80030e4af4b` |
| contract | `56da3accc4f9ba3085c6c0aaf61f79fd14a855063a7b664ac7842b11a3f6f7bf` |
| frozen 14 index | `506d5598bee05609c294e190adfb640eba9448e1624c42b8fcff3a991beeb85e` |
| bundle 7 manifest | `931c89c9ab4e0ae18428f01b806abf4e82c79c402373cc3a9e29ad3f13d2cfd3` |

제품 context는 Git object `bd08ec1c09968f930e5356a70ba7eedd4d47f635`, tree `4fec4f76df0cd88fdaca22d42ae2acb2f876ce6f`로 확인했다. b43 대비 docs 2개만 변경, 나머지 908 tree entries 동일. 기존 source2의 `B-MAP-LOAD-P3-01 FIXED` 및 원문은 유지한다. 이번 helper는 Git 제품 source 변경이나 pack 재발행이 아니다.

## 계약·공격 평가

1. **시간 계약 변경은 명시적이다.** Helper 56–79행과 contract는 기존 canvas/control 초기 5초를 완화하고, navigation 전 같은 monotonic t0의 UX 5초와 bootstrap 전체 60초로 바꾼다. 이는 기존 검사와 동등하거나 성능이 개선됐다는 증명이 아니다. Navigation/action 30초 상한, 남은 전체 예산에 포함된 initial idle/response body/XML/decode/drain/camera, deadline 정확한 경계 실패가 연결돼 있다. Zoom 후 camera 20/decode 45/idle 30은 유지되고 outer 125초·cleanup 10초 상한이 추가된다.
2. **Pending과 phase 경합:** helper 35–53, 70, 79–84행. Phase 종료 후 최종 drain/camera 순서이며 expired/live뿐 아니라 pending job과 모든 row.done을 성공 전 확인한다. 직접 추가 공격에서 늦게 성공한 raw body는 기한 실패를 복구하지 못했다. Overlay 관측 때 끼어든 지연 XML job도 drain 뒤 `bad-rows` 실패로 남았다. 이 판정은 수집한 두 phase에 대한 것으로, phase 종료 이후 모든 미래 WMTS 응답까지 검사했다는 뜻은 아니다.
3. **Cleanup과 실제 caller:** helper 48–53, 104–109행 및 caller 21행. Decoder를 먼저 닫고 필요하면 context abort, 유한 job 정산을 수행하며 close 결과를 재사용한다. 실제 caller가 정상 logout 이후 closeAndRecord를 호출하고 incomplete/예외를 전체 failed·exit 1로 반영한다. VM으로 봉인 caller 원문 자체를 실행한 정상/불완전/예외 cleanup과 최초 PNG 실패 동시 사례에서 이 연결을 확인했다. 첫 실패는 그대로 앞에 남고 screenshot은 PNG 성공 때만 1회다. VM의 가짜 IO·expect·인증은 제어 흐름 검증용이다.
4. **Navigation 오류 경계:** helper 100–103행은 열린 page의 알려진 context-destroy/cannot-find-context만 준비 전 샘플로 다룬다. 새 문서 identity·`/map`·HTTP 200 및 기존 deadline은 유지한다. 닫힌 page/일반 evaluate 오류를 숨기지 않는 pure controls가 통과했다.
5. **품질 oracle:** 원본 key constant·bad-row 식·XML callback이 일치한다. XML callback SHA256 `bc6409992e58acebd4ea0da798f01ed2d225e9c3e9ea0805179026af5c4eda94`. 각 phase 실제 decoded 성공 >=1, decode 시도 최대 2를 유지하며 IHDR/bitmap 치수 일치가 추가됐다. Outside-coverage 허용 XML은 decoded PNG로 세지 않는다. 색 판정은 computed 문자열 비동일성이고 대비율·색 합성·paint 보장이 아니다. Text range 90% clip/12×12px·opacity·semantic 및 transport loader 제거 검사는 명시한 범위로만 인정한다.
6. **나머지 검사·인증 보존:** Caller 변경은 11/12/21행의 PNG module·동일 page screenshot/metadata·cleanup verdict 연결이다. 이를 되돌린 원문 SHA256 `3f1489d1d1b1c57b5ea96fd65680511679f4a94ea5f8541c48f38fc5411e09d8` 일치. 나머지 검사 body SHA256 `e16bd693a0d48599807e2b4fce8f5ae6989f090a8da69693f0b365ea335c3f30`, 로그인/로그아웃·기존 timer 문맥을 독립 대조했다. Screenshot 30초는 기능 bootstrap 밖의 artifact 시간으로 명시돼 있으며 기능 실패를 통과시키지 않는다.

## 직접 실행과 실패 이력

- Linux `/usr/local/bin/node` v22.22.2; 봉인 파일을 own fixture에 byte-identical 복사해 `node --test negative-controls.test.cjs`: **47 PASS / 0 FAIL / 0 skip / 0 cancelled**.
- `node --test own-attacks.test.cjs`: 최종 **9 PASS / 0 FAIL / 0 skip / 0 cancelled**. Actual collector의 늦은 body/abort/XML 경합, exported attach의 listener 제거·멱등 close·setup 실패, 실제 caller cleanup 제어 흐름을 검증했다.
- Own 추가 fixture r1/r2는 각각 5 PASS / 4 FAIL이었다. r1은 login response mock이 click 후 상태를 참조한 오류, r2는 VM의 URL 전역 누락으로 logout ReferenceError가 난 오류다. 등록 시 status 캡처와 URL 전역 주입만 교정했고, 단언·봉인 입력은 바꾸지 않았다. 원 fixture/log 전부 보존한다. 최초 입력검산의 caller line index 기대값 1건 오류도 reviewer harness 오류로 기록했다. 제품 red→green으로 주장하지 않는다.
- 부모 v2 개발 27P6F→34P→40P 및 caller 미통합, v3 45/45/47/47 pure 이력은 기존 기록대로 보존한다. 이번 직접 47/9 결과는 실제 renderer/DOMParser/createImageBitmap/네트워크 transport 실행 결과가 아니다.

## 남은 gate와 운영 경계

기존 M9 정상 9검사의 8 PASS / 1 FAIL과 PNG 진단 1 FAIL, 두 번의 원 canvas 5초 실패는 불변이다. 이번 계약으로 소급 PASS 처리하지 않는다. 지연·aborted 요청의 원인이나 성능 개선도 확정하지 않는다. 기존 advisory와 원 source1/2 raw는 수정하지 않았다.

Bundle의 unchanged `acceptance-common.cjs:3,5–10`은 절대경로 warm Playwright 의존성과 **과거 M9 source/image admission pin**을 유지한다. 상대 require 연결 확인은 이 외부 런타임 의존성·새 source 입장 조건 검증을 뜻하지 않는다. 향후 새 제품 actual QA에는 새 공식 selected input, 정확한 merged source/image/admission 바인딩 및 그 변경을 포함한 봉인 증거가 필요하다. 과거 M9 input이나 이번 bundle의 정적 합격만으로 새 bd08 제품을 수용할 수 없다.

실제 browser의 navigation-context 발생/색·clip/opacity/overlay 제거, decoder/context abort의 실제 취소 및 종료, 실제 PNG decode·camera·idle, fresh exact CI·ARM·official apply·normal acceptance는 이번 검토에서 NOT_RUN/별도 gate다. Setup 실패/최종 factory finish까지 포함한 browser 전체 수명은 실제 취소 검증이 필요하며 helper close의 10초 상한을 전체 운영 세션 상한으로 확대하지 않는다. 새 운영 세션 승인 0, 다른 8개 검사의 실제 재실행 0, install/build/browser/SDK/Docker/Map 작업 0.

## 명령·증거·최종 disposition

명령과 검산은 own evidence의 `commands.md`, `verify-inputs.py`, `verification.json`, `source-and-results.json` 및 pure log/소스에 보존했다. Git은 `rev-parse`, `diff-tree`, `ls-tree` object 읽기만 사용했다. 제품/source/index/branch, 기존 manifest/report는 변경하지 않았다.

Own evidence: `validation/review-B-transport-png-bootstrap-v3-helper-3-20261112/`.
Evidence index SHA256: `d03fdfa52875405abedb0f5c675c315441317321ccfe4351870f5eb35b504dfe` (`evidence-index.json`; 각 own evidence 파일의 bytes/SHA256 포함).

**최종 disposition: HELPER_CONTRACT_PASS, 신규 finding 0.** 제한된 새 helper 계약·정적 caller 연결·pure 회귀에 대한 판정이며, runtime/CI/deploy 또는 다음 운영 로그인 수용 판정이 아니다.
