# Original A — Transport bd08 FINAL_EXECUTION4

- Run ID: `A-TR-MAP-BD08-EXEC4-20261112T125459Z`
- UTC 동결: `2026-11-12T12:54:59.621333+00:00`
- 독립 원 A / frontend·SDK lifecycle·가시적 피드백·시간 계약. 구현 비참여, 상대 CURRENT exec4 원문/판정 열람0.
- Manifest: `review-manifest-transport-map-loading-bd08-final-execution-4.json`
- 실제 SHA256: `a574561afcd7d68ae485e064eacc3234c1cb35ef57efc2899f83a8e598c2e5c6` — 요청값 일치. 18 frozen refs의 SHA256/bytes도 전부 일치하며 마지막에 재확인했다.
- Exact source: `bd08ec1c09968f930e5356a70ba7eedd4d47f635`; tree: `4fec4f76df0cd88fdaca22d42ae2acb2f876ce6f`.

## 판정과 disposition

**PREMERGE_PASS / new findings 0 / P0=0, P1=0, P2=0, P3=0.**

원 source2와 helper3 판정을 유지하고, 이 정확한 source의 local QA·캐시 ARM 근거·identity binder·최종 CI 결박 범위를 독립 확인했다. source2의 문서 P3 교정과 A helper3 HELPER_CONTRACT_PASS는 보존한다. 현재 입력에서 추가 조치할 source/품질 finding은 발견하지 않았다. 실제 merged M/image의 운영 수용이나 추가 로그인 승인은 아니다.

## 독립 검산 및 실행 증거

1. **source/CI tree:** Git object `ls-tree`/`rev-parse`로 b43→bd08은 journal/resume 두 문서만 변경, 다른908개 tree entry가 mode/type/OID까지 같음을 확인했다. 총910 entry는 normal blob909+gitlink1이다. actual QA source는 여전히 **b43**, bd08 전체909개를 직접 QA했다고 바꾸지 않는다. CI synthetic `8303f9f29a9cc6b54995af499ba2c12242a33cd6`의 tree는 bd08과 같다. 해당 commit/parents/tree는 GitHub Git API로도 직접 확인했다.
2. **QA124/ARM16:** 봉인140개 실제 파일을 각 SHA256·bytes·mode와 대조해 mismatch0. ARM 원격 상태를 새로 조회하지 않았으며 local frozen raw와 parent의 remote hash receipt를 구분했다. ARM 원본 source909개는 Git blob OID·mode 및 실제 `cat-file --batch` bytes의 SHA256을 직접 검산했다. Dockerfile COPY namespace를 적용한298개도 일치하며 local/ARM source map과 COPY map이 같다. 설치/빌드 없이 memory-only 해시 계산이다.
3. **local browser accounting:** 10개 실제 Playwright JSON의86 case = native43+Alpine43을 직접 펼쳐 전부 expected/pass, results1개, retry0, skip/flaky/errors0 확인. NoJS2는 native43 안에 포함되어 재실행/중복 가산하지 않는다. old edb 동일 NoJS spec의0P2F는 별도 예상 RED로 보존되며 새86개의 실패로 계산하지 않는다. 총 기록 case execution은 old2+new86=88이다.
4. **NoJS 가시성:** old 1280/375 text visibleArea·ratio0 → b43 각각2916/3411.84375 및 ratio1. 새 색은 실제 computed foreground와 background가 서로 다르다. 정확한 PNG2장을 직접 열어 PC rail/mobile header와 중앙 로딩 문구가 작업면 안에 보이는 것을 확인했고, Windows 원본과 frozen reference의 SHA/bytes도 일치한다. 이는 loopback NoJS rail frame의 레이아웃/문구 근거다. 실제 `/map` 운영5초·SDK bootstrap·타일/bitmap·카메라·보조기기 대비의 증거로 확장하지 않는다. 미실행59a 색상 alias 점검을 실측 실패로 바꾸지 않는다.
5. **QA 환경/cleanup:** frozen image audit에서 COPY298/Common263 mismatch0, routes32 및 rail/parking-lots/rail-timetable을 확인했다. final cleanup에 own server/port/container/heavy0, runner exit0가 남아 있다. 최초 template 대기 target0·전송 timeout·stdin audit transport timeout과 mounted-script 복구 기록은 보존된다. 원격 프로세스를 직접 다시 조회하거나 테스트를 재실행하지 않았다.
6. **ARM cache:** `4cca2e4a9484feaa86d234817e19e8242cce21c8646a5cac48bc5bcccc7474de`는 b43 ARM64 cache-only다. OCI/default ENV도 b43, source909/COPY298/Common263/routes32와 compiled key SHA `2d48…`/canonical ENV SHA `4f57…` 근거가 일치한다. actualApplyAllowed/deployReady/official-preflight-ready는 false. 이 캐시 이미지는 미래 merged M 이미지로 승인하지 않는다.

## 새 identity binder와 helper 계약

- `bind_qa_identity.py` SHA256 `793fb71da177bcb198049f442e879788faddce1ab8b4b9232e283edc413a593c`를 줄 단위로 확인했다. 입력 common SHA `c08b2b9a8165677804b89e360359b046477dc01d5b573b3f9a860a3b2099536f`를 먼저 고정하고, 정확히 sourceSHA/imageID 두 key만 허용한다. lowercase40/source와 sha25664/image 문법, 이전 M9 tuple 거절, 고유 anchor 및 역치환 원본 일치를 강제한다.
- 바뀌는 것은 `ADMIN_SOURCE`/`ADMIN_IMAGE` 두 const의 값이다. 공유 common의 인증·ownership·role/current·qaReady·officialCurrentHealthy·admission 조건, 다른 검사/타이머는 그대로다. CLI 출력은 `O_EXCL`·0600으로 기존 파일을 덮어쓰지 않는다. CLI 파일쓰기 안전성은 소스 검토이며 CLI를 운영 tuple로 실행하지 않았다. provenance의 진실성은 이 문자열 변환기가 증명하지 않으므로 이후 공식 exact M/image/postproof가 필요하다.
- `python3 -B <binder>/test_binding.py -v`를 직접 실행: **2 PASS, exit0**. 원 r1=1P1F(test marker의 optional chaining 오기), r2=2P raw와 hash를 보존·검산했다. factory 변경/운영 실행으로 해석하지 않는다.
- 준비 bundle7개 SHA/bytes/mode와 지정 원본이 동일하다. 실제 준비 admission.enabled=false, expectedM/image는 미정이다. 향후 binder 두 const 예외 외의 모듈을 바꾸면 이 승인으로 대체할 수 없다.
- 부모의 명시적 UX5 + bootstrapTOTAL60 새 계약 채택을 별도 frozen decision으로 확인했다. early canvas5초를 완화한 새 계약이며 동등 검사나 성능 개선이 아니다. helper3의 body/decode/idle/drain/camera 및 post-zoom20/45/30 조건, overall cleanup verdict를 유지해야 한다. screenshot artifact30초는 별도이며 기존 outer900초는 총 ceiling일 뿐 다른8검사 모든 독립 최악 시간을 보장하지 않는다. timeout은 실패다.
- 원 M9 최초8P1F와 PNG-only FAIL **두 판정은 그대로**다. 원인의 성능/자원/라이브러리 단정이나 결과 소급 변경은 하지 않았다. 기존 raw5개 해시도 다시 일치했다. 이 단계에서 새 private PNG helper의 실제 브라우저 실행은0이다.

## 직접 확인한 exact CI

초기 자체 API 관찰에서는 backend2가 RUNNING이었다. 최종 관찰은 아래와 같으며 초기 manifest/초기 own API 기록을 덮어쓰지 않았다. 부모의 최종 CI receipt가 오기 전에 자체 API·필요 로그로 확인한 판정이다.

| run / event | attempt / head | 최종 자체 API |
|---|---|---|
| 43215261871 / pull_request | 1 / bd08ec1… | completed SUCCESS |
| 43215254241 / push | 1 / bd08ec1… | completed SUCCESS |
| 43215262267 / policy pull_request | 1 / bd08ec1… | completed SUCCESS |

- PR public131172768760 **164 PASS**, admin131172769374 **458 PASS**, Doctor0·type/lint/build 성공. push public131172742130/admin131172742118도 같은 수와 성공 상태를 직접 확인했다.
- PR backend131172769114: **1548 PASS / 2 SKIP / 6 warnings / 2390.00s**. push backend131172741666: **1548 PASS / 2 SKIP / 6 warnings / 2479.74s**. 두 로그의 checkout은 각각 synthetic8303f9와 exactbd08이다.
- policy 두 job 모두 SUCCESS. 로그의 실행 code `55a921b55d248106cbe320e7f5305f3d3cdb60fe`, 실제 중앙 policy data `e8ed3ae75000be5cd22a3a11492bd97660635d78`를 직접 확인했다.
- live-e2e 두 job은 **SKIPPED_NOTPASS**다. backend의 기존2 skip도 통과 개수에 포함하지 않는다.
- 직접 받은 decoded UTF-8 job log8개를 own evidence에 보존했다. PR frontend SHA `b673490d3be6b54e78565307699ab8884c6e1e6222ecfe029d1726a6b713b29b`, admin SHA `ad20e9c14a4dc896c168708ad14eb5b0ead441bdd5006905e7c7df26ad98c964`는 봉인 CI bridge와도 일치한다. API source/attempt/whole-tree와 로그 check 결과를 함께 결박했다.

## 경계·원시 증거

실제 미래 merged M의 정상 ARM build/909 source·298 COPY·263 Common·32 routes/OCI/default ENV 감사, 공식 SDK apply/postproof/healthy current, fresh selected input과 **정상1 login+1 logout/9검사/새 PNG visual·actual decoder**는 모두 **postmerge 별도 미완**이다. 본 PREMERGE_PASS를 해당 운영 수용으로 전용하지 않는다. source/runtime 변화0, reviewer browser/build/install/production query/login/SDK/Map ops0이다.

자체 증거: `review-A-transport-map-loading-bd08-final-execution-4-evidence/`의 refs 검산,140파일 검산,Git source/COPY 검산,browser accounting,binder2 로그,직접 본 PNG 기록,초기/최종 API,job raw8개 및 log verification. 명령은 PowerShell workdir `C:\`의 `wsl.exe --exec python3 …`, Git object read-only 명령, `python3 -B test_binding.py -v`, GitHub GET 도구뿐이다. 중간 verifier 경로 namespace/Windows 명령 길이/schema 오류는 own-final-audit에 기록했고 제품 테스트 실패나 숨긴 재실행으로 계산하지 않는다.

Evidence index SHA256: `215d4d108638d90c84c66c0100ddb7f994bc324ca3282fc07546749fd2652e70`. 모든 과거 원문/manifest·원 실패 로그는 불변 보존했고, 본 원문은 새 파일로 독립 동결했다.
