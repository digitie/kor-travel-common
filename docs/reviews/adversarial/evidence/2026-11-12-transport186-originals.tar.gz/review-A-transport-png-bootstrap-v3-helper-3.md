# Original A — Transport PNG bootstrap v3 HELPER3 독립 검토

- runid: `A-TR-PNG-BOOTSTRAP-V3-HELPER3-20261112T123134Z`
- 관찰/동결 UTC: `2026-11-12T12:31:34.255112+00:00`
- 역할: 원 A frontend/SDK lifecycle·가시적 피드백·시간 계약 독립 리뷰어. 구현 비참여, 상대 CURRENT helper3 원문/판정 열람 0.
- 입력: `review-manifest-transport-png-bootstrap-v3-helper-3.json`
- 실제 manifest SHA256: `c9352664899147136dc544ff29788f8a0aa6371830ce6e44ffe65de5442c2c0e` — 요청값 일치.
- 대상: `validation/transport-png-bootstrap-v3-parent-candidate-20261112/`와 실제 7-module runtime review bundle. 제품 bd08/source2 기존 판정은 보존한다.

## 판정

**HELPER_CONTRACT_PASS / new findings 0 / P0=0, P1=0, P2=0, P3=0.**
이는 봉인된 구체 helper·실제 caller의 정적 통합 및 pure control 범위 판정이다. 런타임/CI/배포/운영 추가 세션 승인이 아니다. 실제 브라우저의 5초 피드백·60초 bootstrap·PNG decoder·취소/정산은 **NOT_RUN/PENDING**이다. 제품 source2의 기존 P3 FIXED 판정은 변경하지 않는다.

## 바이트·원본 보존 근거

1. manifest 참조 8개, frozen inputs 14개, bundle 7개 총 29개 항목의 실제 SHA256/byte 수를 직접 검산했다. mode가 지정된 21개 항목은 모두 `0600` 일치. 입력 재확인까지 mismatch 0이다.
2. bundle 5개 이전 모듈은 각 지정 원본과 byte-identical, 새 2개는 candidate helper/caller와 byte-identical이다. 7개 모듈 내부 상대 require는 모두 bundle에 존재한다. 외부의 기존 warm Playwright 경로·향후 admission/payload는 별도이며 이를 실행하지 않았다.
3. helper SHA256: `5b4cbc4fe1347260f58acaea6c5f9e1377939f9adaaa90533493f22cabd51619`; caller SHA256: `a211d5ce8a7609d18229dcfe4f5c3b94c2710662e73e2dbd43ace80030e4af4b`.
4. caller 원본 대비 실제 diff는 11–12행과 21행 두 hunk뿐이다. helper 연결/성공 후 동일 page screenshot·metadata/cleanup verdict 연결을 되돌리면 원본 SHA256 `3f1489d1d1b1c57b5ea96fd65680511679f4a94ea5f8541c48f38fc5411e09d8`와 일치한다. 다른 로그인·로그아웃·8개 검사·타이머 구간은 바이트가 같다. 나머지 검사 본문 13–19행 SHA256은 `e16bd693a0d48599807e2b4fce8f5ae6989f090a8da69693f0b365ea335c3f30`이다.
5. XML classifier 원문 SHA256 `bc6409992e58acebd4ea0da798f01ed2d225e9c3e9ea0805179026af5c4eda94`, expected-key 상수, 기존 bad-row 식이 원본 helper와 같다. 가짜 XML parser가 실제 DOMParser 증거가 되지는 않는다.

## 독립 공격 및 소스 판단

모든 행 번호는 candidate `actual-png.bootstrap-v3.cjs` 기준이다.

- **기한 공유(8–24, 56–84행):** monotonic t0 이후 UX5/전체 bootstrap60을 공유하고 navigation/action은 최대30초다. navigation 성공 HTTP200과 새 문서 identity·`/map`을 함께 요구한다. 새 문서의 알려진 context 파괴만 미준비 샘플로 처리하며(100–103행), 다른 오류/닫힌 page는 실패한다. 정확한 deadline 도달도 실패하며 bootstrap의 flush·마지막 camera read까지 남은 시간을 확인한다. post-zoom camera20/decode45/idle30은 유지하고 action을 포함한125초 outer cap을 추가한다.
- **피드백(26–27, 86–99행):** 의미 있는 문구의 text Range/viewport/overflow 조상 교집합, 12×12 이상·90% 이상 노출, display/visibility/누적 opacity, 최소 색 비동일성을 검사한다. 오래된 문서·다른 route의 문구를 재사용할 수 없다. ready-map 대안도 canvas/control/engine idle/tilesLoaded/decoded PNG를 모두 요구한다. 초기·zoom 후 `.transport-map-loading`이 계속 노출되면 실패한다.
- **수집·정산(33–55, 70, 79–84행):** phase를 닫은 다음 최종 flush와 camera read를 수행한다. raw operation expired/live뿐 아니라 pending job 및 모든 row.done도 검사한다. phase 종료 뒤 새 응답은 측정 표본에 추가되지 않는다. 이는 명시된 phase 표본이며 모든 향후 WMTS 요청을 영구 관찰한다는 뜻은 아니다.
- **이미지/오류(28–29, 38–43, 114–116행):** 실제 adapter는 받은 response bytes를 decoder page의 createImageBitmap으로 보낸다. key/status/MIME/signature/IHDR/bitmap 조건, phase별 최소1개 성공·최대2회 decode 시도, 기존 XML/outside_coverage/bad-row 의미를 유지한다. IHDR/bitmap 치수 일치 조건은 추가된다. pure의 Buffer·decode stub은 실제 PNG 디코딩 증거가 아니다.
- **cleanup(48–54, 104–117행 및 caller21행):** decoder를 먼저 닫고 필요 시 context abort 및 job settlement를 시도한다. 각 close 최대5초/collector cleanup 전체10초, 재호출은 동일 정산을 재사용한다. incomplete/throw는 caller 전체 outcome과 exit를 실패로 만든다. 원 실패는 남고 cleanup 성공이 원 실패를 통과로 소급 변경하지 않는다. 기존 `acceptance-common.cjs:50–55`도 해당 실패 outcome을 통과로 덮어쓰지 않는다. 이10초는 collector close의 예산이며 기존 정상 logout/전체 browser finish의 시간 상한을 새로 보장하는 것은 아니다.
- **실제 caller(11–12, 21행):** 새 helper가 실제 PNG check에 연결됐고 정상 logout 뒤 cleanup verdict가 반영된다. 성공 후 screenshot1장은 같은 page에서 artifact 최대30초를 별도로 쓰며 기능 bootstrap60초 이내 캡처/성능 개선의 증거로 간주하지 않는다.

## 직접 실행 및 명령

WSL을 PowerShell의 `workdir C:\`에서 `wsl.exe --exec ...`로 호출했다. Node 관찰값은 `v22.22.2`다.

- `/usr/local/bin/node --test <candidate>/negative-controls.test.cjs` → **47 PASS, 0 FAIL/SKIP/CANCEL**, exit0. 로그 SHA256 `d0f5d70a86655a004f629f20077c0ea37f518eb0c7dc579b26aecfcb6d232170`.
- `/usr/local/bin/node --check <candidate>/actual-png.bootstrap-v3.cjs` 및 caller → 각각 exit0. caller 자체를 require/실행하지 않았다.
- `/usr/local/bin/node --test <own-evidence>/own-attack-controls.test.cjs` → **8 PASS, 0 FAIL/SKIP/CANCEL**, exit0. 로그 SHA256 `6d64cf415c3db5d7ab2f7bd278d013c64852d8a3129cc04d59676aa3d277c39f`.
- 추가8개: stale document identity, 잘못된 pathname, HTTP503+정상 문구, initial camera 미정산, 두 번째 flush의 공유60초 초과, phase 종료 후 표본 변경, cleanup 성공에 의한 원 실패 소급 변경, IHDR/bitmap 치수 불일치. 실제 helper 함수를 호출하는 dependency-free fake clock/IO 검사다.
- Python `Path.read_bytes`+`hashlib.sha256`+`stat`으로 refs/inputs/bundle을 대조하고 `difflib.SequenceMatcher`로 caller 허용 hunk 및 원본 복원을 독립 검산했다. PowerShell 인용부호 오류1회는 Python 실행 이전 parser 실패였고 literal here-string으로 고쳤다. 제품/검사 실패로 계산하지 않는다.

## 한계 및 보존해야 할 판정

- early canvas/control 5초는 명시적으로 완화됐다. 새 UX5+bootstrap60 계약은 기존 검사의 동등 변경이 아니며 성능 개선 주장이 아니다. 부모가 별도로 승인해야 하는 새 수용 계약을 구체적으로 검사할 수 있다는 범위의 PASS다.
- 기존 M9 최초8P1F 및 PNG-only 진단 FAIL 두 판정은 불변이다. v2 pure40 PASS/호출자 미통합 이력과 v3 개발 로그도 그대로 보존한다. 이 검토가 기존 두 실패를 재채점하지 않는다.
- Range/bbox+색 문자열 조건은 실제 paint/occlusion/WCAG 대비/alpha compositing/스크린리더 사용성 증거가 아니다. Common MapReadout의 실제 bbox·clip은 미측정이고 count prefix가 붙은 status가 해당 문구 prefix matcher에 잡힌다고 가정하지 않는다. 새 Transport 전용 loader의 실제 브라우저 가시성은 후속 QA에서 확인해야 한다.
- 실제 WMTS 수신·DOMParser·createImageBitmap·navigation 중 evaluate·브라우저 close/abort·SDK loaded/loader 제거의 동작은 실행하지 않았다. 이후 별도 GO의 정상 QA에서는 이 정확한7-module bytes와 fresh 공식 selected input, 전체 check outcome/cleanup/원 실패 이력을 함께 결박해야 한다.
- browser/build/install/prod queries/login/SDK/Map ops는 모두0. 제품 source/index/branch/원본 manifest·로그·과거 원문 변경0. runtime/CI/deploy PASS나 추가 운영 로그인 권한을 부여하지 않는다.

## 원시 증거 동결

`review-A-transport-png-bootstrap-v3-helper-3-evidence/`의 `own-execution.json`, `own-pure47.log`, `own-attack-controls.test.cjs`, `own-attack-controls.log`, `own-byte-verification.json`, `own-caller-diff.patch`, `own-module-imports.json`, `own-final-checks.json`에 직접 근거를 저장했다.

증거 index SHA256: `d3aa69a5d8ba44ff129e1b21b1ce5f0754e601e54377825854ad5dc8e3f63466` (`evidence-index.json`). 원문 및 해당 증거를 새로 생성했으며 기존 원문은 덮어쓰지 않았다.
