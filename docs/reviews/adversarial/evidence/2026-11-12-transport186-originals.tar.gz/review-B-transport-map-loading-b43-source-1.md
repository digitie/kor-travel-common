# 원 B Transport map loading b43 SOURCE1

- 원 리뷰어 B(Epicurus), test oracle·증거 무결성·라이브러리 통합 책임·운영 불변성 렌즈. 구현 비참여, 상대 CURRENT 보고서/결과 접근0.
- runid `B-MAP-LOADING-B43-SOURCE1-20261112T120351Z`, 관찰 UTC `2026-11-12T12:03:51Z`.
- **SOURCE PASS / 신규 P3 1건(문서 표현, 비차단). P0/P1/P2 신규0.** 이는 bounded source 판정이며 exact QA/CI·private helper·운영 수용 승인이 아니다.
- manifest `review-manifest-transport-map-loading-b43-source-1.json` SHA256 `adb4a8e693107f9270a7d85385c38a667bb08969b5d1e44f51158fe710bf7b7c` 직접 일치.
- exact head `b43feae2659af8caf376d7d7a012c9299c2088e8`, tree `ac3bd2e4882aad944afcad78006ce244d7bcecf7`, review base M9 `9aebd19947c3606c2953eb564e7eee4541be5856`. 직접 부모59a는 미실행 중간 후보이며 base와 구분한다.

## B-MAP-LOAD-P3-01 — 미실행 alias 수정의 동색 확정 표현을 좁힐 것

- 위치: `docs/resume.md:7`, `docs/journal.md:7`의 “--color-muted가 배경 토큰으로 매핑되어 전경과 같아지는 문제를 확인했다”.
- 직접 근거: source `frontend/app/globals.css:30`에는 color-muted→surface-subtle이 있지만, 별도 **unlayered :root** `app/tokens.css:29–31`에는 color-muted→muted→text-secondary 정의도 있다. root layout은 tokens.css를 함께 import한다. 59a의 실제 compiled/computed 색 관측은 이 입력에 없고 사용자도 그 후보를 미실행으로 인계했다. 한 선언만 보고 과거 실제 fg/bg 동색을 확정할 수 없다.
- 영향: 후속 원인·검증 이력에서 실제로 재현된 동색 실패가 있었던 것으로 읽힐 수 있다. 이는 **b43 foreground-token 선택의 결함을 지적한 것은 아니며**, 기존 M9의 clip0 실측이나 현재 소스의 기능을 뒤집지 않는다. 문서의 “diff 검토/실제 실행 대기” 문맥은 있으나 이 단정 부분은 더 좁히는 것이 정확하다.
- 권고: “실행 전59a의 별칭 혼동을 피하려 전경 의미가 명확한 --color-muted-foreground로 정리했다. 실제 computed fg/bg는 새 exact QA 대기” 정도로 기록한다. 현재 b43에서 동색이 재현됐다는 주장은 하지 않는다.
- disposition: **OPEN, P3 NONBLOCKING 문서 정정 권고**. 제품 source는 PASS이며 원 구현자가 후속 문서에서 처리할 수 있다. 원 B는 소스를 고치지 않았다.

## 제품·token·SDK 책임

- TSX delta는 `components/transport-map.tsx:542`의 제공 node를 `p.loading`에서 **p.transport-map-loading + role=status**로 바꾸는 것뿐임을 문자열 동등성으로 확인했다. SDK/MapLibre API·props·onLoad/onIdle/error/fallback·engine 생성 경로·focus/menu는 변하지 않는다.
- globals602의 신규 app 전용 selector는 기존 `.map-primary` containing block 안에 absolute/inset0·flex center·margin0·기존 spacing/foreground/background token을 적용한다. 전역 `.loading`은 그대로이고 pointer-events:none은 새 focusable/입력 가로채기 경로를 추가하지 않는다. foreground는 globals31의 명시적 muted-foreground→muted alias를 사용한다. 실제 computed 색·layout·대비는 **미실행**이다.
- 봉인 SDK의 load→MapChildren/skeleton lifecycle과 기존 API를 그대로 사용한다. 따라서 loading→children 제거는 기존 SDK가 소유하며 별도 timer·가짜 canvas·자체 loading engine을 만들지 않았다. 실제 loaded 후 제거·stacking·접근성 동작은 후속 exact 실행에서 확인해야 한다.
- source가 제공하는 plain ReactNode와 app 부모 clipping/배치의 통합을 앱에서 고치는 방향은 근거가 있다. Overlay 타입 주석의 위치 보장이 모호하다는 것과 **입증된 upstream 기능 버그**는 구분한다. 이 diff로 라이브러리 책임을 일괄 부정하거나 라이브러리 버그/초기화 속도 개선을 확정하지 않는다.

## No-JS oracle와 한계

- 기존 No-JS PC1280/mobile375의 실제 `/rail` frame bbox>=320·workbench1·지도/목록 탭 assertion은 그대로 보존됐다. 새 검사는 정확한 준비 문구의 **실제 p node**를 찾고 Range를 만들어 text bounding rect를 viewport와 **각 overflow clip ancestor padding box**에 축별로 교차시킨다. 양의 text/visible area와 **ratio>=99%**, role=status를 요구하고 원 geometry/computed color를 attachment에 기록한다. SDK double·CSS injection·DOM 높이 강제 설정·기존 단언 삭제는 없다.
- 이 oracle는 기존 “bbox는 있지만 clip 밖인 p”를 직접 겨냥한다. 기존 baseline의 parent bottom887/p top887 교집합0은 isVisible true와 달랐다. 새 before/after 실행을 하지 않았으므로 원 B가 old RED/new GREEN 또는 새 ratio99%를 실행 관찰했다고 쓰지 않는다.
- **Range의 bounding rectangle** 검사이지 실제 glyph pixel·다른 요소의 가림/stacking·opacity·clip-path·복잡한 transform·AT announcement의 완전한 가시성 증명은 아니다. 기본 현재 레이아웃의 직사각형 overflow clipping에 의미가 있다. font/zoom/테마·모든 viewport도 검사한 것은 아니다.
- `geometry.color !== geometry.backgroundColor`는 직접 computed serialization 동색 회귀 검사다. 합성 배경/alpha·서로 다른 색 공간의 동등성·**WCAG4.5:1 대비**를 보장하지 않으며 문서도 이 한계를 명시한다. 역할 status가 실제 음성 안내를 보장했다고 주장하지 않는다.
- 대상은 `/rail`의 No-JS2 viewport이며 shared TransportMap 경로에 대한 회귀다. **운영 PNG 실패 route `/map`의 새 전후 관측·실제 JS bootstrap·UI5초/SDK60초 시간 기준 수용을 대신하지 않는다.** private helper는 현재 이 입력에 없고 미준비·범위 밖·승인X다.

## 불변 경계·factual chain

- 정확5 paths 변경, head/base 각각909 blobs+gitlink1, 기존904개 blob 동일. 보호 inventory **298 mode/OID 동일**. package/lock/ledger/vendor subtree·tokens.css/layout·메뉴·기존 loopback helper OID도 base와 같다. backend/public/auth/keys/env/data gates·Map 앱 변경을 섞지 않았다. 공통 C11 bytes/license/repack 변경 없음이며 새 설치된 modules/빌드 산출물 검증을 했다는 뜻은 아니다.
- manifest refs6의 SHA/bytes 모두 일치. r2의 실제 index `frozen-remote/remote-frozen-members.json` hash를 확인하고 **13개 raw SHA/bytes/mode**를 직접 재검산했다. baseline source는 edb와 same-tree M9이며 새 b43 실행 결과로 전용하지 않았다.
- 기존 async45초 observer 실패/12raw 보존은 측정 하네스 역사이며 제품 실패로 합산하지 않는다. corrected sync No-JS1은 **지정 p**의 clip0을 입증한다. CommonMapReadout 등 대체 안내는 미측정이므로 모든 사용자 feedback이0이라는 결론으로 확장하지 않는다. docs는 이를 구분한다.
- M9 실제8P1F + PNG-only1 FAIL/default5000, focused decode·zoom 미도달은 불변이다. whole-session45/diagnostic19의 signature/size 적합 개수를 실제 bitmap decode 성공으로 부르지 않는다. 늦은 canvas/handle 관측과 `/map` 정적 크기 증가 근거 부재도 제품/라이브러리 최초 원인 확정으로 바꾸지 않는다. 정상 세션 총2회 종료·제3 production 로그인 GO 없음을 유지한다.

## 명령·evidence·미완 gate

- 수행은 manifest/refs hash, exact Git show/diff/rev-parse/ls-tree, 보호 mode/OID·정확 치환 검산, 봉인 token/SDK 계약 읽기뿐이다. 원 B source/index/branch 변경·test/browser/build/install/host/SDK/workflow/API/Map ops0. 상대 CURRENT 경로 읽기0.
- baseline index를 처음 일반 파일명으로 찾은 로컬 reader FileNotFound는 실제 hash-pinned remote index로 정정했다. 13개 직접 검산은 완료됐으며 제품/test 실행 실패가 아니다.
- **b43 exact QA·before/after·PNG/색/loaded lifecycle·CI·배포/운영 수용은 모두 PENDING**. 소스 PASS만으로 이전8P1F를 닫거나 UI5/SDK60 contract를 승인하지 않는다. Common/Geo publication HOLD 유지.
- own evidence `review-B-transport-map-loading-b43-source-1-evidence/verification.json` SHA256 `46d94701e1a5696f997926bfc047f7f33dda1ddf21f47fbb154c275ec9d7405e`; exact5path diff·token/문서/오라클 줄 번호·보호/ref/raw13 검산·명령/evidence index를 별도 보존했다.
