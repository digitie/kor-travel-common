# Original B — Transport map-loading bd08 FINAL_EXEC4

- Run ID: `B-MAP-LOAD-BD08-FINAL-EXEC4-20261112`; frozen UTC: `2026-11-12T12:55:04.079102+00:00`.
- **판정: PREMERGE_PASS / 신규 finding 0 (P0–P3 모두 0).** 기존 source2 P3 FIXED 및 helper3 HELPER_CONTRACT_PASS를 유지한다.
- 원 reviewer B / Epicurus, 구현 비참여. 상대 CURRENT EXEC4 원문·결과 열람 0. 과거 raw·manifest 변경 0.
- Manifest `review-manifest-transport-map-loading-bd08-final-execution-4.json` SHA256 `a574561afcd7d68ae485e064eacc3234c1cb35ef57efc2899f83a8e598c2e5c6` 직접 일치.
- 정확한 source `bd08ec1c09968f930e5356a70ba7eedd4d47f635`, tree `4fec4f76df0cd88fdaca22d42ae2acb2f876ce6f`. Source·QA·identity binder·exact CI의 premerge 결박에 한정한다. merge 실행·배포·운영 로그인 GO는 부여하지 않는다.

## QA·소스·artifact 증거

Manifest의 18개 reference bytes/SHA256, local QA 봉인 124개 및 ARM `frozen-complete/` 16개 bytes/SHA256/mode를 직접 대조해 불일치 0. 실제 준비 module 7개도 원 bundle과 동일하다. 원격 16개 확인은 부모의 봉인 receipt로 평가했으며 B가 호스트를 다시 조회한 것은 아니다. 처음 ARM index를 candidate root 기준으로 해석한 reviewer 경로 오류는 바로잡았고, 가변 root 파일을 봉인 사본 대신 사용하지 않았다.

10개 실제 Playwright JSON report에서 native43+Alpine43=86 PASS, 각 case 결과 1개·retry0·skip0·flaky0·unexpected0·errors0을 직접 집계했다. NoJS 2개는 native43 안에 포함돼 있으며 추가 실행으로 중복 계수하지 않는다. 원 edb 대상 NoJS before는 0 PASS/2 FAIL로 따로 보존돼 있다. 이 old fixture RED 2건과 과거 M9 정상/PNG 진단의 실제 5초 FAIL 2건은 서로 다른 이력이며 어느 쪽도 지우거나 소급 PASS 처리하지 않는다.

NoJS PNG1280/375 두 장을 직접 열어 지도 준비 문구가 작업면 안에 보이는 것을 확인했다. 봉인 기하 결과의 glyph clip ratio1·색 비동일성과 합치한다. 이는 `/rail` NoJS 초기 frame 관찰이며 실제 `/map` UX5초·SDK60초·PNG decode·zoom 수용 증명이 아니다. Source1의 library 책임/원인 미확정 경계도 유지한다.

실제 QA source/tree는 **b43/ac3b**다. Git object상 bd08은 docs2개만 달라 다른 908 entries가 동일하다. 따라서 runtime/tests/COPY/common 증거를 연결하되 b43의 전체 source909 실행을 bd08으로 재표기하지 않는다. Native nonbrowser receipt SHA `61c604649061db53af6dc60115c19fbe4713e9baa68db6cd08b973888cb63162`와 모든 기록된 step exit0, 재사용 buildID 및 새 Alpine image 연결을 확인했다.

봉인 actual image audit는 COPY298/common263/compiled routes32 및 mismatch0을 기록하며 native common 합계도 263이다. 로컬 fixture key를 사용하는 x64/Alpine QA이고 운영 VWorld 성공을 뜻하지 않는다. 초기 controller의 missing-file 대기(target0), screenshot transfer timeout, stdin audit timeout은 기록대로 남고, 교정된 읽기 전용 audit는 별도 exit0이다. Cleanup 기록은 own process/server/container/heavy0이다. 이 검토에서 제품 테스트/브라우저/호스트 재검증은 수행하지 않았다.

ARM `4cca2e4a...`는 **b43 cache-only**이며 source909/COPY298/common263/routes32, key/env 해시 및 OCI/default source 일치를 봉인 증거로 확인했다. 미래 merged M의 image가 아니며 이 cache image의 retag/applyReady/배포 승인을 뜻하지 않는다. 라이브러리·lock·pack 재발행도 없다.

## Identity binder와 새 계약

`bind_qa_identity.py` SHA256 `793fb71da177bcb198049f442e879788faddce1ab8b4b9232e283edc413a593c`를 읽고 원본 common SHA 고정, 정확한 두 anchor, 엄격한 metadata key/형식, 역복원 byte 동일성을 확인했다. 실제 auth/ownership/current/admission 및 기존 검사·timer body를 바꾸는 경로가 없다. 출력은 O_EXCL·mode0600이며 admission을 쓰거나 활성화하지 않는다.

B의 독립 pure2는 PASS. 합성 tuple만 사용한 CLI 검증에서도 두 상수 역복원이 원본 bytes와 같고, 기존 출력 대상은 exit1로 거부하며 내용이 보존됐다. 실제 M/image는 바인딩하지 않았다. 부모 pure r1의 test marker 오기 1P1F→r2 2PASS 이력과 log는 유지하며 r2 log SHA를 candidate receipt와 대조했다. Factory code가 바뀐 red→green으로 주장하지 않는다.

현재 실제 caller 준비는 여전히 원 M9 pin/disabled admission/expectedM·image null/parentGO false다. 준비 controller의 SHA `cef3371d56bd2c3a8aeb5f2e10507722c8585423a68c4bb2a8361d5ffc148447` 일치 후 코드만 읽었다. 미래 execute는 별도 reviewed binding bundle·공식 source/image/healthy-current proof·parentGO가 필요하다. 이번 binder 승인은 이 조건을 충족했다는 판정이 아니다.

부모가 채택한 UX5초+단일 bootstrap60초는 **early canvas5초를 명시적으로 완화한 새 계약**이다. 기존 조건과 동등하거나 성능이 좋아졌다는 뜻이 아니다. Helper/caller 해시는 원 helper3 그대로이며 품질 oracle·postzoom20/45/30·pending/cleanup 실패 처리는 유지된다. 원 M9 8P1F 및 PNG 진단 FAIL, observer 원인 미확정과 과거 실패를 보존한다. 기존 controller900초는 명시적 전체 상한이며 나머지 독립 최대 시간을 모두 합쳐도 충분하다는 증명은 아니다. Timeout은 FAIL이고 재실행/재로그인으로 통과시키지 않는다.

## Exact CI 직접 종료 확인

최초 B API 관찰에서는 backend 두 job이 in_progress였다. 이후 직접 재조회한 아래 **3 run 모두 attempt1 / head bd08 / completed-success**를 확인했고 최종 API·필요 raw log를 own evidence에 저장했다. 처음 pending이었던 관찰도 보존한다.

| 고정 run | event / 실제 checkout | 최종 직접 확인 |
| --- | --- | --- |
| [43215261871](https://github.com/digitie/kor-travel-transport/actions/runs/43215261871) | PR / `8303f9f29a9cc6b54995af499ba2c12242a33cd6` | public164, admin458, Doctor0/type/lint/build SUCCESS; backend1548P/2SKIP/6warnings, 2390.00s |
| [43215254241](https://github.com/digitie/kor-travel-transport/actions/runs/43215254241) | push / exact bd08 | public164, admin458, Doctor0/type/lint/build SUCCESS; backend1548P/2SKIP/6warnings, 2479.74s |
| [43215262267](https://github.com/digitie/kor-travel-transport/actions/runs/43215262267) | PR common policy / exact bd08 | 두 소비자 policy job SUCCESS; code55a921b/datae8ed3ae 실제 log 일치 |

PR synthetic checkout8303의 parents와 전체 tree가 bd08 tree4fec와 같음을 Git object로 직접 확인했다. Push 로그도 bd08 checkout이다. Backend job131172769114/131172741666의 최종 요약·checkout, frontend/public/admin 및 정책 로그를 각각 읽었다. **두 backend의 2SKIP과 두 run의 live-e2e SKIPPED는 PASS가 아니다.** 다른 source/head/run 또는 옛 b43 결과를 새 exact CI로 대체하지 않았다.

## 남은 운영 gate·증거 고정

실제 미래 merged M의 정상 ARM build와 whole-source/COPY/common/key/env/OCI/default strict audit, fresh 공식 SDK apply/current/postproof, 정상 1 login+1 logout의 실제 9검사·새 시간 계약·PNG 시각 확인은 **postmerge 미완/별도 GO**다. 현재 main/image의 실제 수용, ENV/키 변경, 운영 로그인, Map 작업을 이번 판정으로 확대하지 않는다.

직접 명령/검산은 own `commands.md`, `verify-inputs.py`, `review-evidence.py`, `input-verification.json`, `evidence-review.json`, binder logs 및 `own-final-ci-receipt.json`에 기록했다. 제품/source/index/branch, 기존 raw/manifest 수정·browser/build/install/prodlogin/SDK/Docker/Map ops는 모두 0이다. Peer CURRENT EXEC4는 읽지 않았다.

Own evidence: `validation/review-B-transport-map-loading-bd08-final-execution-4-20261112/`.
Own final CI receipt SHA256: `de38250eaf5111c3e2252ef9912e8bd8be1093d3cb85e9a6ada798ccf533c186`.
Evidence index SHA256: `533e2ef19e7c40dd014a22626835d768a6e59c893a0b4d26616a989486f33527` (`evidence-index.json`, 각 파일 bytes/SHA 포함).

**최종: PREMERGE_PASS / 신규 0.** Source2·helper3의 기존 판정을 유지하고 local QA/bytes·identity binder·정확한 3 CI 성공 대기를 이 입력 범위에서 닫는다. 실제 merged M 운영 수용은 닫지 않는다.
