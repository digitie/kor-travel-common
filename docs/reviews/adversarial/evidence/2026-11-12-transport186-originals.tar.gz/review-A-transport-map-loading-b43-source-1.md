# Independent A — PR186 b43 loading integration SOURCE1

- Run A-TR-LOADING-B43-SOURCE1-20261112; UTC 2026-11-12T12:01:10.774435+00:00 → 2026-11-12T12:02:34.021430+00:00; original A/Mill frontend/accessibility reviewer, 구현 비참여, peer CURRENT 원문/결과 열람0.
- Manifest SHA256 **adb4a8e693107f9270a7d85385c38a667bb08969b5d1e44f51158fe710bf7b7c** 직접 일치. 고정 ref6개 SHA256/bytes 일치; exact source **b43feae2659af8caf376d7d7a012c9299c2088e8**, tree **ac3bd2e4882aad944afcad78006ce244d7bcecf7**, base M9 **9aebd19947c3606c2953eb564e7eee4541be5856** Git 직접 검산.
- 관찰 checkout exactb43/추적 파일 clean. **BOUNDED SOURCE PASS / 신규 findings0(P0/P1/P2/P3 각0)**. 새 QA·CI·private readiness helper·runtime 수용은 모두 **PENDING/NOT_APPROVED**다.

## Source correctness / CSS / stacking

- Base→head는 정확5paths다. 제품 TransportMap 파일 전체는 기존 loading p의 class→전용 transport-map-loading 및 role=status 치환만으로 exact 재구성된다. globals.css 전체는 새 scoped rule1개와 설명 주석을 제거하면 base와 byte-identical이다. SDK 초기화·callbacks·camera/선택/요청·frame/tab·focus 로직은 수정하지 않는다.
- **globals.css:599–602**: 기존 position:absolute/inset0 map-primary가 containing block이고 새 loader도 absolute/inset0으로 같은 작업면 안에 놓인다. flex center, margin0, 기존 space-lg padding을 사용해 full-height canvas 뒤의 normal-flow paragraph였던 원 경로를 제거하는 방향이다. overflow clip 자체를 전역 해제하거나 frame 높이를 임의로 늘린 교정이 아니다.
- Baseline ref는 M9 동등tree/NoJS1280×900에서 loader y887/h110.5, map-primary bottom887, 교집합0 및 isVisible=true를 실제 기록했다. 이는 기존 plain p clipping의 구체 근거다. **b43의 교정된 교집합·픽셀 결과는 아직 실행하지 않았다.**
- 기존 canvas는 globals.css:239 isolation:isolate다. 새 positioned sibling은 renderer상 canvas 뒤에 있고 별도 높은 z-index를 추가하지 않는다. 의도한 loader/canvas paint 순서와 Common stage-content z0 / stage-overlays z1 경계는 소스상 일관된다. 새 loader가 common summary/detail 전체를 덮는 전역 레이어를 만들지 않는다. 실제 occlusion/짧은 viewport의 summary 겹침은 미검증이다.
- pointer-events:none 및 focusable control 없는 p를 사용하므로 배치 교정 자체가 포인터·Tab 정지를 추가하지 않는다. status는 사용자 포커스를 강제로 옮기지 않는다. loaded 이후 p를 남겨 불투명 배경이 지도를 계속 가리는 새로운 상태 관리는 없다.

## Token / readability / a11y / lifecycle

- **transport-map.tsx:542**는 전용 class+role=status를 실제 loadingSkeleton node에 준다. unchanged sealed web1.0.3의 MapChildren은 loaded=false 때 이 node를, loaded=true 때 children을 반환한다. 기존 load lifecycle이 loader를 제거하며 새 타이머·engine-ready 신호를 도입하지 않았다. 키 없음/init error의 fallback 경로도 그대로다.
- 전경은 **var(--color-muted-foreground)**, 배경은 기존 **var(--surface-subtle)**, padding은 기존 **var(--space-lg)**다. RootLayout:4–6의 tokens/globals/app tokens import 경로까지 읽었다. globals.css:31의 foreground→var(--muted), 실제 app/tokens.css:29의 muted→text-secondary 및 :18의 text-secondary 팔레트, :16의 surface-subtle 연결을 확인했다. shared shadcn의 muted 배경 정의만 떼어 최종 앱 전경을 판단하지 않았다.
- App palette/common bridge가 기존에 존재하며 raw 색이나 새 임의 토큰을 넣지 않았다. 중간59a는 본 exact 입력의 실행 전 실패 증거가 아니므로 color red/green으로 세지 않는다. **computed foreground/background·실제4.5:1 contrast·dark/forced-colors/폰트별 가독성은 source-only로 입증하지 않는다.**
- Common MapReadout의 별도 role=status/“지도 로딩 중” 경로는 unchanged다. p clipping 교정은 그 대체 안내의 기존 가시성을 증명하거나 부정하지 않는다. 라이브 screen-reader announcement 중복/실제 읽기 순서는 browser/AT 실행 범위다.
- Caller가 제공하는 ReactNode의 배치를 교정하는 통합 변경이며 sealed library bytes를 바꾸지 않는다. “Overlay” 주석과 bare sibling renderer의 모호성을 근거로 upstream bug를 확정하지 않았다. 실제 초기 엔진 속도나 이전 canvas5초 실패의 원인을 고쳤다는 주장도 하지 않는다.

## NoJS regression quality / limitations

- **rail-map-server-frame.spec.ts:24 이후**의 추가는 실제 p text에 Range를 만들고 viewport와 overflow auto/scroll/hidden/clip 조상 padding-box의 교집합을 구한다. 본문을 stub하거나 CSS/DOM·SDK 상태를 주입하지 않는 synchronous evaluate다. 과거 async NoJS observer45초 실패와 같은 브라우저 timer/Promise 측정에 의존하지 않는다.
- old test 전체는 insert-only이며 기존 heading·region height>=320·workbench1·실제 지도/목록 tabs 단언을 보존한다. 새로운 text rect 폭/높이·visibleArea>0·visibleRatio>=0.99와 role=status는 isVisible만으로는 못 잡던 원 clipping을 직접 겨냥한다. 측정 JSON에는 clip ancestors와 computed color/background도 첨부된다.
- padding box의 clientLeft/clientTop/clientWidth/clientHeight를 사용해 border/scrollbar를 구분하고 축별 clipping을 적용한다. 해당 fixed viewport·transform 없는 initial layout에서 합리적인 oracle다. 줄바꿈된 Range의 union bbox는 정확한 glyph ink나 occlusion 픽셀 검사가 아니며 다른 요소가 위를 덮는 경우는 이 수식만으로 걸러지지 않는다.
- color!=backgroundColor는 동일색 회귀만 잡는다. opacity/다층 배경/가림·WCAG contrast를 일반적으로 증명하지 않으며 docs도4.5:1 주장을 하지 않는다. 검사 폭은1280/375, 높이900이며 전체 responsive·폰트 준비·hydration·engine load 뒤 제거/상호작용으로 확대하지 않는다.
- javaScriptEnabled=false의 loopback helper와 기존 viewport/frame 경로는 unchanged다. 새 Range 측정은 초기 HTML/CSS의 배치만 대상으로 하며 **UI feedback5초 도달·SDK60초 readiness를 시험하지 않는다**. 별도 private UI5/SDK60 helper는 미제공/out-of-scope/승인0이다.

## Provenance / docs / remaining gates

- Manifest refs6개·Git5paths 및 필요한 RootLayout/token bridge를 읽고 immutable hash를 검증했다. protected15개(기존 SSR/정체성/focus/loopback helper·package/lock/ledger·UI/tokens/web tgz)가 base와 동일하다. backend/public/auth/key/env/메뉴/Map 앱/라이브러리 reissue 변경은 이 diff에 없다.
- docs2는 기존 본문 전체를 suffix로 보존하고 구현·원 clipping·foreground correction·한계·새 검증 대기를 추가했다. 실제 baseline이 전체 feedback0이라는 주장을 하지 않고 CommonMapReadout 미측정을 남긴다. 원 M9 actual8PASS1FAIL/PNG-only1FAIL 및 실패 원인 미확정을 유지한다. 원 async observer failure12raw는 제품 failure로 세지 않는다.
- Original advisory1/loading supplement/assets supplement의 기존 SHA를 다시 확인해 불변 보존했다. /map emitted bundle-size-growth 근거 없음과 /rail 별도 초기 비용도 이 수정으로 재판정하지 않는다. 이전 source/QA PASS를 새 b43 runtime PASS로 소급하지 않는다.
- Evidence **review-A-transport-map-loading-b43-source-1-evidence/**: verification.json, source.patch, exact TSX/CSS/tokens/NoJS numbered text 및 sealed renderer·stage/token 관련 packed text.
- Commands: git rev-parse exact tree/HEAD/status; git diff --name-only/--no-ext-diff --unified7 M9→b43 및 --check(exit0); git show exact paths; Python SHA256/bytes·exact product reconstruction·insert-only test 비교·docs suffix/protected15 비교; memory tarfile source read. reviewer source/index/branch/하네스 편집0·test/build/browser/install/prodquery/login/SDK/Docker/Map ops0·peer CURRENT0.
- **Source-only PASS**에 한정한다. 정확 b43의 전후 NoJS/시각 검증·새 전체QA·CI·동일 원 reviewer gate·새 M/image/공식 apply/운영 전체 수용은 미완이다. Private helper 신규 시간 계약과 performance 수용은 후속 독립 입력이 필요하며 현재 원5초 FAIL2건은 그대로다.
