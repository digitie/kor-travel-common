# Common50 문서 사실관계 후속 독립 리뷰 A — 입력2

판정: **DOCS FACTUAL CLOSURE SOURCE PASS**. 신규 P0/P1/P2/P3 각 0건. 불변 79ed의 원문 출판·5개 앱 수용 사실 정산 범위이며, 앱 runtime 재실행/전체 앱 승인/Transport 또는 admin 승인으로 확대하지 않는다. 관찰 당시 새 docs CI는 진행 중이다.

- runid: A-COMMON-FINAL-DOCS-2-79ED-20261112-01
- 시작 UTC: 2026-11-11T22:45:28.219700+00:00; 완료 UTC: 2026-11-11T22:50:40.824435+00:00
- manifest `review-manifest-common-final-docs-2.json`, 직접 SHA256 **33af7ed0637207d2fa27c59b4ca2ec3d9c836e67f887646b605908fa007f1032** 일치.
- base **1742c3756b8f28a685741eb2f88d3bef49c5cafc** → head **79ed906f53b4fb18908f045bda486dfde27fbcd8**; exact tree `a931a7bdb035e274c3dafdf68e83455c195f44ca`. 실제 worktree 시작/종료 head 일치·clean.
- 원 A/Mill, 구현 비참여. 상대 CURRENT 입력2 raw/verdict 미열람. 확정된 입력1 원문은 바이트 보존 대조에만 사용했다. 코드/규범 수정·설치·repack·merge·운영 호출·auth 재실행 없음.

## 불변 소스와 원문 보존

base..head 변경은 manifest와 같은 **10개 경로**다. 각 실제 Git blob ID·SHA256·크기를 대조했다. 기존 **1414 tracked entry**가 mode/type/blob 동일하다. standards·packages·versions·정책·tools·vendor·workflows 및 소비자 저장소 변경은 없다. 원 입력1의 게시 evidence 전부도 그대로다.

새 원장3개 records의 published path를 **git show head:path 실제 blob 바이트**로 읽고 root 원본과 직접 비교했다.

| 원문 | SHA256 | 바이트 |
|---|---|---|
| A 입력1 | 809fbe8c8f0ae06c8868fff808d09bc3a9527a370010a6173081920743a14990 | 9732 |
| B 입력1 | 856acad4dc62b6febcb86b9aa7250db6b006e98a6c333dcc4c343c19ced05294 | 9025 |
| manifest1 | 852069ed9adf00b7bd5cd64f8dc1eccf346b55abfafe4d3d296efa28ae20ec4f | 13312 |

세 파일 모두 원문·원장·Git blob이 일치한다. A 입력1의 당시 4개 snapshot/CI pending과 당시 LIMITS를 고치지 않았고, 이번5개 완료는 별도 공개 receipt/새 journal/후속 절에 기록했다. 원문 BLOCK·미실행 등 과거 source 판정은 바꾸지 않았다.

## 배포 receipt provenance 직접 비교

새 `2026-11-12-frontend-deployment-receipt.json` 실제 Git blob SHA256 **802be47afd9f2633a7e944c68433d86d601da207d3d5db014e0250d4478d6e39**를 검증했다. `apps`는 Manager/Concierge/Pinvi/Weather/Geo 정확5개이며 count5와 같다. Map/Transport는 완료 앱 집합 바깥이다.

공개 receipt의 원본 **7개 직접 참조**(5개 primary와 Manager SDK 두 호스트 final receipt)의 파일명·바이트 수·SHA256을 실제 로컬 원본과 전부 비교했다. Geo/Weather/Pinvi primary가 연결한 **하위23개 원본**도 지정 hash·크기를 대조했다. 원본 raw의 운영값을 새 evidence로 복사하지 않았으며 경로/해시/대조 결과만 기록했다. `deployment-provenance.json`, `own-factual-field-checks.json`.

| 앱 | 게시된 source·실행 방식/이미지 | 공통 파일 수 | 직접 확인한 사실 범위 |
|---|---|---:|---|
| Manager | frontend9910b9a·기존 systemd 새 build, SDK590 두 호스트는 별도 | 153 | 기존 정상 로그인/표/모바일/글꼴/logout401·WebSocket30초, 설치 원본/파일 수 |
| Concierge | f2db107c·77de7633 | 263 | 제 기존 실제 수용 JSON과 auth200/200→401·map34·source/image 연결 |
| Pinvi | dd3bcd18·a029e906 | 297 | 공식 paired 완료와 runtime200/204→401·이전 cookie401·Map 구 pin 보존 |
| Weather | faca2cee·e8abd9f4 | 263 | 실제 이미지 바이트·정상 계정1회·표/overlay/모바일·map40·logout401 |
| Geo | 786dae25·82c7c354 | 263 | 공식 state4단계0·v4 driverExit0·표37행·검색/글꼴/모바일·지오코딩1·map9·logout401 |

위 값은 **보존 원본을 읽어 대조한 결과**다. 이번 리뷰에서 runtime/브라우저/DB/auth를 새로 실행하지 않았다. 앱 source 전체를 다시 검토한 판정도 아니다.

## 반례·미완료와 source/runtime 상한

- Manager의 별도 과거 공유PG fingerprint 차이1은 원인 미확정·미복원으로 남는다. 이전19개 중 설정18개 동일과 image/start/restart identity 보존을, 모든 설정 불변으로 확대하지 않는다. 새 공개 receipt도 별도 historical observation으로 이를 명시한다.
- Manager n150 SDK590 final receipt의 **제공 credential offline mismatch 때문에 실제 login을 재시도하지 않음**을 직접 확인했다. 공개 Manager 정상 수용은 별도 earlier frontend9910 원본이다. 두 호스트의 새 SDK 점검에서 제공 credential 로그인이 모두 성공했다고 해석하지 않는다. credential/reset/session 조작이나 추가 로그인은 하지 않았다.
- Geo의 official-state source/image, 네 명령 exit0, 환경 보존 및54개 비선택 보존을 primary/v4 원본과 대조했다. module path·Fetch.status()·경로/locator 보정 등 prior harness 실패/재시도도 기록된다. `productSourceChangesForQARetry=0`이며 이를 제품 소스 버그 수정·재빌드로 바꾸지 않았다. 정상 login/cleanup과 최종 UI logout을 한 번의 처음부터 완벽한 성공으로 축약하지 않는다.
- Transport는 **BUILDING_PENDING_APPLY_ACCEPTANCE**이며 이번에 승인하지 않는다. Map은 최신 사용자/Claude 인계로 추가 build/deploy 제외이며 기존 PR 머지만 보존한다. native 실기기/EAS/store는 **NOT_RUN**, T-218은 **IN_PROGRESS**다.
- 공개 JSON에는 full private path/운영 URL/환경/계정/키 값이 없다. evidence는 basename·크기·SHA만 게시한다. exact changed-file scanner 결과도 아래와 같이 확인했다.

`docs/resume.md`, `T-218`의5개 완료와 남은 작업이 위 원장과 일치한다. journal의 입력1 당시4개 기록과 원문은 그대로 보존한다. source PASS/설치/실제 운영 수용/SDK 상태를 서로 구분하고, 같은 버전 패키지 bytes의 새 발행을 추론하지 않았다.

## 직접 실행한 문서·scanner·적대 검사

- exact Git Markdown/validator를 own `/tmp/review-A-common-final-docs-2-object-fixture`에 추출했다. 다른 tracked target은 **존재 검사만 위한 빈 파일**이며 패키지 내용 검증/설치로 계산하지 않는다.
- 링크 **840문서/3197대상/errors0**, plan **111 task/errors0**, exact base..head `git diff --check` **exit0**.
- 공개 배포 receipt 링크를 own fixture에서 없는 파일로 치환하면 공식 link validator **exit1**. 이후 own fixture 원문 복원. fragment·remote URL 가용성은 도구 범위 밖이다.
- 새 B 입력1 raw는 실제 **CRLF1 + bareLF87**의 혼합 원문이다. 추가 attributes는 그 정확한 한 경로만 `-text -eol whitespace=cr-at-eol,-blank-at-eof`로 보존한다. Git `hash-object --path` 필터 결과와 raw `--no-filters` hash가 같고 LF 정규화 시 SHA256이 달라진다. 기존6개 예외는 변경 없다.
- `check-attr --source=head`에서 인접 A 원문/공개 JSON/미래 raw 이름에는 새 예외가 없다. 별도 own Git fixture에서 정확 새 예외 경로라도 trailing space를 넣으면 `git diff --check` **exit2**다. 저장소 전체 whitespace 정책을 끄지 않는다.
- exact head와 base 사이 **Git object 변경10개**만 공식 `scan_secrets.py --base ...` 및 `check_prod_redaction.py --base ...`로 직접 검사했다. 둘 다 **exit0,10파일/발견0/명시적 예외0**. 전체 runtime/400개 회귀를 새로 실행한 수치가 아니다.

실행 골격:

```text
git diff / git ls-tree -r / git rev-parse head:path / git show head:path / git cat-file --batch
python3 -B <own-fixture>/tools/validate_document_links.py <own-fixture>
python3 -B <own-fixture>/tools/validate_plan.py --root <own-fixture>
python3 -B <repo>/tools/scan_secrets.py --root <repo> --base 1742c3756b8f28a685741eb2f88d3bef49c5cafc
python3 -B <repo>/tools/check_prod_redaction.py --root <repo> --base 1742c3756b8f28a685741eb2f88d3bef49c5cafc
git check-attr --source=79ed906f53b4fb18908f045bda486dfde27fbcd8 text eol whitespace -- <exact raw/인접 경로>
git diff --check 1742c3756b8f28a685741eb2f88d3bef49c5cafc 79ed906f53b4fb18908f045bda486dfde27fbcd8
```

## CI 관찰과 최종 처분

GitHub API를 직접 조회한 UTC **2026-11-11T22:49:08.296Z**:

- 이전1742: frontend43111997734, python-package43111997752, docs43111997774 모두 SUCCESS이고 docs의6개 jobs도 SUCCESS였다. 당시 입력1 raw의 pending을 소급 수정하지 않고 별도 후속 관찰로 둔다. Python package workflow 성공을 Python 기능 전체400 재실행으로 확대하지 않는다.
- 새79ed: common frontend43114222024와 python-package43114221949는 SUCCESS, **docs43114221873 IN_PROGRESS**였다. 따라서 새 head 전체 CI PASS/merge 가능 확정으로 쓰지 않는다. API는 PR-triggered 첫 페이지 범위이며 전체 check suite를 망라한다고 주장하지 않는다.

이번 bounded source/factual closure는 **PASS**, 새 P0/P1/P2/P3 **0/0/0/0**, OPEN finding 없음. 이전 COMMON7/Scope2/소비자/SDK 및 Common50 입력1 판정은 불변 보존한다. 남은 CI·Transport/admin 신규 소스·후속 운영 수용은 별도 입력이다.

Evidence: `review-A-common-final-docs-2-evidence/`에 observations, bounded-source.patch, deployment-provenance, own-factual-field-checks, direct-bounded-scans와 raw logs, link-plan-attributes-attacks, narrow-new-attribute-adversary, direct-ci-status를 보존한다. 비공개 credential/ENV/raw response/세션을 복사하지 않았다.
