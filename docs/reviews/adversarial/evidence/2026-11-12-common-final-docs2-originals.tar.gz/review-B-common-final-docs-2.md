# 독립 리뷰 B — COMMON 최종 문서 사실 정산 입력2

- Reviewer: Epicurus, 원 B / packaging·platform·security·release. 구현 비참여.
- Run ID: Epicurus-B-common-docs2-20261111T224500Z
- UTC: 시작 2026-11-11T22:45Z, 판정 관찰 2026-11-11T22:47:59Z.
- Manifest: review-manifest-common-final-docs-2.json
- 관찰 SHA256: 33af7ed0637207d2fa27c59b4ca2ec3d9c836e67f887646b605908fa007f1032
- Repo / PR: kor-travel-common / PR50
- Base: 1742c3756b8f28a685741eb2f88d3bef49c5cafc
- Head: 79ed906f53b4fb18908f045bda486dfde27fbcd8
- Verdict: **제한된 DOCS / PROVENANCE PASS, 신규 finding 0. exact-head 원격 CI는 일부 진행 중으로 별도 조건 유지.**

## 범위·독립성·입력 보존

원 Common50 입력1의 PASS와 원문을 변경하지 않았다. 사용자 요청대로 입력1 이후 정확한 10개 변경만 검토했다. AGENTS / agent-workflow / reviews 규칙은 계속 적용하며, norm·package·code·workflow와 앱 소스의 새 승인은 범위 밖이다. 현재 상대 입력2 raw/판정은 읽지 않았다. 이미 확정된 입력1 원문은 게시 바이트 대조 대상으로만 사용했다.

manifest 경로 집합·Git blob OID·SHA256·크기 모두 head Git object와 직접 일치한다. packages/tools/vendor/.github/workflows tree, versions.json/package.json/package-lock.json, docs/standards, AGENTS.md, agent-workflow 및 두 scanner policy blob은 base와 동일하다. 과거 raw/manifest나 현재 작업 트리를 새 baseline에 섞지 않았다.

독립 증거는 review-B-common-final-docs-2-evidence/에 보존한다. 부모 repository의 index·source를 쓰지 않았고, 자체 /tmp snapshot·index·object DB만 사용했다. 원 저장소 object DB는 읽기 전용 alternate다. 설치·repack·commit·push·merge·운영 접속/변경은 하지 않았다.

## 원문 실제 Git bytes와 새 attributes

게시 원장 2026-11-12-common-final-docs-original-receipts.json의 **3/3**을 실제 root 원본과 head의 Git blob으로 직접 비교했다.

| 원본 | 실제 게시 SHA256 | 결과 |
|---|---|---|
| 원 A 입력1 raw | 809fbe8c8f0ae06c8868fff808d09bc3a9527a370010a6173081920743a14990 | exact bytes |
| 원 B 입력1 raw | 856acad4dc62b6febcb86b9aa7250db6b006e98a6c333dcc4c343c19ced05294 | exact bytes |
| 입력1 manifest | 852069ed9adf00b7bd5cd64f8dc1eccf346b55abfafe4d3d296efa28ae20ec4f | exact bytes |

입력1 B 원문의 당시 네 앱 완료 snapshot, 판정과 CI 관찰은 그대로다. 이전 35개 게시 원본도 이번 10개 변경 집합에 포함되지 않는다.

.gitattributes:40–41의 새 규칙은 B 입력1 원문 경로 하나만 지정한다. 원문에는 LF와 EOF의 CRLF가 섞여 있으며, 이를 보존하는 -text -eol 및 whitespace=cr-at-eol,-blank-at-eof다. 새 wildcard나 전역 검사 해제는 없다.

자체 fixture에서 직접 수행한 공격:

- 새 규칙을 제거하면 원본 EOF/CR 공백 거부 exit2가 재현되고, empty index의 Git clean filter가 원문 blob을 바꾼다.
- 규칙이 있으면 원문의 filtered blob이 원래 Git blob과 같다.
- 해당 원문에 trailing spaces를 추가하면 공백 검사 exit2로 거부한다.
- 인접 미등록 경로는 text=auto/eol=lf와 기본 whitespace 검사를 유지한다.
- 해당 원문에 합성 canary를 넣어 자체 index에 stage하면 secret/redaction이 각각 1개 파일·1건을 탐지하여 exit1이다. .md.txt/attributes가 scanner 예외가 되지 않는다.
- 공격 후 snapshot 10개 SHA256을 다시 검사해 복원됨을 확인했다.

증거: manifest-blobs.json, original-receipts.json, unchanged-boundaries.json, attribute-scanner-attacks.json 및 audit.py/attributes.py.

## 배포 정산 JSON의 출처와 범위

2026-11-12-frontend-deployment-receipt.json은 관찰 시각이 있는 5개 앱 정산이며 실제 운영 실행을 이 리뷰에서 다시 했다는 기록이 아니다. 공개 JSON이 참조하는 **7개 원본 영수증** 모두 파일명·크기·SHA256을 실제 비공개 evidence와 직접 대조했다. 같은 final-receipt.json 이름을 사용하는 Manager 두 호스트도 서로 다른 해시와 크기로 정확히 식별된다.

Geo/Pinvi/Weather manifest의 하위 evidence **23개**도 각 고정 해시/크기와 일치한다. 실행 로그 내용은 검사에 읽었으나 운영 주소·환경·계정·가림값을 새 보고서에 복사하지 않았다.

직접 확인한 핵심 연결:

| 앱 | 공개 정산과 hash-bound 원본의 연결 | 이번 B가 직접 수행한 운영 실행 |
|---|---|---|
| Manager | frontend9910 / 공통153, 기존 정상 브라우저 및 logout 후 30초 WS 관측; SDK ca1d 두 호스트 설치 영수증 | 없음 |
| Concierge | f2db source / image77de, 실제 login200·table·font·mobile·VWorld34·logout200·protected401 | 없음 |
| Pinvi | dd3b source / imagea029 / 공통297, paired Map 기존 pin과 실제 수용 evidence | 없음 |
| Weather | faca source / imagee8ab, SDK590 공식 UI 경로와 실제 VWorld40·보호 API 전환 | 없음 |
| Geo | source786dae / image82c7 / 공통263, 공식 상태·이미지 감사·v4 브라우저의 같은 source/image | 없음 |

Geo official-geo-state-latest.json은 dryrun/confirm/current/verify 모두 exit0, expected image/current/health 일치, 기존 effective 환경과 비선택54개 projection 보존을 기록한다. 이미지 감사는 실제 263개 파일과 6개 archive SRI 검증을 기록한다. v4 응답은 driverExit0, mock 없음, PASS, 표37행·검색·폰트·모바일·지오코딩200/후보1·타일9응답200·logout200·보호401과 domainWrites0을 기록하며 공개 정산과 일치한다. 이미지 감사의 productionApplied=false는 당시 build 전용 단계이고, 후속 공식 상태의 actualApplySucceeded=true와 혼동하지 않았다.

이 검토는 영수증 bytes·일관성과 문서의 사실 범위 수용이다. live image를 다시 추출하거나 source786dae를 새로 앱 source 승인한 것이 아니다. 인용된 숫자는 hash-bound 실행 evidence를 읽어 대조한 값이다.

증거: factual-evidence-hash-binding.json, nested-factual-evidence-binding.json, semantic-fact-joins.json.

## 실패·미확정 상태와 수용 한계

- Manager production-completion-receipt의 과거 공유PG configuration fingerprint 차이 1건은 원인 미확정이다. rawBeforeConfig 부재, field-level 비교 불가와 dynamic-only 미확정을 원 영수증이 보존하며 공개 JSON도 이를 명시한다. 모든 과거 설정이 같다고 확대하지 않는다.
- n150의 후속 SDK 설치 영수증은 제공 credential의 offline mismatch로 정상 로그인을 재시도하지 않았고 credentialChanges=false라고 기록한다. SDKBothHosts는 설치/소스 확인이며 이 시점 새 로그인 PASS를 뜻하지 않는다. 기존9910 frontend 정상 runtime 수용과 별개로 대조했다.
- Geo의 검증기 module path/Fetch 사용/실제 v1 경로·locator 조정 실패와 재시도는 public 설명 및 원 evidence의 역사로 남는다. 최종 결과를 제품 소스 수정이나 반복 없는 첫 시도 성공이라고 주장하지 않는다. 제품 source QA 수정·계정 변경·backend/migration 변경은 원 manifest에서 0으로 구분한다.
- 현재 5개 상태만 DEPLOYED_VERIFIED이며 fullyAcceptedAppCount=5와 집합이 같다. Transport는 BUILDING_PENDING_APPLY_ACCEPTANCE, Map은 USER_HANDOFF_NO_FURTHER_BUILD_DEPLOY다. 새 Manager591 PUBLIC/admin 작업을 이미 수용한 것으로 표시하지 않는다.
- nativeDeviceEASStore는 NOT_RUN, T-218:3은 IN_PROGRESS다. source 판정·SDK 설치·이미지 build·실제 UI/API 수용·물리 native 검증을 합산하지 않는다.
- sameVersionArtifactRepacked=false와 unchanged Git tree/blob 증거가 맞는다. 새 규약/패키지/버전/CI 기능 변경은 없다.

resume/T-218의 현재5와 journal의 새 사실 구역이 일치한다. 입력1 원문 및 journal의 이전4 구역은 당시 snapshot으로 보존되어 있으며 소급 덮어쓰지 않는다. 원문 정산 문서도 Python dependency recovery 성공을 전체 Python 기능 시험 재실행으로 확대하지 않는다고 명시한다.

## 실제 실행 명령·결과

자체 immutable snapshot에서 실행했다.

- git diff --name-only BASE HEAD / git show HEAD:path / git rev-parse HEAD:path: 10개 입력 검증.
- 원본 read_bytes와 Git show 출력의 bytes/SHA256/size 대조: 3/3 PASS.
- Python으로 공개 receipt와 비공개 원본의 digest/크기 및 source/image/상태 필드 대조: 위 7개·하위23개 PASS.
- python3 tools/validate_document_links.py: **840 documents / 3197 local targets / errors0**, exit0.
- python3 tools/validate_plan.py: **111 tasks / errors0**, exit0.
- python3 tools/scan_secrets.py --base 1742c3756b8f28a685741eb2f88d3bef49c5cafc: **10 files / findings0 / exceptions0**, exit0.
- python3 tools/check_prod_redaction.py --base 같은 SHA: **10 files / findings0 / exceptions0**, exit0.
- git diff --cached --check BASE: exit0.
- git check-attr, hash-object filtered/unfiltered/empty-index 및 자체 staged-canary: 위 공격 결과.

--base는 자체 HEAD79ed의 commit blob을 읽는다. 부모 staged index나 workingtree scan 결과로 바꾸지 않았다. 원 400 run/399 PASS/1 SKIP는 역사이며 이번에 재실행하지 않았다. backend·app browser·export·ExpoDoctor·운영 runtime을 재실행하지 않았다.

## exact-head CI — 판정 시각의 별도 조건

GitHub connector로 79ed906의 PR workflows와 docs jobs를 직접 조회했다. 첫 조회와 후속 관찰을 github-ci.json에 보존한다. 2026-11-11T22:47:59Z 직전 관찰:

- frontend 43114222024: SUCCESS
- python-package 43114221949: SUCCESS
- docs 43114221873: IN_PROGRESS
- docs job130837892302 / secret-scan130837892310 / check-versions130837892492: SUCCESS
- packages130837891891 / Windows tools130837892450 / Ubuntu tools130837892465: IN_PROGRESS

https://github.com/digitie/kor-travel-common/actions/runs/43114221873

입력1의 exact1742 전부 성공을 입력2 CI 성공으로 대체하지 않았다. 이 원문 작성 후 CI가 끝나더라도 당시 pending을 소급 변경하지 않고 별도 closure로 기록해야 한다.

## Finding / disposition / verdict

새 P0/P1/P2/P3 finding: **0**. 입력1 원문 보존·좁은 새 attribute·배포 사실 정산·출처/상태 제한에 대해 **DOCS / PROVENANCE PASS**다. 원격 exact docs CI 완료는 별도 조건으로 남는다.

이 판정은 전체 앱 runtime의 재검증·Transport 최종 완료·Map 추가 배포·실기기/native·591 combined source 승인이나 merge/install/apply 지시가 아니다. 새로운 운영 사실이나 source 변경은 새 불변 delta가 필요하다. 이전 모든 raw/manifest와 판정을 보존한다.

