# Original B — Common final factual docs5

- Run ID: `B-COMMON-FINAL-DOCS5-20261112`; frozen UTC: `2026-11-12T14:00:51.830875+00:00`.
- **판정: PASS / 신규 finding 0 (P0–P3 모두 0), 문서 사실·출처·보존 범위 한정.** 최종 출판 CI는 미완이며 merge/운영 실행 승인이 아니다.
- 원 reviewer B / Epicurus, 구현 비참여. 상대 CURRENT docs5 원문·판정 열람 0. 기존 raw·manifest는 변경하지 않았다.
- Manifest SHA256: `50f3faf1904d5a08bf0285715dd489ac6aa497c1dc2c6d93f7e8e59a460c22f2`.
- Common head `37a264b34b0a9ed4189f62a271722dbdc6b8235a`, parent `4c43de5edb38676c01755edf3da26921e78767ff`, tree `1af715361dec570135adeac25e39f6b4a5d759f7`.

## 정확한 출판 범위와 원문 bytes

Git object로 14개 변경 경로가 manifest와 정확히 같고 각 bytes/SHA256이 일치함을 확인했다. Markdown5개·공개 JSON/closure receipt5개·archive4개이며 제품 source/package/version/lock/vendor/tool/scanner allowance/workflow/attributes 변경은 없다. 이동 중 workingtree나 index를 baseline으로 사용하지 않았다.

Git에 실제 들어간 archive blob을 메모리에서 읽어 다음을 검산했다. Root 원본과 비교한 것은 member별 원시 bytes이며 텍스트 개행 정규화 비교가 아니다.

| 아카이브 | 실제 member | 원본 bytes 일치 | 별도 생성 closure metadata |
| --- | ---: | ---: | ---: |
| docs3/4 | 6 | 6 | 0 |
| Transport184 | 36 | 34 | 2 |
| Transport185 | 36 | 34 | 2 |
| Transport186 | 48 | 46 | 2 |
| 합계 | 126 | 120 | 6 |

전체 tgz/member SHA256·bytes와 내부 index/외부 closure receipt가 일치한다. 단일 gzip stream이며 숨은 두 번째 gzip header/trailing stream이 없고, member는 모두 중복 없는 상대 regular file로 symlink/상위경로 이탈이 없다. 새 member에서 CRLF 변환은 관찰되지 않았고 원본 bytes가 그대로다. 과거 narrow attributes와 기존 archive는 변경 경로에 없다. 최초 reviewer 검산에서184의 생성 disposition.json을 root 원본으로 오인한 경로 기대 오류를 교정했으며 원문·기대 해시는 바꾸지 않았다.

자기 docs3/4 및 source186/helper3/EXEC4 원문 SHA가 보존됐다. 특히 EXEC4 원문 `f7380572ecdb9b8e4b96fb3d9f064f78b83c19d7c47fe9a12a31a25e864a84cc`와 helper3 원문 `c1c7403616939daf5ab1ae00301c100cdd9363168cbbdd1d652b73b6ee4af762`가 실제 published Git archive 안에서도 일치한다. 예전 pending/FAIL/P3 disposition은 새 보고서로 덮지 않았다.

## Source → image → SDK → 실제 수용 사실

공개 JSON과 archive-bound receipt에서 source `f30dbd823614399d6dc671eb1f1bf4d8f46c6064` 및 image `sha256:0ac648f860f7aba501ad6ff1b6f4457344e0ed91ebd60a2d1a9a4338b97be69b`가 build/SDK/actual9/parent visual 단계 모두 일치한다. Git object로 reviewed bd08·CI checkout8303·merged f30의 전체 tree4fec도 직접 대조했다. 이전 b43 QA의 전체 source909를 bd08으로 재명명하지 않고 docs2줄·나머지908 항목 동일이라는 bridge를 구분한다.

- ARM build는 별도 actual merged-source 정상 build이며 retag가 아니다. Source909·COPY298·공통6패키지263·compiled32·OCI/default 및 key/env digest 연결을 확인했다. 이 문서 검토가 ARM build나 image audit를 새로 실행한 것은 아니다.
- SDK508 dry-run1/confirm1·errors0·비선택54 보존, 공개936/image3262·backend499/schema0042 보존이 운영 receipt와 일치한다. 선택 Transport current가 새 source/image로 갱신됐다는 true 필드도 유지돼 과거 docs3 문구 문제를 되살리지 않는다. 실제 빌드 receipt의 normalDockerBuild 호환 필드1개 추가는 원본 보존·다른 필드 동일로 설명하며 SDK guard 완화나 추가 apply로 감추지 않는다.
- Remote44와 local18/미다운로드26, QA local63이라는 서로 다른 검산 범위를 문서가 정확히 구분한다. B는 봉인 원문·공개 Git bytes를 읽었으며 원격44개를 직접 다시 수집했다고 주장하지 않는다.
- 정상 actual9 첫 M30 세션의 9 PASS·실패0·login1/logout1·401→200 exactM→303→401, browser/decoder/pending/own process 종료가 receipt와 일치한다. 새 운영 로그인·도메인 조회는 수행하지 않았다.
- Bounded40(20+20)는 key/HTTP/signature/IHDR 검증이며 **실제 bitmap decode는 2+2 표본4개**다. Observer112 중77 format-qualified/나머지35 미분류를 전체 decode/PNG 성공으로 확대하지 않는다. Zoom7→8, 폭9개/왕복11행·폰트12행과 parent 실제 PNG4 확인도 서로 다른 증거로 구분한다. 두 모바일 crop의 동일 bytes를 추가 세션/독립 decode 증거로 세지 않는다.

이전47a Transport 전체 snapshot은 이전 JSON transport 객체와 같고, 다른 앱·public·priorHistory·remainingFollowups도 deep equality다. 184/185의 8P1F와 별도 진단 FAIL, bf9의 최초 실패/추가 관찰2/collector0, 새 NoJS2가 native43 안에 포함된 이력을 보존한다. 과거 원인 미확정·미도달을 성공이나 특정 원인으로 바꾸지 않는다.

## 새 계약·CI·발행 gate의 경계

새 actual 수용은 명시적으로 채택한 **UX feedback5초/단일 bootstrap60초** 계약이다. Early canvas5초 완화와 비동등성을 Markdown·JSON·archive가 함께 밝히며 과거 M9 FAIL2를 재분류하거나 성능 개선 인과를 주장하지 않는다. 관측2808.995ms/5644.271ms는 원 receipt와 일치한다. 제품 library 전체의 5초 SLA나 모든 최악 시간 합계의900초 내 완주를 새로 보장하지 않는다.

Source186의 정확한 PR/push/policy 성공과 backend1548P/2SKIP/6warnings, public164/admin458·Doctor0 및 live-e2e 두 SKIPPED는 이미 닫힌 과거 gate로 출판한다. **Source186 CI 성공을 이번 Common37a 문서 CI 성공으로 전용하지 않는다.** 부모의 최신 전달은 frontend/python SUCCESS, docs/packages 대기이며 B가 새 CI API를 직접 확인한 것은 아니다. 현 원문은 최종 exact docs CI all-green을 주장하지 않고 원2검토·정확 CI·PR50 merge를 출판 선행 조건으로 남긴다.

Parent frozen logs의 links840/3228·plan111, staged14 scanner 발견0/예외0, evidence751 scanner 발견0/예외0을 읽었다. Archive exact-file scope가 0개를 검사한 NOT_RUN도 남아 있고 후속 실제 evidence/staged 검사를 별도로 기록했다. Unit400 run399 PASS/1SKIP은 부모 실행 인계이며 B 재실행이 아니다. Scanner 규칙·allowlist 변경이나 검사 제외로 통과시킨 delta는 없다. 공개 archive는 검토·정산·해시 원문이며 PNG binary·raw credential/owner input·cookie/body/key URL을 새로 넣지 않는다. Private 운영 파일은 이름/hash reference와 공개 가능한 요약으로 구분한다.

현재 실제 수용6개는 문서의 사실 갱신이다. T-218 IN_PROGRESS·Map 사용자/Claude 별도 범위·native physical/EAS/store NOT_RUN을 유지한다. 순서는 Common50·Geo 단일 MD → Transport 남은 PR/빌드 체계 → 전체 프로젝트 build/CI/test 일관화 → CI 순서 최적화 LAST이며 전체 작업 완료로 확대하지 않는다. 규범·배포 버전·C11 artifact bytes의 재발행도 없다.

## 증거·제한·최종 판정

Own evidence: `validation/review-B-common-final-docs-5-20261112/`의 input-verification.json, exact-markdown.diff, verify-archives.py/archive-verification.json, factual-verification.json, commands.md.
Evidence index SHA256: `21cf54126a5407a895ce2edb82fa20e232f8edf186b03f1701d82d0f3cd03f4f` (`evidence-index.json`).

범위는 불변 Git source/기존 동결 receipt의 정적 사실·보존 검토다. Source186 재감사·새 tests/scanners/build/install/browser/auth/production/SDK/Map 작업·repo 수정은 모두 0이다. 실제 장비/운영 수용을 새로 재현하지 않았다. 기존 원문·manifest와 peer CURRENT 결과는 보존/비열람을 유지했다.

**최종 PASS / 신규 finding 0. 최종 Common37a exact CI 및 출판/merge gate는 별도 미완이다.**
